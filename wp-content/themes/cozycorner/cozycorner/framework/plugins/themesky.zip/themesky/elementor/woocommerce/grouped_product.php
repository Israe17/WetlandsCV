<?php
use Elementor\Controls_Manager;

class TS_Elementor_Widget_Grouped_Product extends TS_Elementor_Widget_Base{
	public function get_name(){
        return 'ts-grouped-product';
    }
	
	public function get_title(){
        return esc_html__( 'TS Grouped Product', 'themesky' );
    }
	
	public function get_categories(){
        return array( 'ts-elements', 'woocommerce-elements' );
    }
	
	public function get_icon(){
		return 'eicon-product-related';
	}
	
	protected function register_controls(){
		$this->start_controls_section(
            'section_general'
            ,array(
                'label' 	=> esc_html__( 'General', 'themesky' )
                ,'tab'   	=> Controls_Manager::TAB_CONTENT
            )
        );
		
		$this->add_lazy_load_controls( array( 'thumb-height' => 170 ) );
		
		$this->add_control(
            'specific_product'
            ,array(
                'label' 		=> esc_html__( 'Specific Product', 'themesky' )
                ,'type' 		=> 'ts_autocomplete'
                ,'default' 		=> array()
				,'options'		=> array()
				,'autocomplete'	=> array(
					'type'		=> 'post'
					,'name'		=> 'product'
				)
				,'multiple' 	=> false
				,'label_block' 	=> true
				,'description' 	=> esc_html__( 'Select a grouped product. If not, the recent grouped product will be selected', 'themesky' )
            )
        );
		
		$this->end_controls_section();
		
		$this->start_controls_section(
            'section_item'
            ,array(
                'label' 		=> esc_html__( 'Item', 'themesky' )
                ,'tab'   		=> Controls_Manager::TAB_CONTENT
            )
        );
		
		$this->add_control(
            'show_image'
            ,array(
                'label' 		=> esc_html__( 'Product Image', 'themesky' )
                ,'type' 		=> Controls_Manager::SWITCHER
                ,'default' 		=> '1'
				,'return_value' => '1'
				,'label_on'		=> esc_html__( 'Show', 'themesky' )
				,'label_off'	=> esc_html__( 'Hide', 'themesky' )
                ,'description' 	=> ''
            )
        );
		
		$this->add_control(
            'show_brands'
            ,array(
                'label' 		=> esc_html__( 'Product Brands', 'themesky' )
                ,'type' 		=> Controls_Manager::SWITCHER
                ,'default' 		=> '1'
				,'return_value' => '1'
				,'label_on'		=> 	esc_html__( 'Show', 'themesky' )
				,'label_off'	=> 	esc_html__( 'Hide', 'themesky' )			
                ,'description' 	=> ''
            )
        );
		
		$this->add_control(
            'show_title'
            ,array(
                'label' 		=> esc_html__( 'Product Name', 'themesky' )
                ,'type' 		=> Controls_Manager::SWITCHER
                ,'default' 		=> '1'
				,'return_value' => '1'
				,'label_on'		=> esc_html__( 'Show', 'themesky' )
				,'label_off'	=> esc_html__( 'Hide', 'themesky' )
                ,'description' 	=> ''
            )
        );
		
		$this->add_control(
            'show_price'
            ,array(
                'label' 		=> esc_html__( 'Product Price', 'themesky' )
                ,'type' 		=> Controls_Manager::SWITCHER
                ,'default' 		=> '1'
				,'return_value' => '1'
				,'label_on'		=> esc_html__( 'Show', 'themesky' )
				,'label_off'	=> esc_html__( 'Hide', 'themesky' )
                ,'description' 	=> ''
            )
        );
		
		$this->add_control(
            'show_add_to_cart'
            ,array(
                'label' 		=> esc_html__( 'Add To Cart Button', 'themesky' )
                ,'type' 		=> Controls_Manager::SWITCHER
                ,'default' 		=> '1'
				,'return_value' => '1'
				,'label_on'		=> esc_html__( 'Show', 'themesky' )
				,'label_off'	=> esc_html__( 'Hide', 'themesky' )
                ,'description' 	=> esc_html__( 'This add to cart button allows users to add all products in group to cart', 'themesky' )
            )
        );
		
		$this->add_control(
            'show_total_price'
            ,array(
                'label' 		=> esc_html__( 'Show Total Price', 'themesky' )
                ,'type' 		=> Controls_Manager::SWITCHER
                ,'default' 		=> '1'
				,'return_value' => '1'
				,'label_on'		=> esc_html__( 'Show', 'themesky' )
				,'label_off'	=> esc_html__( 'Hide', 'themesky' )
            )
        );
		
		$this->end_controls_section();
	}
	
	protected function render(){
		$settings = $this->get_settings_for_display();
		
		$default = array(
			'lazy_load'						=> 0
			,'title'						=> ''
			,'specific_product'				=> array()
			,'show_image' 					=> 1
			,'show_brands' 					=> 1
			,'show_title' 					=> 1
			,'show_price' 					=> 1
			,'show_add_to_cart' 			=> 1
			,'show_total_price' 			=> 1
		);
		
		$settings = wp_parse_args( $settings, $default );
		
		extract( $settings );
		
		if ( !class_exists('WooCommerce') ){
			return;
		}
		
		if( $this->lazy_load_placeholder( $settings, 'grouped-product' ) ){
			return;
		}
		
		$args = array(
			'post_type'				=> 'product'
			,'post_status' 			=> 'publish'
			,'posts_per_page' 		=> 1
			,'orderby' 				=> 'date'
			,'order' 				=> 'desc'
			,'meta_query' 			=> WC()->query->get_meta_query()
			,'tax_query'           	=> WC()->query->get_tax_query()
		);
		
		$args['tax_query'][] = array(
									'taxonomy'	=> 'product_type'
									,'field'	=> 'slug'
									,'terms'	=> array('grouped')
								);

		if( !empty($specific_product) ){
			$args['post__in'] = array($specific_product);
		}
		
		global $post, $product;

		$products = new WP_Query( $args );
	
		$classes = array('ts-grouped-product-wrapper ts-shortcode ts-product woocommerce product');

		if( $products->have_posts() ){
			$products->the_post();
			$product = wc_get_product( $post->ID );
			$parent_product_id = $product->get_id();
			
			$products = array_filter( array_map( 'wc_get_product', $product->get_children() ), 'wc_products_array_filter_visible_grouped' );
			if( $products ){
			?>
			<div class="<?php echo esc_attr(implode(' ', $classes)); ?>">
				<?php if( $title ){ ?>
				<header class="shortcode-heading-wrapper">
					<h3 class="shortcode-title">
						<?php echo esc_html($title); ?>
					</h3>
				</header>
				<?php } ?>
				
				<div class="summary">	
					<form class="cart grouped_form" action="<?php echo esc_url( apply_filters( 'woocommerce_add_to_cart_form_action', $product->get_permalink() ) ); ?>" method="post" enctype='multipart/form-data'>
						<div class="items">
						<?php
						$total = 0;
						$count = 0;
						foreach( $products as $product_child ){
							if( !$product_child->is_in_stock() || $product_child->get_type() != 'simple' ){
								continue;
							}
							if( $show_total_price ){
								$total += $product_child->get_price();
							}
							$count++;
							
							$post = get_post( $product_child->get_id() );
							wc_setup_product_data( $post );
							?>
							<div class="item">
								<?php if( $show_image ){ ?>
								<div class="product-thumbnail">
									<?php 
									if( function_exists('TS_WISHLIST') && TS_WISHLIST()->enable_wishlist('loop') ){
										TS_WISHLIST()->add_wishlist_button();
									}
									
									echo $product_child->get_image();
									?>
								</div>
								<?php } ?>
								
								<div class="product-meta">
									<?php 
									if( $show_brands && function_exists('cozycorner_template_loop_brands') ){ 
										cozycorner_template_loop_brands(); 
									}
									?>
									
									<?php if( $show_title ){ ?>
									<div class="product-title">
										<?php
										if( $product_child->is_visible() ){
											echo '<a href="' . esc_url( $product_child->get_permalink() ) . '">' . $product_child->get_name() . '</a>';
										}
										else{
											echo $product_child->get_name();
										}
										?>
									</div>
									<?php } ?>
									
									<?php if( $show_price ){ ?>
									<div class="product-price">
										<?php echo $product_child->get_price_html(); ?>
									</div>
									<?php } ?>
									
									<div class="hidden-fields hidden" style="display: none">
									<?php
										woocommerce_quantity_input(
												array(
													'input_name'  	=> 'quantity[' . $product_child->get_id() . ']'
													,'input_value' 	=> '1'
												)
											);
									?>
									</div>
								</div>
							</div>
							<?php } ?>
						</div>
						
						<?php
						if( $show_add_to_cart ){
						?>
							<input type="hidden" name="add-to-cart" value="<?php echo esc_attr( $parent_product_id ); ?>" />
							<button type="submit" class="single_add_to_cart_button button alt"><?php printf( _n('Add all <span class="count">%s</span> product to cart', 'Add all <span class="count">%s</span> products to cart', $count, 'themesky'), $count ); ?></button>
						<?php
						}
						
						if( $show_total_price ){
						?>
							<div class="total-wrapper">
								<span class="total-label"><?php esc_html_e('Total', 'themesky') ?></span>
								<span class="total-amount"><?php echo wc_price($total); ?></span>
							</div>
						<?php } ?>
					</form>
				</div>
			</div>
			<?php
			}
		}
		
		wp_reset_postdata();
	}
}

$widgets_manager->register( new TS_Elementor_Widget_Grouped_Product() );