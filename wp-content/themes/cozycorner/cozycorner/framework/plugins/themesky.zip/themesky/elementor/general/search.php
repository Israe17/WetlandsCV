<?php
use Elementor\Controls_Manager;

class TS_Elementor_Widget_Search extends TS_Elementor_Widget_Base{
	public function get_name(){
        return 'ts-search';
    }
	
	public function get_title(){
        return esc_html__( 'TS Search Form', 'themesky' );
    }
	
	public function get_categories(){
        return array( 'ts-elements', 'general' );
    }
	
	public function get_icon(){
		return 'eicon-search';
	}
	
	protected function register_controls(){
		$this->start_controls_section(
            'section_general'
            ,array(
                'label' 	=> esc_html__( 'General', 'themesky' )
                ,'tab'   	=> Controls_Manager::TAB_CONTENT
            )
        );
		
		$this->add_control(
            'keywords'
            ,array(
                'label' 		=> esc_html__( 'Popular Keywords For Search', 'themesky' )
                ,'type' 		=> Controls_Manager::TEXTAREA
                ,'default' 		=> ''
                ,'rows' 		=> 10
                ,'description' 	=> esc_html__( 'A comma separated list of keywords. Ex: table, sofa and couches, chair, lighting', 'themesky' )
            )
        );
		
		$this->end_controls_section();
		
		$this->start_controls_section(
            'section_style'
            ,array(
                'label' 	=> esc_html__( 'Styles', 'themesky' )
                ,'tab'   	=> Controls_Manager::TAB_STYLE
            )
        );
		
		$this->add_control(
            'text_color'
            ,array(
                'label'     	=> esc_html__( 'Popular Search Color', 'themesky' )
                ,'type'     	=> Controls_Manager::COLOR
				,'default'  	=> ''
				,'selectors'	=> array(
					'{{WRAPPER}} .ts-search-form-widget .popular-search > a' => 'color: {{VALUE}}'
				)
            )
        );
		
		$this->add_control(
            'text_color_hover'
            ,array(
                'label'     	=> esc_html__( 'Popular Search Color Hover', 'themesky' )
                ,'type'     	=> Controls_Manager::COLOR
				,'default'  	=> ''
				,'selectors'	=> array(
					'{{WRAPPER}} .ts-search-form-widget .popular-search > a:hover' => 'color: {{VALUE}}'
				)
            )
        );
		
		$this->add_control(
			'ts_hr_1'
			,array(
                'type' 		=> Controls_Manager::DIVIDER
            )
		);
		
		$this->add_control(
            'input_styles'
            ,array(
                'label'     	=> esc_html__( 'Input', 'themesky' )
                ,'type' 		=> Controls_Manager::HEADING		
                ,'description' 	=> ''
            )
        );
		
		$this->add_control(
            'input_text_color'
            ,array(
                'label'     	=> esc_html__( 'Text Color', 'themesky' )
                ,'type'     	=> Controls_Manager::COLOR
				,'default'  	=> ''
				,'selectors'	=> array(
					'{{WRAPPER}} .ts-search-form-widget .search-table .search-field input[type="text"]' => 'color: {{VALUE}};'
				)
            )
        );
		
		$this->add_control(
            'input_background_color'
            ,array(
                'label'     	=> esc_html__( 'Background Color', 'themesky' )
                ,'type'     	=> Controls_Manager::COLOR
				,'default'  	=> ''
				,'selectors'	=> array(
					'{{WRAPPER}} .ts-search-form-widget .search-table .search-field input[type="text"]' => 'background: {{VALUE}}'
				)
            )
        );
		
		$this->add_control(
            'input_border_color'
            ,array(
                'label'     	=> esc_html__( 'Border Color', 'themesky' )
                ,'type'     	=> Controls_Manager::COLOR
				,'default'  	=> ''
				,'selectors'	=> array(
					'{{WRAPPER}} .ts-search-form-widget .search-table .search-field input[type="text"]' => 'border-color: {{VALUE}}'
				)
            )
        );
		
		$this->add_control(
			'ts_hr_2'
			,array(
                'type' 		=> Controls_Manager::DIVIDER
            )
		);
		
		$this->add_control(
            'button_styles'
            ,array(
                'label'     	=> esc_html__( 'Button', 'themesky' )
                ,'type' 		=> Controls_Manager::HEADING		
                ,'description' 	=> ''
            )
        );
		
		$this->start_controls_tabs(
			'style_tabs'
		);
		
		$this->start_controls_tab(
			'style_normal_tab'
			,array(
				'label' 		=> esc_html__( 'Normal', 'themesky' )
			)
		);
		
		$this->add_control(
            'button_text_color'
            ,array(
                'label'     	=> esc_html__( 'Text Color', 'themesky' )
                ,'type'     	=> Controls_Manager::COLOR
				,'default'  	=> ''
				,'selectors'	=> array(
					'{{WRAPPER}} .ts-search-form-widget .search-table .search-button' => 'color: {{VALUE}}'
				)
            )
        );
		
		$this->add_control(
            'button_background_color'
            ,array(
                'label'     	=> esc_html__( 'Background Color', 'themesky' )
                ,'type'     	=> Controls_Manager::COLOR
				,'default'  	=> ''
				,'selectors'	=> array(
					'{{WRAPPER}} .ts-search-form-widget .search-table .search-button' => 'background: {{VALUE}}'
				)
            )
        );
		
		$this->add_control(
            'button_border_color'
            ,array(
                'label'     	=> esc_html__( 'Border Color', 'themesky' )
                ,'type'     	=> Controls_Manager::COLOR
				,'default'  	=> ''
				,'selectors'	=> array(
					'{{WRAPPER}} .ts-search-form-widget .search-table .search-button' => 'border-color: {{VALUE}}'
				)
            )
        );
		
		$this->end_controls_tab();
		
		$this->start_controls_tab(
			'style_hover_tab'
			,array(
				'label' 		=> esc_html__( 'Hover', 'themesky' )
			)
		);
		
		$this->add_control(
            'button_text_hover'
            ,array(
                'label'     	=> esc_html__( 'Text Color', 'themesky' )
                ,'type'     	=> Controls_Manager::COLOR
				,'default'  	=> ''
				,'selectors'	=> array(
					'{{WRAPPER}} .ts-search-form-widget .search-table .search-button:hover' => 'color: {{VALUE}}'
				)
            )
        );
		
		$this->add_control(
            'button_background_hover'
            ,array(
                'label'     	=> esc_html__( 'Background Color', 'themesky' )
                ,'type'     	=> Controls_Manager::COLOR
				,'default'  	=> ''
				,'selectors'	=> array(
					'{{WRAPPER}} .ts-search-form-widget .search-table .search-button:hover' => 'background: {{VALUE}}'
				)
            )
        );
		
		$this->add_control(
            'button_border_hover'
            ,array(
                'label'     	=> esc_html__( 'Border Color', 'themesky' )
                ,'type'     	=> Controls_Manager::COLOR
				,'default'  	=> ''
				,'selectors'	=> array(
					'{{WRAPPER}} .ts-search-form-widget .search-table .search-button:hover' => 'border-color: {{VALUE}}'
				)
            )
        );
		
		$this->end_controls_tab();
		
		$this->end_controls_tabs();
		
		$this->end_controls_section();
	}
	
	protected function render(){
		$settings = $this->get_settings_for_display();
		
		$default = array(
			'title'				=> ''
			,'keywords'			=> ''
		);
		
		$settings = wp_parse_args( $settings, $default );
		
		extract( $settings );
		
		?>
		<div class="ts-search-form-widget ts-shortcode">
			<?php if( $title ){ ?>
			<header class="shortcode-heading-wrapper">
				<h3 class="shortcode-title"><?php echo esc_html( $title ); ?></h3>
			</header>
			<?php } ?>
			
			<?php get_search_form(); ?>
			
			<?php 
			if( $keywords ){
				$keywords = array_map( 'trim', explode(',', $keywords) );
				$base_url = home_url( '/' );
				if( class_exists('WooCommerce') ){
					$base_url = add_query_arg('post_type', 'product', $base_url);
				}
				?>
				<div class="popular-search">
					<?php
					foreach( $keywords as $keyword ){
						$search_url = add_query_arg('s', $keyword, $base_url);
						?>
						<a href="<?php echo esc_url($search_url); ?>"><?php echo esc_html($keyword); ?></a>
						<?php 
					}
					?>
				</div>
				<?php
			}
			?>
		</div>
		<?php
	}
}

$widgets_manager->register( new TS_Elementor_Widget_Search() );