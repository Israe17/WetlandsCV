<?php
use Elementor\Controls_Manager;

class TS_Elementor_Widget_Page_Title extends TS_Elementor_Widget_Base{
	public function get_name(){
        return 'ts-page-title';
    }
	
	public function get_title(){
        return esc_html__( 'TS Page Title', 'themesky' );
    }
	
	public function get_categories(){
        return array( 'ts-elements', 'general' );
    }
	
	public function get_icon(){
		return 'eicon-site-title';
	}
	
	protected function register_controls(){
		$this->start_controls_section(
            'section_general'
            ,array(
                'label' 	=> esc_html__( 'General', 'themesky' )
                ,'tab'   	=> Controls_Manager::TAB_CONTENT
            )
        );
		
		$this->add_control(
            'info'
            ,array(
                'type' 			=> Controls_Manager::ALERT
                ,'alert_type' 	=> 'info'
				,'content' 		=> esc_html__( 'This is a dynamic element. Its content depends on where it is located', 'themesky' )
            )
        );
		
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type()
			,array(
				'label' 			=> esc_html__( 'Typography', 'themesky' )
				,'name' 			=> 'heading_typo'
				,'selector'			=> '{{WRAPPER}} .entry-title'
			)
		);
		
		$this->add_control(
            'heading_text_color'
            ,array(
                'label'     	=> esc_html__( 'Text Color', 'themesky' )
                ,'type'     	=> Controls_Manager::COLOR
				,'default'  	=> ''
				,'selectors'	=> array(
					'{{WRAPPER}} .entry-title' => 'color: {{VALUE}}'
				)
            )
        );
		
		$this->add_responsive_control(
            'text_align'
            ,array(
                'label' 		=> esc_html__( 'Text Align', 'themesky' )
                ,'type' 		=> Controls_Manager::CHOOSE
				,'options' => array(
					'start' => array(
						'title' => esc_html__( 'Left', 'themesky' )
						,'icon' => 'eicon-text-align-left'
					)
					,'center' => array(
						'title' => esc_html__( 'Center', 'themesky' )
						,'icon' => 'eicon-text-align-center'
					)
					,'end' => array(
						'title' => esc_html__( 'Right', 'themesky' )
						,'icon' => 'eicon-text-align-right'
					)
				)
				,'description' 	=> ''
				,'selectors' => array(
					'{{WRAPPER}} .entry-title' => 'text-align: {{VALUE}}'
				)
            )
        );
		
		$this->end_controls_section();
	}
	
	protected function render(){
		switch( true ){
			case is_day():
				$page_title = esc_html__( 'Day: ', 'themesky' ) . get_the_date();
			break;
			case is_month():
				$page_title = esc_html__( 'Month: ', 'themesky' ) . get_the_date( esc_html_x( 'F Y', 'monthly archives date format', 'themesky' ) );
			break;
			case is_year():
				$page_title = esc_html__( 'Year: ', 'themesky' ) . get_the_date( esc_html_x( 'Y', 'yearly archives date format', 'themesky' ) );
			break;
			case is_search():
				$page_title = esc_html__( 'Search Results for: ', 'themesky' ) . get_search_query();
			break;
			case is_tag():
				$page_title = esc_html__( 'Tag: ', 'themesky' ) . single_tag_title( '', false );
			break;
			case is_category():
				$page_title = esc_html__( 'Category: ', 'themesky' ) . single_cat_title( '', false );
			break;
			case is_404():
				$page_title = '';
			break;
			case is_tax( get_object_taxonomies('product') ):
				$page_title = single_term_title( '', false );
			break;
			case is_post_type_archive('product'):
				$shop_page_id = wc_get_page_id( 'shop' );
				$page_title   = get_the_title( $shop_page_id );
			break;
			default:
				$page_title = get_the_title();
			break;
		}
		
		echo '<h1 class="heading-title page-title entry-title">' . esc_html($page_title) . '</h1>';
	}
}

$widgets_manager->register( new TS_Elementor_Widget_Page_Title() );