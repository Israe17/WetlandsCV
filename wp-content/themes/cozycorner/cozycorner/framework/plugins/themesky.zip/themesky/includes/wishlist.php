<?php
class TS_Wishlist{
	protected static $_instance = null;
	
	public $wishlist = null;
	public $wishlist_url = null;
	public $cookie_name = 'ts_wishlist';
	public $user_meta_key = 'ts_wishlist';
	
	function __construct(){
		add_action('init', array($this, 'set_cookie_name'));
		add_action('init', array($this, 'add_hook'), 20);
		add_action('init', array($this, 'register_ajax'), 20);
		
		add_action('wp_enqueue_scripts', array($this, 'register_scripts'));
		
		add_shortcode('ts_wishlist', array($this, 'wishlist_table'));
	}
	
	public static function instance(){
		if( is_null( self::$_instance ) ){
			self::$_instance = new self();
		}
		return self::$_instance;
	}
	
	function set_cookie_name(){
		$language = $this->get_current_language();
		if( $language != 'default' ){
			$this->cookie_name = $this->cookie_name . '_' . $language;
		}
	}
	
	function enable_wishlist( $type = 'both'){ /* both / loop / single */
		$enabled = false;
		if( function_exists('cozycorner_get_theme_options') ){
			switch( $type ){
				case 'both':
					if( cozycorner_get_theme_options('ts_wishlist_show_in_loop') || cozycorner_get_theme_options('ts_wishlist_show_on_product_page') ){
						$enabled = true;
					}
				break;
				case 'loop':
					if( cozycorner_get_theme_options('ts_wishlist_show_in_loop') ){
						$enabled = true;
					}
				break;
				case 'single':
					if( cozycorner_get_theme_options('ts_wishlist_show_on_product_page') ){
						$enabled = true;
					}
				break;
			}
		}
		
		return $enabled;
	}
	
	function register_scripts(){
		if( !$this->enable_wishlist('both') ){
			return;
		}
		
		wp_enqueue_script( 'ts-wishlist', plugin_dir_url( __DIR__ ) . 'js/wishlist.js', array('jquery'), THEMESKY_VERSION, true );
		
		$remove_wishlist_after_addedtocart = 1;
		if( function_exists('cozycorner_get_theme_options') && !cozycorner_get_theme_options('ts_wishlist_remove_after_added_to_cart') ){
			$remove_wishlist_after_addedtocart = 0;
		}
		
		$has_cache = !is_user_logged_in() && ( defined('W3TC') || defined('LSCWP_V') || defined('SiteGround_Optimizer\VERSION') || defined('WP_ROCKET_VERSION') || apply_filters('ts_wishlist_has_cache', false) );
		
		$data = array(
			'ajax_nonce'						=> wp_create_nonce( 'ts-wishlist-nonce' )
			,'wishlist_url'						=> $this->get_wishlist_url()
			,'remove_wishlist_after_addedtocart'=> $remove_wishlist_after_addedtocart
			,'added_to_cart_message' 			=> '<div class="woocommerce-notices-wrapper"><div class="woocommerce-message" role="alert">' . esc_html__('Product added to cart successfully', 'themesky') . '</div></div>'
			,'cookie_alert' 					=> esc_html__('This feature is only available if your browser cookies are enabled', 'themesky')
			,'wait_alert' 						=> esc_html__('Please wait until the previous task is finished!', 'themesky')
			,'cookie_name'						=> $this->cookie_name
			,'cookie_path'						=> defined('COOKIEPATH') ? COOKIEPATH : '/'
			,'cookie_domain'					=> defined('COOKIE_DOMAIN') ? COOKIE_DOMAIN : ''
			,'cookie_secure'					=> is_ssl() ? 1 : 0
			,'has_cache'						=> $has_cache ? 1 : 0
		);
		wp_localize_script( 'ts-wishlist', 'ts_wishlist_params', $data );
	}
	
	function add_hook(){
		if( $this->enable_wishlist('loop') ){
			add_action( 'woocommerce_after_shop_loop_item_title', array($this, 'add_wishlist_button'), 10001 );
			add_action( 'woocommerce_after_shop_loop_item_2', array($this, 'add_wishlist_button'), 50 );
		}
		
		if( $this->enable_wishlist('single') ){
			add_action( 'woocommerce_single_product_summary', array($this, 'add_single_wishlist_button'), 31 );
		}
	}
	
	function register_ajax(){
		add_action('wp_ajax_ts_add_to_wishlist', array($this, 'add_to_wishlist'));
		add_action('wp_ajax_nopriv_ts_add_to_wishlist', array($this, 'add_to_wishlist'));
		
		add_action('wp_ajax_ts_remove_from_wishlist', array($this, 'remove_from_wishlist'));
		add_action('wp_ajax_nopriv_ts_remove_from_wishlist', array($this, 'remove_from_wishlist'));
	}
	
	function get_current_language(){
		return apply_filters('wpml_current_language', 'default');
	}
	
	function get_wishlist_from_db(){
		if( is_user_logged_in() ){
			$wishlist = get_user_meta( get_current_user_id(), $this->user_meta_key, true );
			if( $wishlist && is_array($wishlist) ){
				$language = $this->get_current_language();
				if( !isset($wishlist[$language]) || !is_array($wishlist[$language]) ){
					return array();
				}
				else{
					return array_map('absint', $wishlist[$language]);
				}
			}
			return array();
		}
		return false;
	}
	
	function get_wishlist(){
		if( !is_null($this->wishlist) ){
			return $this->wishlist;
		}
		
		/* Get wishlist from db if logged in */
		$this->wishlist = $this->get_wishlist_from_db();
		if( $this->wishlist !== false ){
			return $this->wishlist;
		}
		
		/* Get wishlist from cookies if not logged in */
		if( isset($_COOKIE[$this->cookie_name]) ){
			$this->wishlist = $_COOKIE[$this->cookie_name];
			if( !$this->wishlist ){
				$this->wishlist = array();
			}
			else{
				$this->wishlist = array_map('absint', explode(',', $this->wishlist));
			}
		}
		else{
			$this->wishlist = array();
		}
		
		return $this->wishlist;
	}
	
	function set_wishlist_to_db(){
		if( is_user_logged_in() ){
			$wishlist = get_user_meta( get_current_user_id(), $this->user_meta_key, true );
			if( !is_array($wishlist) ){
				$wishlist = array();
			}
			$wishlist[$this->get_current_language()] = $this->wishlist;
			update_user_meta( get_current_user_id(), $this->user_meta_key, $wishlist );
			return true;
		}
		return false;
	}
	
	function set_wishlist( $wishlist ){
		$this->wishlist = $wishlist;
		
		/* Save wishlist to db if logged in */
		if( $this->set_wishlist_to_db() !== false ){
			return;
		}
		
		/* Save wishlist to cookies if not logged in */
		$options = array(
					'expires'   => time() + 60 * 60 * 24 * 7 /* 7 days */
					,'secure'   => is_ssl()
					,'path'     => defined('COOKIEPATH') ? COOKIEPATH : '/'
					,'domain'   => defined('COOKIE_DOMAIN') ? COOKIE_DOMAIN : ''
					,'httponly' => false
				);
				
		setcookie( $this->cookie_name, implode(',', $wishlist), $options );
	}
	
	function get_wishlist_url(){
		if( !is_null($this->wishlist_url) ){
			return $this->wishlist_url;
		}
		
		$this->wishlist_url = '';
		if( function_exists('cozycorner_get_theme_options') ){
			$page_id = cozycorner_get_theme_options('ts_wishlist_page');
			if( $page_id ){
				$this->wishlist_url = get_the_permalink( $page_id );
			}
		}
		return $this->wishlist_url;
	}
	
	function get_wishlist_count(){
		return count( $this->get_wishlist() );
	}
	
	function get_refreshed_fragments( $send_json = false, $extra_data = array() ){
		$data = array(
			'fragments'	=> array()
		);
		
		if( function_exists('cozycorner_tini_wishlist') ){
			$data['fragments']['.tini-wishlist'] = cozycorner_tini_wishlist();
		}
		
		if( !empty($_POST['has_table']) ){
			$data['fragments']['.ts-wishlist-table-wrapper'] = $this->wishlist_table();
		}
		
		if( $extra_data ){
			$data = array_merge( $data, $extra_data );
		}
		
		if( $send_json ){
			wp_send_json( $data );
		}
		else{
			return $data;
		}
	}
	
	function verify_nonce( $post_key = 'nonce', $nonce_key = 'ts-wishlist-nonce' ){
		if( isset($_POST[$post_key]) && wp_verify_nonce($_POST[$post_key], $nonce_key) ){
			return true;
		}
		die( esc_html__('Security check', 'themesky') );
	}
	
	function is_product_in_wishlist( $product_id ){
		if( in_array( $product_id, $this->get_wishlist() ) ){
			return true;
		}
		
		return false;
	}
	
	function add_to_wishlist(){
		if( isset($_POST['product_id']) && $this->verify_nonce() ){
			$product_id = absint($_POST['product_id']);
			$wishlist = $this->get_wishlist();
			
			if( in_array( $product_id, $wishlist ) ){
				$this->get_refreshed_fragments( true, array( 'message' => esc_html__('Already in wishlist', 'themesky') ) );
			}
			else{
				$wishlist[] = $product_id;
				$this->set_wishlist($wishlist);
				$this->get_refreshed_fragments( true, array( 'message' => esc_html__('Added to wishlist', 'themesky') ) );
			}
		}
	}
	
	function remove_from_wishlist(){
		if( isset($_POST['product_id']) && $this->verify_nonce() ){
			$product_id = absint($_POST['product_id']);
			$wishlist = $this->get_wishlist();
			
			if( !in_array( $product_id, $wishlist ) ){
				$this->get_refreshed_fragments( true, array( 'message' => esc_html__('Product is not in wishlist', 'themesky') ) );
			}
			else{
				unset( $wishlist[array_search( $product_id, $wishlist )] );
				$this->set_wishlist($wishlist);
				$this->get_refreshed_fragments( true, array( 'message' => esc_html__('Removed from wishlist', 'themesky') ) );
			}
		}
	}
	
	function remove_unavailable_products_from_wishlist( $unavailable_products ){
		if( is_user_logged_in() ){
			$wishlist = $this->get_wishlist();
			$wishlist = array_diff($wishlist, $unavailable_products);
			$this->set_wishlist($wishlist);
		}
	}
	
	function get_action_after_added(){
		$action = 'remove';
		if( function_exists('cozycorner_get_theme_options') && cozycorner_get_theme_options('ts_wishlist_show_link_after_added') ){
			$action = 'link';
		}
		return $action;
	}
	
	function add_wishlist_button( $text = '' ){
		global $product;
		if( !$text ){
			$text = __('Wishlist', 'themesky');
		}
		
		$added = $this->is_product_in_wishlist( $product->get_id() );
		$action = $this->get_action_after_added();
		
		$url = '#';
		$classes = array('ts-add-to-wishlist');
		$classes[] = $action . '-after-added';
		
		if( $added ){
			$classes[] = 'added';
			
			if( $action == 'link' ){
				$url = $this->get_wishlist_url();
			}
		}
		?>
		<div class="button-in wishlist">
			<a href="<?php echo esc_url( $url ); ?>" class="<?php echo esc_attr( implode(' ', $classes) ); ?>" data-id="<?php echo esc_attr( $product->get_id() ); ?>">
				<span class="ts-tooltip button-tooltip"><?php echo esc_html( $text ); ?></span>
			</a>
		</div>
		<?php
	}
	
	function add_single_wishlist_button(){
		$this->add_wishlist_button( __('Add to wishlist', 'themesky') );
	}
	
	function wishlist_table(){
		if( !class_exists('WooCommerce') ){
			return;
		}
		
		$wishlist = $this->get_wishlist();
		
		$classes = array('ts-wishlist-table-wrapper woocommerce');
		
		if( empty($wishlist) ){
			$classes[] = 'empty-wishlist';
		}
		
		global $product;
		$unavailable_products = array();
		
		$enable_addtocart = function_exists('cozycorner_get_theme_options') && !cozycorner_get_theme_options('ts_enable_catalog_mode') ? true : false;
		
		ob_start();
		?>
		<div class="<?php echo esc_attr( implode(' ', $classes) ); ?>">
			<div class="heading-row">
				<span class="product-remove"></span>
				<span class="product-thumbnail"></span>
				<span class="product-name"><?php esc_html_e('Product name', 'themesky'); ?></span>
				<span class="product-price"><?php esc_html_e('Price', 'themesky'); ?></span>
				<span class="product-stock-status"><?php esc_html_e('Stock status', 'themesky'); ?></span>
				<?php if( $enable_addtocart ){ ?>
				<span class="product-add-to-cart"></span>
				<?php } ?>
			</div>
			<div class="items">
				<?php if( empty($wishlist) ){ ?>
				<div class="item"><span><?php esc_html_e('No products added to the wishlist', 'themesky'); ?></span></div>
				<?php
				} else {
					foreach( $wishlist as $product_id ){
						$product = wc_get_product( $product_id );
						if( ! is_a( $product, WC_Product::class ) || ! $product->is_visible() ){
							$unavailable_products[] = $product_id;
							continue;
						}
						$availability = $product->get_availability();
				?>
					<div class="item wishlist-item">
						<span class="product-remove">
							<a href="#" class="ts-remove-from-wishlist added" data-id="<?php echo esc_attr($product_id); ?>"><?php esc_html_e('Remove', 'themesky'); ?></a>
						</span>
						<span class="product-thumbnail">
							<a href="<?php echo esc_url( $product->get_permalink() ); ?>">
								<?php echo wp_kses_post( $product->get_image() ); ?>
							</a>
						</span>
						<span class="product-name">
							<a href="<?php echo esc_url( $product->get_permalink() ); ?>">
								<?php echo wp_kses_post( $product->get_name() ); ?>
							</a>
						</span>
						<span class="product-price">
							<?php echo wp_kses_post( $product->get_price_html() ); ?>
						</span>
						<span class="product-stock-status">
							<span class="<?php echo esc_attr( $availability['class'] ); ?>"><?php echo esc_html( $availability['availability'] ? $availability['availability'] : __('In stock', 'themesky') ); ?></span>
						</span>
						<?php if( $enable_addtocart ){ ?>
						<span class="product-add-to-cart">
							<?php woocommerce_template_loop_add_to_cart(); ?>
						</span>
						<?php } ?>						
					</div>
				<?php
					}
				}
				?>
			</div>
		</div>
		<?php
		
		if( $unavailable_products ){
			$this->remove_unavailable_products_from_wishlist( $unavailable_products );
		}
		
		wp_reset_postdata();
		
		return ob_get_clean();
	}
}

function TS_WISHLIST(){
	return TS_Wishlist::instance();
}
TS_WISHLIST();