<?php
use Elementor\Controls_Manager;

class TS_Elementor_Widget_Banner extends TS_Elementor_Widget_Base{
	public function get_name(){
        return 'ts-banner';
    }
	
	public function get_title(){
        return esc_html__( 'TS Banner', 'themesky' );
    }
	
	public function get_categories(){
        return array( 'ts-elements', 'general' );
    }
	
	public function get_icon(){
		return 'eicon-image';
	}
	
	protected function register_controls(){
		
		$this->start_controls_section(
            'section_bg'
            ,array(
                'label' 	=> esc_html__( 'General', 'themesky' )
                ,'tab'   	=> Controls_Manager::TAB_CONTENT
            )
        );
		
		$this->add_control(
            'img_bg'
            ,array(
                'label' 		=> esc_html__( 'Background Image', 'themesky' )
                ,'type' 		=> Controls_Manager::MEDIA
                ,'default' 		=> array( 
					'id' 		=> ''
					,'url' 		=> '' 
				)		
                ,'description' 	=> ''
            )
        );
		
		$this->add_control(
            'bg_image_device'
            ,array(
                'label' 		=> esc_html__( 'Background Image Device', 'themesky' )
                ,'type' 		=> Controls_Manager::SELECT
                ,'default' 		=> 'none'
				,'options'		=> array(
					'none'					=> esc_html__( 'None', 'themesky' )
					,'img-mobile-tablet'	=> esc_html__( 'Mobile & Tablet', 'themesky' )
					,'img-mobile-tablet-p'	=> esc_html__( 'Mobile & Tablet Portrait', 'themesky' )
					,'img-tablet'			=> esc_html__( 'Tablet Only', 'themesky' )
					,'img-tablet-portrait'	=> esc_html__( 'Tablet Portrait Only', 'themesky' )
					,'img-mobile'			=> esc_html__( 'Mobile Only', 'themesky' )
					
				)			
                ,'description' 	=> ''
            )
        );
		
		$this->add_control(
            'img_bg_mobile'
            ,array(
                'type' 			=> Controls_Manager::MEDIA
                ,'default' 		=> array( 'id' => '', 'url' => '' )		
                ,'description' 	=> esc_html__( 'Use this image for device. If not selected, it will show image above', 'themesky' )
				,'condition'	=> array( 'bg_image_device!' => 'none' )
            )
        );
		
		$this->add_control(
            'link'
            ,array(
                'label'     		=> esc_html__( 'Banner Link', 'themesky' )
                ,'type'     		=> Controls_Manager::URL
				,'default'  		=> array( 'url' => '', 'is_external' => true, 'nofollow' => true )
				,'show_external'	=> true
				,'description' 		=> ''
            )
        );
		
		$this->add_control(
            'link_apply'
            ,array(
                'label' 		=> esc_html__( 'Apply Link On', 'themesky' )
                ,'type' 		=> Controls_Manager::SELECT
                ,'default' 		=> 'full'
				,'options'		=> array(
									'full'				=> esc_html__('Full Banner', 'themesky')
									,'button' 			=> esc_html__('Only Button', 'themesky')
								)
                ,'description' 	=> ''
				,'label_block' 	=> true
            )
        );
		
		$this->add_responsive_control(
			'border_radius'
			,array(
				'type' => Controls_Manager::DIMENSIONS
				,'label' => esc_html__( 'Banner Border Radius', 'themesky' )
				,'size_units' => array( 'px', '%' )
				,'default' => array(
					'top' => 5
					,'right' => 5
					,'bottom' => 5
					,'left' => 5
					,'unit' => 'px'
					,'isLinked' => true
				)
				,'selectors' => array(
					'{{WRAPPER}} .ts-banner, {{WRAPPER}} .banner-bg img' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
				)
			)
		);
		
		$this->add_control(
			'ts_hr_1'
			,array(
                'type' 		=> Controls_Manager::DIVIDER
            )
		);

		$this->add_control(
            'heading_title'
            ,array(
                'label' 		=> esc_html__( 'Heading', 'themesky' )
                ,'type' 		=> Controls_Manager::TEXT
                ,'default' 		=> ''		
                ,'description' 	=> ''
            )
        );
		
		$this->add_control(
            'description'
            ,array(
                'label' 		=> esc_html__( 'Description', 'themesky' )
                ,'type' 		=> Controls_Manager::TEXT
                ,'default' 		=> ''		
                ,'description' 	=> ''
            )
        );

		$this->add_control(
            'button_text'
            ,array(
                'label'     	=> esc_html__( 'Button Text', 'themesky' )
                ,'type' 		=> Controls_Manager::TEXT
                ,'default' 		=> ''		
                ,'description' 	=> esc_html__( 'Leave blank if you don\'t want to show button', 'themesky' )
            )
        );
		
		$this->add_control(
			'button_icon'
			,array(
				'label' => esc_html__( 'Button Icon', 'themesky' )
				,'type' => Controls_Manager::ICONS
				,'fa4compatibility' => 'icon'
				,'skin' => 'inline'
				,'label_block' => false
			)
		);
		
		$this->add_responsive_control(
            'button_pos'
            ,array(
                'label' 		=> esc_html__( 'Button Position', 'themesky' )
                ,'type' 		=> Controls_Manager::CHOOSE
				,'default' 		=> 'top'
				,'options' 		=> array(
					'top' => array(
						'title' => esc_html__( 'Top', 'themesky' )
						,'icon' => 'eicon-v-align-top'
					)
					,'bottom' => array(
						'title' => esc_html__( 'Bottom', 'themesky' )
						,'icon' => 'eicon-v-align-bottom'
					)
				)
            )
        );
		
		$this->add_control(
			'ts_hr_3'
			,array(
                'type' 		=> Controls_Manager::DIVIDER
            )
		);
		
		$this->add_control(
            'style_effect'
            ,array(
                'label' 		=> esc_html__( 'Banner Effect', 'themesky' )
                ,'type' 		=> Controls_Manager::SELECT
                ,'default' 		=> 'eff-zoom-in'
				,'options'		=> array(
									'eff-zoom-in'				=> esc_html__('Zoom in', 'themesky')
									,'eff-grow-rotate' 			=> esc_html__('Grow Rotate', 'themesky')
									,'eff-flash' 				=> esc_html__('Flash', 'themesky')
									,'no-effect' 				=> esc_html__('None', 'themesky')
								)
                ,'description' 	=> ''
				,'label_block' 	=> true
            )
        );
		
		$this->end_controls_section();
		
		$this->start_controls_section(
            'section_style'
            ,array(
                'label' 	=> esc_html__( 'Banner Content', 'themesky' )
                ,'tab'   	=> Controls_Manager::TAB_STYLE
            )
        );
		
		$this->add_responsive_control(
			'content_width'
			,array(
				'label' 	=> esc_html__( 'Content Max Width', 'themesky' )
				,'type' 	=> Controls_Manager::SLIDER
				,'range' 	=> array(
					'px'	=> array(
						'min' 	=> 0
						,'max' 	=> 1000
					)
				)
				,'size_units' 	=> array( 'px', '%' )
				,'default' 		=> array( 'unit' => 'px', 'size' => 1000 )
				,'description' 	=> esc_html__( 'Please not that Content Max Width included Content Padding', 'themesky' )
				,'selectors' 	=> array(
					'{{WRAPPER}} .box-content .content-text' => 'max-width: {{SIZE}}{{UNIT}};'
				)
			)
		);

		$this->add_responsive_control(
			'content_gap'
			,array(
				'label' 	=> esc_html__( 'Content Gap', 'themesky' )
				,'type' 	=> Controls_Manager::SLIDER
				,'range' 	=> array(
					'px'	=> array(
						'min' 	=> 0
						,'max' 	=> 100
					)
				)
				,'size_units' 	=> array( 'px', '%', 'em', 'rem')
				,'default' 		=> array( 'unit' => 'px', 'size' => 20 )
				,'selectors' => array(
					'{{WRAPPER}} .box-content .content-text'=> 'gap: {{SIZE}}{{UNIT}};'
				)
			)
		);
		
		$this->add_responsive_control(
			'content_padding'
			,array(
				'type' => Controls_Manager::DIMENSIONS
				,'label' => esc_html__( 'Content Padding', 'themesky' )
				,'size_units' => array( 'px', '%', 'em', 'rem' )
				,'default' => array(
					'top' => 50
					,'right' => 50
					,'bottom' => 50
					,'left' => 50
					,'unit' => 'px'
					,'isLinked' => true
				)
				,'selectors' => array(
					'{{WRAPPER}} .box-content .content-text' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
				)
			)
		);
		
		$this->add_responsive_control(
            'h_align'
            ,array(
                'label' 		=> esc_html__( 'Horizontal Align', 'themesky' )
                ,'type' 		=> Controls_Manager::CHOOSE
				,'default' 		=> 'flex-start'
				,'options' 		=> array(
					'flex-start' => array(
						'title' => esc_html__( 'Top', 'themesky' )
						,'icon' => 'eicon-h-align-left'
					)
					,'center' => array(
						'title' => esc_html__( 'Middle', 'themesky' )
						,'icon' => 'eicon-h-align-center'
					)
					,'flex-end' => array(
						'title' => esc_html__( 'Bottom', 'themesky' )
						,'icon' => 'eicon-h-align-right'
					)
				)
				,'selectors' => array(
					'{{WRAPPER}} .box-content' => 'align-items: {{VALUE}}'
				)
            )
        );
		
		$this->add_responsive_control(
			'v_align'
			,array(
				'label' => esc_html__( 'Vertical Align', 'themesky' )
				,'type' => Controls_Manager::CHOOSE
				,'default' => 'center'
				,'options' => array(
					'flex-start' => array(
						'title' => esc_html__( 'Top', 'themesky' )
						,'icon' => 'eicon-v-align-top'
					)
					,'center' => array(
						'title' => esc_html__( 'Middle', 'themesky' )
						,'icon' => 'eicon-v-align-middle'
					)
					,'flex-end' => array(
						'title' => esc_html__( 'Bottom', 'themesky' )
						,'icon' => 'eicon-v-align-bottom'
					)
				)
				,'description' 	=> ''
				,'selectors' => array(
					'{{WRAPPER}} .box-content' => 'justify-content: {{VALUE}}'
				)
			)
		);
		
		$this->add_responsive_control(
            'text_align'
            ,array(
                'label' 		=> esc_html__( 'Text Align', 'themesky' )
                ,'type' 		=> Controls_Manager::CHOOSE
				,'options' => array(
					'start' => array(
						'title' => esc_html__( 'Left', 'themesky' )
						,'icon' => 'eicon-text-align-left'
					)
					,'center' => array(
						'title' => esc_html__( 'Center', 'themesky' )
						,'icon' => 'eicon-text-align-center'
					)
					,'end' => array(
						'title' => esc_html__( 'Right', 'themesky' )
						,'icon' => 'eicon-text-align-right'
					)
				)
				,'description' 	=> ''
				,'selectors' => array(
					'{{WRAPPER}} .box-content .content-text' => 'align-items: {{VALUE}}; text-align: {{VALUE}}'
				)
            )
        );

		$this->end_controls_section();
		
		$this->start_controls_section(
            'section_heading_style'
            ,array(
                'label' 	=> esc_html__( 'Heading', 'themesky' )
                ,'tab'   	=> Controls_Manager::TAB_STYLE
            )
        );
		
		$this->add_responsive_control(
			'heading_width'
			,array(
				'label' 	=> esc_html__( 'Heading Max Width', 'themesky' )
				,'type' 	=> Controls_Manager::SLIDER
				,'range' 	=> array(
					'px'	=> array(
						'min' 	=> 0
						,'max' 	=> 1000
					)
				)
				,'size_units' 	=> array( 'px', '%' )
				,'selectors' 	=> array(
					'{{WRAPPER}} .box-content h2' => 'max-width: {{SIZE}}{{UNIT}};'
				)
			)
		);
		
		$this->add_control(
            'heading_text_color'
            ,array(
                'label'     	=> esc_html__( 'Text Color', 'themesky' )
                ,'type'     	=> Controls_Manager::COLOR
				,'default'  	=> ''
				,'selectors'	=> array(
					'{{WRAPPER}} .box-content h2' => 'color: {{VALUE}}'
				)
            )
        );
		
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type()
			,array(
				'label' 			=> esc_html__( 'Typography', 'themesky' )
				,'name' 			=> 'heading_typo'
				,'selector'			=> '{{WRAPPER}} .box-content h2'
			)
		);
		
		$this->end_controls_section();
		
		$this->start_controls_section(
            'section_des_style'
            ,array(
                'label' 	=> esc_html__( 'Description', 'themesky' )
                ,'tab'   	=> Controls_Manager::TAB_STYLE
            )
        );

		$this->add_control(
            'des_text_color'
            ,array(
                'label'     	=> esc_html__( 'Text Color', 'themesky' )
                ,'type'     	=> Controls_Manager::COLOR
				,'default'  	=> ''
				,'selectors'	=> array(
					'{{WRAPPER}} .box-content .description' => 'color: {{VALUE}}'
				)
            )
        );
		
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type()
			,array(
				'label' 			=> esc_html__( 'Typography', 'themesky' )
				,'name' 			=> 'des_typo'
				,'selector'			=> '{{WRAPPER}} .box-content .description'
			)
		);

		$this->end_controls_section();
		
		$this->start_controls_section(
            'banner_btn'
            ,array(
                'label' 	=> esc_html__( 'Button', 'themesky' )
                ,'tab'   	=> Controls_Manager::TAB_STYLE
            )
        );
		
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type()
			,array(
				'label' 			=> esc_html__( 'Button Text Typography', 'themesky' )
				,'name' 			=> 'btn_typo'
				,'selector'			=> '{{WRAPPER}} .ts-banner .ts-banner-button a.button'
			)
		);
		
		$this->add_responsive_control(
			'btn_icon_size'
			,array(
				'label' 	=> esc_html__( 'Button Icon Size', 'themesky' )
				,'type' 	=> Controls_Manager::SLIDER
				,'range' 	=> array(
					'px'	=> array(
						'min' 	=> 0
						,'max' 	=> 100
					)
				)
				,'size_units' 	=> array( 'px' )
				,'selectors' 	=> array(
					'{{WRAPPER}} .ts-banner .ts-banner-button a.button i' => 'font-size: {{SIZE}}{{UNIT}};'
				)
			)
		);
		
		$this->add_responsive_control(
			'btn_gap'
			,array(
				'label' 	=> esc_html__( 'Button Gap', 'themesky' )
				,'type' 	=> Controls_Manager::SLIDER
				,'range' 	=> array(
					'px'	=> array(
						'min' 	=> 0
						,'max' 	=> 100
					)
				)
				,'size_units' 	=> array( 'px', '%', 'em', 'rem')
				,'selectors' => array(
					'{{WRAPPER}} .ts-banner .ts-banner-button a.button'=> 'gap: {{SIZE}}{{UNIT}};'
				)
			)
		);
		
		$this->add_responsive_control(
			'btn_padding'
			,array(
				'type' => Controls_Manager::DIMENSIONS
				,'label' => esc_html__( 'Padding', 'themesky' )
				,'size_units' => array( 'px', '%', 'em', 'rem' )
				,'selectors' => array(
					'{{WRAPPER}} .ts-banner .ts-banner-button a.button' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
				)
			)
		);
		
		$this->add_responsive_control(
			'btn_border_radius'
			,array(
				'type' => Controls_Manager::DIMENSIONS
				,'label' => esc_html__( 'Border Radius', 'themesky' )
				,'size_units' => array( 'px', '%' )
				,'selectors' => array(
					'{{WRAPPER}} .ts-banner .ts-banner-button a.button' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
				)
			)
		);
		
		$this->add_control(
			'ts_hr_2'
			,array(
                'type' 		=> Controls_Manager::DIVIDER
            )
		);
		
		$this->start_controls_tabs(
			'style_tabs'
		);
		
		$this->start_controls_tab(
			'style_normal_tab'
			,array(
				'label' 		=> esc_html__( 'Normal', 'themesky' )
			)
		);
		
		$this->add_control(
            'btn_text_color'
            ,array(
                'label'     	=> esc_html__( 'Text Color', 'themesky' )
                ,'type'     	=> Controls_Manager::COLOR
				,'default'  	=> ''
				,'selectors'	=> array(
					'{{WRAPPER}} .ts-banner .ts-banner-button a.button' => 'color: {{VALUE}}'
				)
            )
        );
		
		$this->add_control(
            'btn_bg_color'
            ,array(
                'label'     	=> esc_html__( 'Background Color', 'themesky' )
                ,'type'     	=> Controls_Manager::COLOR
				,'default'  	=> ''
				,'selectors'	=> array(
					'{{WRAPPER}} .ts-banner .ts-banner-button a.button' => 'background-color: {{VALUE}}'
				)
            )
        );

		$this->add_control(
            'btn_border_color'
            ,array(
                'label'     	=> esc_html__( 'Border Color', 'themesky' )
                ,'type'     	=> Controls_Manager::COLOR
				,'default'  	=> ''
				,'selectors'	=> array(
					'{{WRAPPER}} .ts-banner .ts-banner-button a.button' => 'border-color: {{VALUE}}'
				)
            )
        );
		
		$this->end_controls_tab();
		
		$this->start_controls_tab(
			'style_hover_tab'
			,array(
				'label' 		=> esc_html__( 'Hover', 'themesky' )
			)
		);
		
		$this->add_control(
            'btn_text_color_hover'
            ,array(
                'label'     	=> esc_html__( 'Text Color', 'themesky' )
                ,'type'     	=> Controls_Manager::COLOR
				,'default'  	=> ''
				,'selectors'	=> array(
					'{{WRAPPER}} .ts-banner .ts-banner-button a.button:hover, {{WRAPPER}} .ts-banner a.banner-link:hover ~ .box-content .ts-banner-button a.button' => 'color: {{VALUE}}'
				)
            )
        );
		
		$this->add_control(
            'btn_bg_color_hover'
            ,array(
                'label'     	=> esc_html__( 'Background Color', 'themesky' )
                ,'type'     	=> Controls_Manager::COLOR
				,'default'  	=> ''
				,'selectors'	=> array(
					'{{WRAPPER}} .ts-banner .ts-banner-button a.button:hover, {{WRAPPER}} .ts-banner a.banner-link:hover ~ .box-content .ts-banner-button a.button' => 'background-color: {{VALUE}}'
				)
            )
        );

		$this->add_control(
            'btn_border_color_hover'
            ,array(
                'label'     	=> esc_html__( 'Border Color', 'themesky' )
                ,'type'     	=> Controls_Manager::COLOR
				,'default'  	=> ''
				,'selectors'	=> array(
					'{{WRAPPER}} .ts-banner .ts-banner-button a.button:hover, {{WRAPPER}} .ts-banner a.banner-link:hover ~ .box-content .ts-banner-button a.button' => 'border-color: {{VALUE}}'
				)
            )
        );
		
		$this->end_controls_tab();

		$this->end_controls_section();
	}
	
	protected function render(){
		$settings = $this->get_settings_for_display();
		
		$default = array(
			'img_bg'							=> array( 'id' => '', 'url' => '' )
			,'img_bg_mobile'					=> array( 'id' => '', 'url' => '' )
			,'bg_image_device'					=> 'none'
			,'heading_title'					=> ''
			,'description'						=> ''
			,'button_icon'						=> array( 'value' => '', 'library' => '' )
			,'button_pos'						=> 'top'
			,'link' 							=> array( 'url' => '', 'is_external' => true, 'nofollow' => true )
			,'style_effect'						=> 'eff-zoom-in'
		);
		
		$settings = wp_parse_args( $settings, $default );
		
		extract( $settings );
		
		$link_attr = '#';
		$link_attr = $this->generate_link_attributes( $link );
		
		$classes = array();
		$classes[] = $style_effect;
		$classes[] = 'button-'. $button_pos;
		
		if( $bg_image_device != 'none' ){
			$classes[] = $bg_image_device;
		}
		
		$allow_tags = array(
			'a'			=> array('href' => array(),'title' => array(),'style' => array())
			,'span'		=> array('class' => array(),'style' => array())
			,'div'		=> array('class' => array(),'style' => array())
			,'strong'	=> array('class' => array(),'style' => array())
			,'em'		=> array('class' => array(),'style' => array())
			,'br'		=> array('class' => array(),'style' => array())
			,'u'		=> array('class' => array(),'style' => array())
		);
		?>
		<div class="ts-banner <?php echo esc_attr( implode(' ', $classes) ); ?>">
			<div class="banner-wrapper">
			
				<?php if( $link_attr && $link_apply == 'full' ): ?>
				<a class="banner-link" <?php echo implode(' ', $link_attr); ?>></a>
				<?php endif;?>
				
				<div class="background-overlay"></div>
				
				<div class="banner-bg">
				<?php 
					if( !empty( $img_bg_mobile['id'] ) && $bg_image_device != 'none' ){
						echo wp_get_attachment_image($img_bg_mobile['id'], 'full', 0, array('class' => 'bg-image mobile-banner'));
					}
					echo wp_get_attachment_image($img_bg['id'], 'full', 0, array('class' => 'bg-image bg-image main-banner'));
				?>
				</div>
					
				<div class="box-content">
					<div class="content-text">
					
						<?php if( $button_text && $button_pos == 'top' ):?>
							<div class="ts-banner-button">
								<a class="button" <?php echo implode(' ', $link_attr); ?>>
									<span><?php echo esc_html($button_text) ?></span>
									<?php echo ($button_icon['value'] != '') ? '<i class="'. $button_icon['value'] .'"></i>' : ''; ?>
								</a>
							</div>
						<?php endif; ?>
						
						<?php if( $heading_title ): ?>				
							<h2><?php echo wp_kses( $heading_title, $allow_tags ); ?></h2>
						<?php endif; ?>
						
						<?php if( $description ): ?>				
							<div class="description"><?php echo wp_kses( $description, $allow_tags ); ?></div>
						<?php endif; ?>
						
						<?php if( $button_text && $button_pos == 'bottom' ):?>
							<div class="ts-banner-button">
								<a class="button" <?php echo implode(' ', $link_attr); ?>>
									<span><?php echo esc_html($button_text) ?></span>
									<?php echo ($button_icon['value'] != '') ? '<i class="'. $button_icon['value'] .'"></i>' : ''; ?>
								</a>
							</div>
						<?php endif; ?>
					</div>
				</div>
				
			</div>
		</div>
		<?php
	}
}

$widgets_manager->register( new TS_Elementor_Widget_Banner() );