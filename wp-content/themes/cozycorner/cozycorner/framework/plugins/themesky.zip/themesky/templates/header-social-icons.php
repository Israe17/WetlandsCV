<?php 
$theme_options = cozycorner_get_theme_options();
$facebook_url = $theme_options['ts_facebook_url'];
$ts_tiktok_url = $theme_options['ts_tiktok_url'];
$twitter_url = $theme_options['ts_twitter_url'];
$youtube_url = $theme_options['ts_youtube_url'];
$instagram_url = $theme_options['ts_instagram_url'];
$linkedin_url = $theme_options['ts_linkedin_url'];
$pinterest_url = $theme_options['ts_pinterest_url'];
$custom_url = $theme_options['ts_custom_social_url'];
$custom_class = $theme_options['ts_custom_social_class'];
$custom_text = '';
?>
<div class="social-icons">
	<ul>
		<?php do_action('ts_header_social_icons_before'); ?>
			
		<?php if( $facebook_url ): ?>
		<li class="facebook" >
			<a class="icon-brand-facebook" href="<?php echo esc_url($facebook_url); ?>" target="_blank" title="<?php echo esc_attr('Facebook', 'themesky'); ?>"></a>
		</li>
		<?php endif; ?>
		
		<?php if( $instagram_url ): ?>
		<li class="instagram" >
			<a class="icon-brand-instagram" href="<?php echo esc_url($instagram_url); ?>" target="_blank" title="<?php echo esc_attr('Instagram', 'themesky'); ?>"></a>
		</li>
		<?php endif; ?>
		
		<?php if( $twitter_url ): ?>
		<li class="twitter" >
			<a class="icon-brand-x" href="<?php echo esc_url($twitter_url); ?>" target="_blank" title="<?php echo esc_attr('Twitter', 'themesky'); ?>"></a>
		</li>
		<?php endif; ?>
		
		<?php if( $linkedin_url ): ?>
		<li class="linkedin" >
			<a class="icon-brand-linkedin" href="<?php echo esc_url($linkedin_url); ?>" target="_blank" title="<?php echo esc_attr('LinkedIn', 'themesky'); ?>"></a>
		</li>
		<?php endif; ?>
		
		<?php if( $youtube_url ): ?>
		<li class="youtube" >
			<a class="icon-brand-youtube" href="<?php echo esc_url($youtube_url); ?>" target="_blank" title="<?php echo esc_attr('Youtube', 'themesky'); ?>"></a>
		</li>
		<?php endif; ?>
		
		<?php if( $ts_tiktok_url ): ?>
		<li class="tiktok" >
			<a class="icon-brand-tiktok" href="<?php echo esc_url($ts_tiktok_url); ?>" target="_blank" title="<?php echo esc_attr('Tiktok', 'themesky'); ?>"></a>
		</li>
		<?php endif; ?>
		
		<?php if( $pinterest_url ): ?>
		<li class="pinterest" >
			<a class="icon-brand-pinterest" href="<?php echo esc_url($pinterest_url); ?>" target="_blank" title="<?php echo esc_attr('Pinterest', 'themesky'); ?>"></a>
		</li>
		<?php endif; ?>
		
		<?php if( $custom_url ): ?>
		<li class="custom">
			<a class="<?php echo esc_attr($custom_class) ?>" href="<?php echo esc_url($custom_url); ?>" target="_blank" title="<?php echo esc_attr($custom_text); ?>"></a>
		</li>
		<?php endif; ?>
		
		<?php do_action('ts_header_social_icons_after'); ?>
	</ul>
</div>