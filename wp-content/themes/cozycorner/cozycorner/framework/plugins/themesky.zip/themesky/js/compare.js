jQuery(function($){
	"use strict";
	var _has_cache = ts_compare_params.has_cache == 1;
	var _ajax_fragments = _has_cache;
	
	function get_compare(){
		var compare = [];
		var cookie = ts_get_cookie(ts_compare_params.cookie_name);
		
		if( cookie && typeof cookie == 'string' ){
			compare = cookie.split(',');
		}
		if( !Array.isArray(compare) ){
			compare = [];
		}
		return compare;
	}
	
	function set_compare( compare ){
		if( Array.isArray(compare) ){
			compare = compare.join(',');
		}
		ts_set_cookie(ts_compare_params.cookie_name, compare, {expires: 1, secure: ts_compare_params.cookie_secure == 1, path: ts_compare_params.cookie_path, domain: ts_compare_params.cookie_domain});
	}
	
	function add_to_compare( product_id ){
		var compare = get_compare();
		var index = compare.indexOf( product_id );
		if( index == -1 ){
			compare.push(product_id);
			set_compare( compare );
		}
	}
	
	function remove_from_compare( product_id ){
		var compare = get_compare();
		var index = compare.indexOf( product_id );
		if( index != -1 ){
			compare.splice(index, 1);
			set_compare( compare );
		}
	}
	
	function is_cookie_enabled(){
		if( !navigator.cookieEnabled ){
			alert( ts_compare_params.cookie_alert );
			return false;
		}
		
		return true;
	}
	
	function ajax_fragments(){
		$('.ts-compare-popup').addClass('loading');
		$.ajax({
			type : "POST",
			timeout : 30000,
			url : themesky_params.ajax_uri,
			data : {action: 'ts_compare_fragments', nonce: ts_compare_params.ajax_nonce},
			error: function(xhr,err){
				
			},
			success: function( response ){
				if( response && typeof response.fragments != 'undefined' ){
					$.each( response.fragments, function( key, value ){
						$( key ).replaceWith( value );
					});
				}
				$('.ts-compare-popup').removeClass('loading');
				var compare = get_compare();
				if( compare.length ){
					$('.ts-compare-popup').addClass('active');
				}
				_ajax_fragments = false;
			}
		});
	}
	
	function update_popup( action, product_id, button ){
		if( !_ajax_fragments ){
			if( action == 'remove' ){
				var item = $('.ts-compare-popup .item[data-id="' + product_id + '"]');
				if( item.length ){
					item.addClass('empty');
					// empty data & move to end
					item.insertAfter( $('.ts-compare-popup .item:last') );
				}
			}
			else{
				var item = $('.ts-compare-popup .item.empty:first');
				
				if( !button.hasClass('single-compare') ){
					var product = button.closest('.product');
					var product_thumbnail = product.find('.thumbnail-wrapper figure img').length ? product.find('.thumbnail-wrapper figure img:first').clone() : '';
					var product_url = product.find('.product-name').length ? product.find('.product-name:first a').attr('href') : '';
					var product_name = product.find('.product-name').length ? product.find('.product-name:first a').text() : '';
					var product_price = product.find('.price').length ? product.find('.price:first').html() : '';
				}
				else{ /* Button on single product */
					var images = button.closest('.product').find('.woocommerce-product-gallery');
					var summary = button.closest('.product').find('.summary');
					
					var product_thumbnail = images.find('img').length ? images.find('img:first').clone() : '';
					var product_url = window.location.href;
					var product_name = summary.find('.product_title').length ? summary.find('.product_title:first').text() : '';
					var product_price = summary.find('.price').length ? summary.find('.price:first').html() : '';
					
					if( !product_name && $('.breadcrumb-title .heading-title').length ){ /* Get product name in breadcrumb */
						product_name = $('.breadcrumb-title .heading-title').text();
					}
				}
				
				if( !product_thumbnail || !product_name ){
					ajax_fragments();
				}
				else{
					item.attr('data-id', product_id);
				
					item.find('.product-thumbnail a').html('').append(product_thumbnail);
					item.find('.product-url').attr('href', product_url);
					item.find('.product-name a').html(product_name);
					item.find('.product-price').html(product_price);
					
					item.find('.remove').attr('data-id', product_id);
					
					item.removeClass('empty');
				}
			}
		}
		else{
			ajax_fragments();
		}
		
		var compare = get_compare();
		var count = compare.length;
		
		if( count ){
			$('.ts-compare-popup').addClass('active');
			$('.ts-stick-compare-button').removeClass('active');
		}
		else{
			$('.ts-compare-popup, .ts-stick-compare-button').removeClass('active');
		}
		
		$('.ts-stick-compare-button .number').text( '(' + count + ')' );
	}

	$(document).on('click', '.ts-add-to-compare, .ts-compare-popup .remove', function(e){
		e.preventDefault();
		
		if( !is_cookie_enabled() ){
			return false;
		}
		
		var button = $(this);
		
		var product_id = button.attr('data-id');
		
		if( button.hasClass('added') || button.hasClass('remove') ){
			remove_from_compare( product_id );
			update_popup('remove', product_id, button);
		}
		else{
			var compare = get_compare();
			if( compare.length == ts_compare_params.max_item ){
				$('.ts-stick-compare-button').trigger('click');
				alert(ts_compare_params.full_alert);
				return false;
			}
			add_to_compare( product_id );
			update_popup('add', product_id, button);
		}
		
		$('.ts-add-to-compare[data-id="' + product_id + '"]').toggleClass('added');
	});
	
	$(document).on('click', '.ts-stick-compare-button', function(){
		$(this).removeClass('active');
		$('.ts-compare-popup').addClass('active');
		if( _ajax_fragments ){
			ajax_fragments();
		}
	});
	
	$(document).on('click', '.ts-compare-popup .close', function(){
		$('.ts-compare-popup').removeClass('active');
		$('.ts-stick-compare-button').addClass('active');
	});
	
	$(document).on('click', '.ts-compare-popup .link-to-compare', function(){
		var compare = get_compare();
		if( compare.length <= 1 ){
			alert(ts_compare_params.add_more_product_alert);
			return false;
		}
	});
	
	$(document).on('click', '.empty-compare-button', function(e){
		e.preventDefault();
		$('.ts-compare-popup .item:not(.empty) .remove').each(function(){
			$(this).trigger('click');
		});
	});
	
	/* Compare table */
	$(document).on('click', '.ts-remove-from-compare', function(e){
		e.preventDefault();
		
		var wrapper = $(this).closest('.ts-compare-table-wrapper');
		
		var product_id = $(this).attr('data-id');
		remove_from_compare( product_id );
		
		var col = wrapper.find('.ts-remove-from-compare').index( $(this) ) + 1;
		
		wrapper.find('> *').each(function(i, el){
			$(el).find('> *').eq(col).remove();
		});
		
		if( wrapper.find('.ts-remove-from-compare').length == 0 ){ /* no product */
			wrapper.siblings('.ts-empty-compare-message').show();
			wrapper.remove();
		}
	});
	
	$('body').on('added_to_cart', function(e, fragments, cart_hash, $button){
		if( typeof $button !== 'undefined' && $button.closest( '.ts-compare-table-wrapper' ).length ){
			var message = $button.closest('.ts-compare-table-wrapper').siblings('.woocommerce-notices-wrapper');
			if( message.length ){
				message.replaceWith( ts_compare_params.added_to_cart_message );
			}
			else{
				$button.closest('.ts-compare-table-wrapper').before( ts_compare_params.added_to_cart_message );
			}
		}
	});
	
	/* Has cache */
	function update_fragments(){
		var compare = get_compare();
		$('.ts-stick-compare-button .number').text('(' + compare.length + ')');
		
		$('.ts-add-to-compare').removeClass('added');
		compare.forEach(function( product_id ){
			$('.ts-add-to-compare[data-id="' + product_id + '"]').addClass('added');
		});

		if( compare.length ){
			$('.ts-stick-compare-button').addClass('active');
			$('.ts-compare-popup').removeClass('active');
		}
		else{
			$('.ts-compare-popup, .ts-stick-compare-button').removeClass('active');
		}
	}
	
	if( _has_cache ){
		update_fragments();
	}
});