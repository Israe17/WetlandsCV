<?php
class TS_Compare{
	protected static $_instance = null;
	
	public $compare = null;
	public $compare_url = null;
	public $cookie_name = 'ts_compare';
	public $max_item = 3;
	
	function __construct(){
		add_action('init', array($this, 'set_cookie_name'));
		add_action('init', array($this, 'add_hook'), 20);
		
		add_action('template_redirect', array($this, 'template_redirect'));
		
		add_action('wp_enqueue_scripts', array($this, 'register_scripts'));
		
		add_shortcode('ts_compare', array($this, 'compare_table'));
		
		add_action('wp_ajax_ts_compare_fragments', array($this, 'compare_fragments'));
		add_action('wp_ajax_nopriv_ts_compare_fragments', array($this, 'compare_fragments'));
	}
	
	public static function instance(){
		if( is_null( self::$_instance ) ){
			self::$_instance = new self();
		}
		return self::$_instance;
	}
	
	function set_cookie_name(){
		$language = $this->get_current_language();
		if( $language != 'default' ){
			$this->cookie_name = $this->cookie_name . '_' . $language;
		}
	}
	
	function enable_compare( $type = 'both'){ /* both / loop / single */
		$enabled = false;
		if( function_exists('cozycorner_get_theme_options') ){
			switch( $type ){
				case 'both':
					if( cozycorner_get_theme_options('ts_compare_show_in_loop') || cozycorner_get_theme_options('ts_compare_show_on_product_page') ){
						$enabled = true;
					}
				break;
				case 'loop':
					if( cozycorner_get_theme_options('ts_compare_show_in_loop') ){
						$enabled = true;
					}
				break;
				case 'single':
					if( cozycorner_get_theme_options('ts_compare_show_on_product_page') ){
						$enabled = true;
					}
				break;
			}
		}
		
		return $enabled;
	}
	
	function register_scripts(){
		if( !$this->enable_compare('both') ){
			return;
		}
		
		wp_enqueue_script( 'ts-compare', plugin_dir_url( __DIR__ ) . 'js/compare.js', array('jquery'), THEMESKY_VERSION, true );
		
		$has_cache = !is_user_logged_in() && ( defined('W3TC') || defined('LSCWP_V') || defined('SiteGround_Optimizer\VERSION') || defined('WP_ROCKET_VERSION') || apply_filters('ts_compare_has_cache', false) );
		
		$data = array(
			'ajax_nonce'						=> wp_create_nonce( 'ts-compare-nonce' )
			,'added_to_cart_message' 			=> '<div class="woocommerce-notices-wrapper"><div class="woocommerce-message" role="alert">' . esc_html__('Product added to cart successfully', 'themesky') . '</div></div>'
			,'full_alert' 						=> esc_html__('Your compare table is full!', 'themesky')
			,'cookie_alert' 					=> esc_html__('This feature is only available if your browser cookies are enabled', 'themesky')
			,'add_more_product_alert' 			=> esc_html__('Please add more products to compare!', 'themesky')
			,'cookie_name'						=> $this->cookie_name
			,'cookie_path'						=> defined('COOKIEPATH') ? COOKIEPATH : '/'
			,'cookie_domain'					=> defined('COOKIE_DOMAIN') ? COOKIE_DOMAIN : ''
			,'cookie_secure'					=> is_ssl() ? 1 : 0
			,'has_cache'						=> $has_cache ? 1 : 0
			,'max_item'							=> $this->max_item
		);
		wp_localize_script( 'ts-compare', 'ts_compare_params', $data );
	}
	
	function add_hook(){
		if( $this->enable_compare('loop') ){
			add_action( 'woocommerce_after_shop_loop_item_title', array($this, 'add_compare_button'), 10003 );
		}
		
		if( $this->enable_compare('single') ){
			add_action( 'woocommerce_single_product_summary', array($this, 'add_single_compare_button'), 35 );
		}
	}
	
	function template_redirect(){
		if( $this->enable_compare('both') && !$this->is_compare_page() ){
			add_action('wp_footer', array($this, 'compare_stick_button'), 99);
			add_action('wp_footer', array($this, 'compare_popup'), 99);
		}
	}
	
	function is_compare_page(){
		if( function_exists('cozycorner_get_theme_options') ){
			$page_id = cozycorner_get_theme_options('ts_compare_page');
			if( $page_id && is_page($page_id) ){
				return true;
			}
		}
		return false;
	}
	
	function get_current_language(){
		return apply_filters('wpml_current_language', 'default');
	}
	
	function get_compare(){
		if( !is_null($this->compare) ){
			return $this->compare;
		}
		
		if( isset($_COOKIE[$this->cookie_name]) ){
			$this->compare = $_COOKIE[$this->cookie_name];
			if( !$this->compare ){
				$this->compare = array();
			}
			else{
				$this->compare = array_map('absint', explode(',', $this->compare));
			}
		}
		else{
			$this->compare = array();
		}
		
		return $this->compare;
	}
	
	function get_compare_url(){
		if( !is_null($this->compare_url) ){
			return $this->compare_url;
		}
		
		$this->compare_url = '';
		if( function_exists('cozycorner_get_theme_options') ){
			$page_id = cozycorner_get_theme_options('ts_compare_page');
			if( $page_id ){
				$this->compare_url = get_the_permalink( $page_id );
			}
		}
		return $this->compare_url;
	}
	
	function get_compare_count(){
		return count( $this->get_compare() );
	}
	
	public function get_default_table_fields(){
		return array(
			'description' 	=> esc_html__('Description', 'themesky')
			,'sku' 		  	=> esc_html__('SKU', 'themesky')
			,'stock' 		=> esc_html__('Availability', 'themesky')
			,'weight' 		=> esc_html__('Weight', 'themesky')
			,'dimensions' 	=> esc_html__('Dimensions', 'themesky')
		);
	}
	
	function get_compare_table_fields(){
		if( function_exists('cozycorner_get_theme_options') ){
			return cozycorner_get_theme_options('ts_compare_table_fields', array());
		}
		return array();
	}
	
	function is_product_in_compare( $product_id ){
		if( in_array( $product_id, $this->get_compare() ) ){
			return true;
		}
		
		return false;
	}
	
	function add_compare_button( $text = '', $extra_class = '' ){
		global $product;
		if( !$text ){
			$text = __('Compare', 'themesky');
		}
		
		$added = $this->is_product_in_compare( $product->get_id() );
		
		$classes = array('ts-add-to-compare');
		
		if( $extra_class ){
			$classes[] = $extra_class;
		}
		
		if( $added ){
			$classes[] = 'added';
		}
		?>
		<div class="button-in compare">
			<a href="#" class="<?php echo esc_attr( implode(' ', $classes) ); ?>" data-id="<?php echo esc_attr( $product->get_id() ); ?>">
				<span class="ts-tooltip button-tooltip"><?php echo esc_html( $text ); ?></span>
			</a>
		</div>
		<?php
	}
	
	function add_single_compare_button(){
		$this->add_compare_button( __('Add to compare', 'themesky'), 'single-compare' );
	}
	
	function compare_stick_button(){
		$count = $this->get_compare_count();
	?>
		<div class="ts-stick-compare-button <?php echo $count ? 'active' : '' ?>">
			<span class="icon"></span>
			<span><?php esc_html_e('Compare', 'themesky'); ?></span>
			<span class="number">(<?php echo $count; ?>)</span>
		</div>
	<?php
	}
	
	function compare_popup(){
		if( !class_exists('WooCommerce') ){
			return;
		}
		
		$compare = $this->get_compare();
		$count = count($compare);
		$empty_item = 0;
		if( $count < $this->max_item ){
			$empty_item = $this->max_item - $count;
		}
		global $product;
		?>
		<div class="ts-compare-popup">
			<span class="close"></span>
			<div class="content-wrapper">
				<div class="items">
				<?php 
				foreach( $compare as $product_id ){
					$product = wc_get_product( $product_id );
					if( ! is_a( $product, WC_Product::class ) || ! $product->is_visible() ){
						$empty_item++;
						continue;
					}
					?>
					<div class="item" data-id="<?php echo $product->get_id(); ?>">
						<div class="product-wrapper">
							<span class="product-thumbnail"><a href="<?php echo esc_url( $product->get_permalink() ); ?>" class="product-url"><?php echo wp_kses_post( $product->get_image() ); ?></a></span>
							<div class="product-meta">
								<span class="product-name"><a href="<?php echo esc_url( $product->get_permalink() ); ?>" class="product-url"><?php echo wp_kses_post( $product->get_name() ); ?></a></span>
								<span class="product-price"><?php echo wp_kses_post( $product->get_price_html() ); ?></span>
							</div>
						</div>
						<span class="remove" data-id="<?php echo $product->get_id(); ?>"></span>
					</div>
					<?php
				}
				
				for( $i = 0; $i < $empty_item; $i++ ){
					?>
					<div class="item empty" data-id="">
						<div class="product-wrapper">
							<span class="product-thumbnail"><a href="#" class="product-url"></a></span>
							<div class="product-meta">
								<span class="product-name"><a href="#" class="product-url"></a></span>
								<span class="product-price"></span>
							</div>
						</div>
						<span class="remove" data-id=""></span>
					</div>
					<?php
				}
				?>
				</div>
				<div class="actions">
					<a href="<?php echo esc_url( $this->get_compare_url() ); ?>" class="button link-to-compare"><?php esc_html_e('Compare', 'themesky'); ?></a>
					<a href="#" class="button-text empty-compare-button"><?php esc_html_e('Remove all products', 'themesky'); ?></a>
				</div>
			</div>
		</div>
		<?php
		wp_reset_postdata();
	}
	
	function compare_fragments(){
		if( !isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'ts-compare-nonce') ){
			die(__('Security check', 'themesky') );
		}
		else{
			ob_start();
			$this->compare_popup();
			$popup_html = ob_get_clean();
			
			$data = array(
				'fragments'	=> array(
					'.ts-compare-popup' => $popup_html
				)
			);
			wp_send_json( $data );
		}
	}
	
	function compare_table(){
		if( !class_exists('WooCommerce') ){
			return;
		}
		
		$products = array();
		
		$compare = $this->get_compare();
		
		foreach( $compare as $k => $product_id ){
			$product = wc_get_product( $product_id );
			if( ! is_a( $product, WC_Product::class ) || ! $product->is_visible() ){
				unset( $compare[$k] );
			}
			else{
				$products[] = $product;
			}
		}
		
		global $product;
		
		$enable_addtocart = function_exists('cozycorner_get_theme_options') && !cozycorner_get_theme_options('ts_enable_catalog_mode') ? true : false;
		
		$default_fields = $this->get_default_table_fields();
		$fields = $this->get_compare_table_fields();
		
		ob_start();
		?>
		<div class="ts-empty-compare-message" <?php echo !empty($compare) ? 'style="display: none"' : '' ?>>
			<span><?php esc_html_e('No products added to the compare', 'themesky'); ?></span>
		</div>
		
		<?php if( !empty($compare) ){ ?>
		<div class="ts-compare-table-wrapper woocommerce">
			<div class="product-thumbnail">
				<div class="heading"></div>
				
				<?php foreach( $products as $product ){ ?>
				<div>
					<a href="#" class="ts-remove-from-compare" data-id="<?php echo $product->get_id(); ?>"><?php esc_html_e('Remove', 'themesky'); ?></a>
					<a href="<?php echo esc_url( $product->get_permalink() ); ?>" class="thumbnail">
						<?php echo wp_kses_post( $product->get_image() ); ?>
					</a>
					<h6><a href="<?php echo esc_url( $product->get_permalink() ); ?>" class="product-name"><?php echo wp_kses_post( $product->get_name() ); ?></a></h6>
					<div class="product-price">
						<?php echo wp_kses_post( $product->get_price_html() ); ?>
					</div>
					<?php if( $enable_addtocart ){ ?>
					<div class="product-add-to-cart">
						<?php woocommerce_template_loop_add_to_cart(); ?>
					</div>
					<?php } ?>
				</div>
				<?php } ?>
			</div>
			
			<?php
			if( !empty($fields) ){
				foreach( $fields as $field ){
					$heading = isset($default_fields[$field]) ? $default_fields[$field] : ( taxonomy_exists($field) ? wc_attribute_label($field) : '' );
				?>
				<div class="product-<?php echo esc_attr($field) ?>">
					<div class="heading"><?php echo esc_html( $heading ); ?></div>
					<?php foreach( $products as $product ){
						?>
						<div>
						<?php
						switch( $field ){
							case 'description':
								echo apply_filters( 'woocommerce_short_description', $product->get_short_description() );
							break;
							
							case 'stock':
								$availability = $product->get_availability();
								echo '<span class="'.$availability['class'].'">' . esc_html( $availability['availability'] ? $availability['availability'] : __('In stock', 'themesky') ) . '</span>';
							break;
							
							case 'sku':
								$sku = $product->get_sku();
								echo esc_html( $sku ? $sku : __('N/A', 'themesky') );
							break;
							
							case 'weight':
								$weight = $product->get_weight();
								echo esc_html( $weight ? wc_format_localized_decimal( $weight ) . ' ' . get_option( 'woocommerce_weight_unit' ) : __('N/A', 'themesky') );
							break;
							
							case 'dimensions':
								echo esc_html( wc_format_dimensions( $product->get_dimensions( false ) ) );
							break;
							
							default: /* attributes */
								if( taxonomy_exists($field) ){
									$terms = get_the_terms( $product->get_id(), $field );
									if( !empty( $terms ) ){
										if( $field != 'pa_color' ){
											echo implode(', ', wp_list_pluck($terms, 'name'));
										}
										else{
											$color_html = '';
											foreach( $terms as $term ){
												$colors = get_term_meta( $term->term_id, 'ts_product_color_config', true );
												$colors = $colors ? unserialize($colors) : '';
												if( $colors ){
													if( !empty($colors['ts_color_image']) ){
														$color_html .= wp_get_attachment_image( absint($colors['ts_color_image']), 'ts_prod_color_thumb', true, array('title' => $term->name, 'alt' => $term->name) );
													}
													else{
														$style = 'background-color:'. $colors['ts_color_color'] .';';
														if( $colors['ts_color_color'] == '#ffffff' ){
															$style .= ' border-color: var(--ts-border);';
														}
														if( $colors['ts_color_color'] == '#000000' ){
															$style .= ' border-color: #ffffff;';
														}
														$color_html .= '<span style="'. $style .'"></span>';
													}
												}
												else{ /* Break if one of colors is not set */
													$color_html = '';
													break;
												}
											}
											
											if( $color_html ){
												echo $color_html;
											}
											else{
												echo implode(', ', wp_list_pluck($terms, 'name'));
											}
										}
									}
								}
							break;
						}
						?>
						</div>
					<?php } ?>
				</div>
				<?php
				}
			}
			?>
		</div>
		<?php
		}
		
		wp_reset_postdata();
		
		return ob_get_clean();
	}
}

function TS_COMPARE(){
	return TS_Compare::instance();
}
TS_COMPARE();