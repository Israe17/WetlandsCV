<?php
use Elementor\Controls_Manager;

class TS_Elementor_Widget_Special_Product extends TS_Elementor_Widget_Base{
	public function get_name(){
        return 'ts-special-product';
    }
	
	public function get_title(){
        return esc_html__( 'TS Special Product', 'themesky' );
    }
	
	public function get_categories(){
        return array( 'ts-elements', 'woocommerce-elements' );
    }
	
	public function get_icon(){
		return 'eicon-single-product';
	}
	
	protected function register_controls(){
		$this->start_controls_section(
            'section_general'
            ,array(
                'label' 	=> esc_html__( 'General', 'themesky' )
                ,'tab'   	=> Controls_Manager::TAB_CONTENT
            )
        );
		
		$this->add_lazy_load_controls( array( 'thumb-height' => 385 ) );
		
		$this->add_control(
            'ids'
            ,array(
                'label' 		=> esc_html__( 'Specific product', 'themesky' )
                ,'type' 		=> 'ts_autocomplete'
                ,'default' 		=> array()
				,'options'		=> array()
				,'autocomplete'	=> array(
					'type'		=> 'post'
					,'name'		=> 'product'
				)
				,'multiple' 	=> false
				,'label_block' 	=> true
            )
        );

		$this->end_controls_section();
		
		$this->start_controls_section(
            'section_item'
            ,array(
                'label' 		=> esc_html__( 'Item', 'themesky' )
                ,'tab'   		=> Controls_Manager::TAB_CONTENT
            )
        );
		
		$this->add_product_meta_controls();
		
		$this->end_controls_section();
		
		$this->start_controls_section(
            'section_style'
            ,array(
                'label' 	=> esc_html__( 'General', 'themesky' )
                ,'tab'   	=> Controls_Manager::TAB_STYLE
            )
        );
		
		$this->add_control(
            'background_color'
            ,array(
                'label'     	=> esc_html__( 'Background Color', 'themesky' )
                ,'type'     	=> Controls_Manager::COLOR
				,'default'  	=> ''
				,'selectors'	=> array(
					'{{WRAPPER}} .ts-special-product-wrapper.woocommerce .products .product-wrapper' => 'background: {{VALUE}}'
				)
            )
        );
		
		$this->add_responsive_control(
			'content_padding'
			,array(
				'type' => Controls_Manager::DIMENSIONS
				,'label' => esc_html__( 'Content Padding', 'themesky' )
				,'size_units' => array( 'px', '%', 'em', 'rem' )
				,'default' => array(
					'top' => 20
					,'right' => 20
					,'bottom' => 20
					,'left' => 70
					,'unit' => 'px'
					,'isLinked' => false
				)
				,'selectors' => array(
					'{{WRAPPER}} .ts-special-product-wrapper.woocommerce .products .product-wrapper' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
				)
			)
		);
		
		$this->add_control(
			'ts_hr'
			,array(
                'type' 		=> Controls_Manager::DIVIDER
            )
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type()
			,array(
				'label' 			=> esc_html__( 'Product Brands/Categories', 'themesky' )
				,'name' 			=> 'brands_typography'
				,'selector'			=> '{{WRAPPER}} .ts-special-product-wrapper .products .product .product-brands,
										{{WRAPPER}} .ts-special-product-wrapper .products .product .product-categories'
			)
		);
		
		$this->add_control(
            'brands_color'
            ,array(
                'label'     	=> esc_html__( 'Product Brands/Categories Color', 'themesky' )
                ,'type'     	=> Controls_Manager::COLOR
				,'default'  	=> ''
				,'selectors'	=> array(
					'{{WRAPPER}} .ts-special-product-wrapper .products .product .product-brands,
					{{WRAPPER}} .ts-special-product-wrapper .products .product .product-categories' => 'color: {{VALUE}}'
				)
            )
        );
		
		$this->add_control(
			'ts_hr_1'
			,array(
                'type' 		=> Controls_Manager::DIVIDER
            )
		);
		
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type()
			,array(
				'label' 			=> esc_html__( 'Product Name', 'themesky' )
				,'name' 			=> 'name_typography'
				,'selector'			=> '{{WRAPPER}} .ts-special-product-wrapper.woocommerce .products .product .product-name'
			)
		);
		
		$this->add_control(
            'name_color'
            ,array(
                'label'     	=> esc_html__( 'Product Name Color', 'themesky' )
                ,'type'     	=> Controls_Manager::COLOR
				,'default'  	=> ''
				,'selectors'	=> array(
					'{{WRAPPER}} .ts-special-product-wrapper.woocommerce .products .product .product-name' => 'color: {{VALUE}}'
				)
            )
        );
		
		$this->add_responsive_control(
			'name_margin_top'
			,array(
				'label' 	=> esc_html__( 'Product Name Margin Top', 'themesky' )
				,'type' 	=> Controls_Manager::SLIDER
				,'range' 	=> array(
					'px'	=> array(
						'min' 	=> 0
						,'max' 	=> 100
					)
				)
				,'size_units' 	=> array( 'px' )
				,'selectors' 	=> array(
					'{{WRAPPER}} .ts-special-product-wrapper.woocommerce .products .product .product-name' => 'margin-top: {{SIZE}}{{UNIT}};'
				)
			)
		);
		
		$this->add_responsive_control(
			'name_margin_bottom'
			,array(
				'label' 	=> esc_html__( 'Product Name Margin Bottom', 'themesky' )
				,'type' 	=> Controls_Manager::SLIDER
				,'range' 	=> array(
					'px'	=> array(
						'min' 	=> 0
						,'max' 	=> 100
					)
				)
				,'size_units' 	=> array( 'px' )
				,'selectors' 	=> array(
					'{{WRAPPER}} .ts-special-product-wrapper.woocommerce .products .product .product-name' => 'margin-bottom: {{SIZE}}{{UNIT}};'
				)
			)
		);
		
		$this->add_control(
			'ts_hr_2'
			,array(
                'type' 		=> Controls_Manager::DIVIDER
            )
		);
		
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type()
			,array(
				'label' 			=> esc_html__( 'Product Price', 'themesky' )
				,'name' 			=> 'price_typography'
				,'selector'			=> '{{WRAPPER}} .ts-special-product-wrapper.woocommerce .products .product .price'
			)
		);
		
		$this->add_control(
            'price_color'
            ,array(
                'label'     	=> esc_html__( 'Product Price Color', 'themesky' )
                ,'type'     	=> Controls_Manager::COLOR
				,'default'  	=> ''
				,'selectors'	=> array(
					'{{WRAPPER}} .ts-special-product-wrapper.woocommerce .products .product .price' => 'color: {{VALUE}}'
				)
            )
        );

		$this->add_control(
            'price_color_del'
            ,array(
                'label'     	=> esc_html__( 'Product Regular Price Color', 'themesky' )
                ,'type'     	=> Controls_Manager::COLOR
				,'default'  	=> ''
				,'selectors'	=> array(
					'{{WRAPPER}} .ts-special-product-wrapper.woocommerce .products .product .price del' => 'color: {{VALUE}} !important'
				)
            )
        );
		
		$this->add_control(
            'price_color_ins'
            ,array(
                'label'     	=> esc_html__( 'Product Sale Price Color', 'themesky' )
                ,'type'     	=> Controls_Manager::COLOR
				,'default'  	=> ''
				,'selectors'	=> array(
					'{{WRAPPER}} .ts-special-product-wrapper.woocommerce .products .product .price ins' => 'color: {{VALUE}} !important'
				)
            )
        );
		
		$this->add_responsive_control(
			'price_margin_bottom'
			,array(
				'label' 	=> esc_html__( 'Product Price Margin Bottom', 'themesky' )
				,'type' 	=> Controls_Manager::SLIDER
				,'range' 	=> array(
					'px'	=> array(
						'min' 	=> 0
						,'max' 	=> 100
					)
				)
				,'size_units' 	=> array( 'px' )
				,'selectors' 	=> array(
					'{{WRAPPER}} .ts-special-product-wrapper.woocommerce .products .product .price' => 'margin-bottom: {{SIZE}}{{UNIT}};'
				)
			)
		);
		
		$this->add_control(
			'ts_hr_3'
			,array(
                'type' 		=> Controls_Manager::DIVIDER
            )
		);
		
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type()
			,array(
				'label' 			=> esc_html__( 'Product Description', 'themesky' )
				,'name' 			=> 'meta_typography'
				,'selector'			=> '{{WRAPPER}} .ts-special-product-wrapper .products .product .meta-wrapper .short-description'
			)
		);

		$this->add_control(
            'meta_color'
            ,array(
                'label'     	=> esc_html__( 'Product Description Color', 'themesky' )
                ,'type'     	=> Controls_Manager::COLOR
				,'default'  	=> ''
				,'selectors'	=> array(
					'{{WRAPPER}} .ts-special-product-wrapper .products .product .short-description' => 'color: {{VALUE}}'
				)
            )
        );
		
		$this->add_control(
			'ts_hr_4'
			,array(
                'type' 		=> Controls_Manager::DIVIDER
            )
		);
		
		$this->add_responsive_control(
			'rating_size'
			,array(
				'label' 	=> esc_html__( 'Product Rating Size', 'themesky' )
				,'type' 	=> Controls_Manager::SLIDER
				,'range' 	=> array(
					'px'	=> array(
						'min' 	=> 0
						,'max' 	=> 100
					)
				)
				,'size_units' 	=> array( 'px' )
				,'selectors' 	=> array(
					'{{WRAPPER}} .ts-special-product-wrapper' => '--ts-star-size: {{SIZE}}{{UNIT}};'
				)
			)
		);
		
		$this->add_control(
            'rating_color'
            ,array(
                'label'     	=> esc_html__( 'Rating Color', 'themesky' )
                ,'type'     	=> Controls_Manager::COLOR
				,'default'  	=> ''
				,'selectors'	=> array(
					'{{WRAPPER}} .ts-special-product-wrapper' => '--ts-rating-color: {{VALUE}} !important'
				)
            )
        );
		
		$this->add_control(
            'rated_color'
            ,array(
                'label'     	=> esc_html__( 'Rated Color', 'themesky' )
                ,'type'     	=> Controls_Manager::COLOR
				,'default'  	=> ''
				,'selectors'	=> array(
					'{{WRAPPER}} .ts-special-product-wrapper' => '--ts-rated-color: {{VALUE}} !important'
				)
            )
        );
		
		$this->add_responsive_control(
			'meta_margin_bottom'
			,array(
				'label' 	=> esc_html__( 'Product Meta Margin Bottom', 'themesky' )
				,'type' 	=> Controls_Manager::SLIDER
				,'range' 	=> array(
					'px'	=> array(
						'min' 	=> 0
						,'max' 	=> 100
					)
				)
				,'size_units' 	=> array( 'px' )
				,'selectors' 	=> array(
					'{{WRAPPER}} .ts-special-product-wrapper .products .product div.loop-add-to-cart' => 'margin-top: {{SIZE}}{{UNIT}};'
				)
			)
		);
		
		$this->end_controls_section();
	}
	
	protected function render(){
		$settings = $this->get_settings_for_display();
		
		$default = array(
			'lazy_load'						=> 0
			,'ids'							=> 0
			,'show_image' 					=> 1
			,'show_title' 					=> 1
			,'show_sku' 					=> 0
			,'show_price' 					=> 1
			,'show_short_desc'  			=> 0
			,'show_rating' 					=> 0
			,'show_label' 					=> 1
			,'show_categories'				=> 0
			,'show_brands'					=> 0
			,'show_add_to_cart' 			=> 1
		);
		
		$settings = wp_parse_args( $settings, $default );
		
		extract( $settings );
		
		if ( !class_exists('WooCommerce') ){
			return;
		}
		
		if( !$ids ){
			return;
		}
		
		if( !is_array($ids) ){
			$ids = array( $ids );
		}
		
		if( $this->lazy_load_placeholder( $settings, 'special-product' ) ){
			return;
		}
		
		if( $show_add_to_cart ){
			add_action('woocommerce_after_shop_loop_item', 'cozycorner_template_loop_add_to_cart', 55);
			$show_add_to_cart = 0;
		}
		
		$options = array(
				'show_image'			=> $show_image
				,'show_label'			=> $show_label
				,'show_title'			=> $show_title
				,'show_sku'				=> $show_sku
				,'show_price'			=> $show_price
				,'show_short_desc'		=> $show_short_desc
				,'show_categories'		=> $show_categories
				,'show_brands'			=> $show_brands
				,'show_rating'			=> $show_rating
				,'show_add_to_cart'		=> $show_add_to_cart
			);
			
		ts_remove_product_hooks( $options );
		
		$args = array(
			'post_type'				=> 'product'
			,'post_status' 			=> 'publish'
			,'ignore_sticky_posts'	=> 1
			,'posts_per_page' 		=> 1
			,'post__in' 			=> $ids
			,'orderby' 				=> 'post__in'
			,'meta_query' 			=> WC()->query->get_meta_query()
			,'tax_query'           	=> WC()->query->get_tax_query()
		);
		
		global $post;

		$products = new WP_Query( $args );

		if( $products->have_posts() ): 
		?>
		<div class="ts-special-product-wrapper ts-shortcode ts-product woocommerce">
			<div class="content-wrapper">
				<?php
				woocommerce_product_loop_start();
				
				while( $products->have_posts() ){
					$products->the_post();
					wc_get_template_part( 'content', 'product' );
				}
				
				woocommerce_product_loop_end();
				?>
			</div>
		</div>
		<?php
		endif;
		
		wp_reset_postdata();

		/* restore hooks */
		ts_restore_product_hooks();
		
		remove_action('woocommerce_after_shop_loop_item', 'cozycorner_template_loop_add_to_cart', 55);
	}
}

$widgets_manager->register( new TS_Elementor_Widget_Special_Product() );