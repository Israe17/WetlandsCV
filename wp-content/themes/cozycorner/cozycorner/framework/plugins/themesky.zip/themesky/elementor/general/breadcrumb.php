<?php
use Elementor\Controls_Manager;

class TS_Elementor_Widget_Breadcrumb extends TS_Elementor_Widget_Base{
	public function get_name(){
        return 'ts-breadcrumb';
    }
	
	public function get_title(){
        return esc_html__( 'TS Breadcrumb', 'themesky' );
    }
	
	public function get_categories(){
        return array( 'ts-elements', 'general' );
    }
	
	public function get_icon(){
		return 'eicon-product-breadcrumbs';
	}
	
	protected function register_controls(){
		$this->start_controls_section(
            'section_general'
            ,array(
                'label' 	=> esc_html__( 'General', 'themesky' )
                ,'tab'   	=> Controls_Manager::TAB_CONTENT
            )
        );
		
		$this->add_control(
            'info'
            ,array(
                'type' 			=> Controls_Manager::ALERT
                ,'alert_type' 	=> 'info'
				,'content' 		=> esc_html__( 'This is a dynamic element. Its content depends on where it is located', 'themesky' )
            )
        );
		
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type()
			,array(
				'label' 			=> esc_html__( 'Typography', 'themesky' )
				,'name' 			=> 'breadcrumb_typo'
				,'selector'			=> '{{WRAPPER}} .ts-breadcrumbs'
			)
		);
		
		$this->add_control(
            'breadcrumb_color'
            ,array(
                'label'     	=> esc_html__( 'Text Color', 'themesky' )
                ,'type'     	=> Controls_Manager::COLOR
				,'default'  	=> ''
				,'selectors'	=> array(
					'{{WRAPPER}}' => '--ts-breadcrumb-color: {{VALUE}};'
				)
            )
        );
		
		$this->add_control(
            'breadcrumb_link_color'
            ,array(
                'label'     	=> esc_html__( 'Link Color', 'themesky' )
                ,'type'     	=> Controls_Manager::COLOR
				,'default'  	=> ''
				,'selectors'	=> array(
					'{{WRAPPER}}' => '--ts-breadcrumb-link-color: {{VALUE}}'
				)
            )
        );
		
		$this->add_responsive_control(
            'text_align'
            ,array(
                'label' 		=> esc_html__( 'Text Align', 'themesky' )
                ,'type' 		=> Controls_Manager::CHOOSE
				,'options' => array(
					'start' => array(
						'title' => esc_html__( 'Left', 'themesky' )
						,'icon' => 'eicon-text-align-left'
					)
					,'center' => array(
						'title' => esc_html__( 'Center', 'themesky' )
						,'icon' => 'eicon-text-align-center'
					)
					,'end' => array(
						'title' => esc_html__( 'Right', 'themesky' )
						,'icon' => 'eicon-text-align-right'
					)
				)
				,'description' 	=> ''
				,'selectors' => array(
					'{{WRAPPER}} .ts-breadcrumbs' => 'text-align: {{VALUE}}'
				)
            )
        );
		
		$this->end_controls_section();
	}
	
	protected function render(){
		if( function_exists('cozycorner_breadcrumbs') ){
			cozycorner_breadcrumbs();
		}
	}
}

$widgets_manager->register( new TS_Elementor_Widget_Breadcrumb() );