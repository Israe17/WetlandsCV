<?php
use Elementor\Controls_Manager;

class TS_Elementor_Widget_Mailchimp extends TS_Elementor_Widget_Base{
	public function get_name(){
        return 'ts-mailchimp';
    }
	
	public function get_title(){
        return esc_html__( 'TS Mailchimp', 'themesky' );
    }
	
	public function get_categories(){
        return array( 'ts-elements', 'general' );
    }
	
	public function get_icon(){
		return 'eicon-email-field';
	}
	
	protected function register_controls(){
		$this->start_controls_section(
            'section_general'
            ,array(
                'label' 	=> esc_html__( 'General', 'themesky' )
                ,'tab'   	=> Controls_Manager::TAB_CONTENT
            )
        );
		
		$this->add_control(
            'form'
            ,array(
                'label' 		=> esc_html__( 'Form', 'themesky' )
                ,'type' 		=> Controls_Manager::SELECT
                ,'default' 		=> ''
				,'options'		=> $this->get_custom_post_options( 'mc4wp-form' )			
                ,'description' 	=> ''
            )
        );

		$this->add_control(
            'title'
            ,array(
                'label' 		=> esc_html__( 'Title', 'themesky' )
                ,'type' 		=> Controls_Manager::TEXT
                ,'default' 		=> ''		
                ,'description' 	=> ''
            )
        );

		$this->add_control(
            'intro_text'
            ,array(
                'label' 		=> esc_html__( 'Intro text', 'themesky' )
                ,'type' 		=> Controls_Manager::TEXT
                ,'default' 		=> ''		
                ,'description' 	=> ''
            )
        );
		
		$this->add_control(
            'button_style'
            ,array(
                'label' 		=> esc_html__( 'Button Style', 'themesky' )
                ,'type' 		=> Controls_Manager::SELECT
                ,'default' 		=> 'button-default'
				,'options'		=> array(
									'button-default'	=> 'Button Default'
									,'button-text'		=> 'Button Text'
									,'button-icon'		=> 'Button Icon'
								)			
            )
        );

		$this->end_controls_section();
		
		$this->start_controls_section(
            'section_layout'
            ,array(
                'label' 	=> esc_html__( 'Layout', 'themesky' )
                ,'tab'   	=> Controls_Manager::TAB_STYLE
            )
        );
		
		$this->add_responsive_control(
            'align'
            ,array(
                'label' 		=> esc_html__( 'Align Items', 'themesky' )
                ,'type' 		=> Controls_Manager::CHOOSE
				,'options' => array(
					'flex-start' => array(
						'title' => esc_html__( 'Left', 'themesky' )
						,'icon' => 'eicon-align-start-h'
					)
					,'center' => array(
						'title' => esc_html__( 'Center', 'themesky' )
						,'icon' => 'eicon-align-center-h'
					)
					,'flex-end' => array(
						'title' => esc_html__( 'Right', 'themesky' )
						,'icon' => 'eicon-align-end-h'
					)
				)
				,'description' 	=> ''
				,'selectors' 	=> array(
					'{{WRAPPER}} .direction-row .mailchimp-subscription' => 'justify-content: {{VALUE}}'
					,'{{WRAPPER}} .direction-column .mailchimp-subscription' => 'align-items: {{VALUE}}'
				)
            )
        );
		
		$this->add_responsive_control(
            'text_align'
            ,array(
                'label' 		=> esc_html__( 'Text Align', 'themesky' )
                ,'type' 		=> Controls_Manager::CHOOSE
				,'options' => array(
					'left' => array(
						'title' => esc_html__( 'Left', 'themesky' )
						,'icon' => 'eicon-text-align-left'
					)
					,'center' => array(
						'title' => esc_html__( 'Center', 'themesky' )
						,'icon' => 'eicon-text-align-center'
					)
					,'right' => array(
						'title' => esc_html__( 'Right', 'themesky' )
						,'icon' => 'eicon-text-align-right'
					)
				)
				,'description' 	=> ''
				,'selectors' 	=> array(
					'{{WRAPPER}} .mailchimp-subscription' => 'text-align: {{VALUE}}'
				)
            )
        );
		
		$this->add_responsive_control(
            'direction'
            ,array(
                'label' 		=> esc_html__( 'Direction', 'themesky' )
                ,'type' 		=> Controls_Manager::CHOOSE
				,'options' => array(
					'row' => array(
						'title' => esc_html__( 'Horizontal', 'themesky' )
						,'icon' => 'eicon-arrow-right'
					)
					,'column' => array(
						'title' => esc_html__( 'Vertical', 'themesky' )
						,'icon' => 'eicon-arrow-down'
					)
				)
				,'description' 	=> ''
				,'default' 		=> 'row'
				,'selectors' 	=> array(
					'{{WRAPPER}} .mailchimp-subscription' => 'flex-direction: {{VALUE}}'
				)
            )
        );
		
		$this->add_responsive_control(
			'ts_gap'
			,array(
				'type' => Controls_Manager::GAPS
				,'label' => esc_html__( 'Gap', 'themesky' )
				,'size_units' => array( 'px', '%', 'em', 'rem', 'vw', 'custom' )
				,'selectors' => array(
					'{{WRAPPER}} .mailchimp-subscription'=> 'gap: {{ROW}}{{UNIT}} {{COLUMN}}{{UNIT}};'
				)
			)
		);
		
		$this->end_controls_section();
		
		$this->start_controls_section(
            'section_title_style'
            ,array(
                'label' 	=> esc_html__( 'Title', 'themesky' )
                ,'tab'   	=> Controls_Manager::TAB_STYLE
            )
        );
		
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type()
			,array(
				'label' 			=> esc_html__( 'Typography', 'themesky' )
				,'name' 			=> 'heading_typography'
				,'selector'			=> '{{WRAPPER}} .mailchimp-subscription .widget-title'
				,'fields_options'	=> array(
					'font_size'			=> array(
						'default'		=> array(
							'size' 		=> '30'
							,'unit' 	=> 'px'
						)
						,'size_units' 	=> array( 'px', 'em', 'rem', 'vw' )
					)
					,'line_height'		=> array(
						'default' 		=> array(
							'size' 		=> '36'
							,'unit' 	=> 'px'
						)
					)
				)
			)
		);
		
		$this->add_control(
            'title_color'
            ,array(
                'label'     	=> esc_html__( 'Color', 'themesky' )
                ,'type'     	=> Controls_Manager::COLOR
				,'default'  	=> ''
				,'selectors'	=> array(
					'{{WRAPPER}} .mailchimp-subscription .widget-title' => 'color: {{VALUE}}'
				)
            )
        );
		
		$this->end_controls_section();
		
		$this->start_controls_section(
            'section_intro_style'
            ,array(
                'label' 	=> esc_html__( 'Intro Text', 'themesky' )
                ,'tab'   	=> Controls_Manager::TAB_STYLE
            )
        );
			
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type()
			,array(
				'label' 			=> esc_html__( 'Typography', 'themesky' )
				,'name' 			=> 'intro_typography'
				,'selector'			=> '{{WRAPPER}} .mailchimp-subscription .newsletter'
				,'fields_options'	=> array(
					'font_size'			=> array(
						'default'		=> array(
							'size' 		=> '15'
							,'unit' 	=> 'px'
						)
						,'size_units' 	=> array( 'px', 'em', 'rem', 'vw' )
					)
					,'line_height'		=> array(
						'default' 		=> array(
							'size' 		=> '22'
							,'unit' 	=> 'px'
						)
					)
				)
			)
		);
		
		$this->add_control(
            'intro_color'
            ,array(
                'label'     	=> esc_html__( 'Color', 'themesky' )
                ,'type'     	=> Controls_Manager::COLOR
				,'default'  	=> ''
				,'selectors'	=> array(
					'{{WRAPPER}} .mailchimp-subscription .newsletter' => 'color: {{VALUE}}'
				)
            )
        );
		
		$this->end_controls_section();
		
		$this->start_controls_section(
            'section_form'
            ,array(
                'label' 		=> esc_html__( 'Subscribe Form', 'themesky' )
                ,'tab'   		=> Controls_Manager::TAB_STYLE
            )
        );

		$this->add_responsive_control(
			'form_gap'
			,array(
				'type' => Controls_Manager::GAPS
				,'label' => esc_html__( 'Form Gap', 'themesky' )
				,'size_units' => array( 'px', '%', 'em', 'rem', 'vw', 'custom' )
				,'default' => array(
					'column' => 10
					,'row' => 10
					,'isLinked' => true
					,'unit' => 'px'
				)
				,'selectors' => array(
					'{{WRAPPER}} form .subscribe-email'=> 'gap: {{ROW}}{{UNIT}} {{COLUMN}}{{UNIT}};'
				)
			)
		);
		
		$this->add_responsive_control(
            'form_direction'
            ,array(
                'label' 		=> esc_html__( 'Form Direction', 'themesky' )
                ,'type' 		=> Controls_Manager::CHOOSE
				,'options' => array(
					'row' => array(
						'title' => esc_html__( 'Horizontal', 'themesky' )
						,'icon' => 'eicon-arrow-right'
					)
					,'column' => array(
						'title' => esc_html__( 'Vertical', 'themesky' )
						,'icon' => 'eicon-arrow-down'
					)
				)
				,'description' 	=> ''
				,'default' 		=> 'row'
				,'selectors' 	=> array(
					'{{WRAPPER}} .mailchimp-subscription .subscribe-email' => 'flex-direction: {{VALUE}};'
				)
            )
        );
		
		$this->add_control(
			'ts_hr_1'
			,array(
                'type' 		=> Controls_Manager::DIVIDER
            )
		);
		
		$this->add_control(
            'input_style'
            ,array(
                'label'     	=> esc_html__( 'Input', 'themesky' )
                ,'type' 		=> Controls_Manager::HEADING		
                ,'description' 	=> ''
            )
        );
		
		$this->add_responsive_control(
			'input_width'
			,array(
				'label' 	=> esc_html__( 'Min Width', 'themesky' )
				,'type' 	=> Controls_Manager::SLIDER
				,'range' 	=> array(
					'px'	=> array(
						'min' 	=> 0
						,'max' 	=> 1000
					)
				)
				,'default' 		=> array( 'unit' => 'px', 'size' => 290 )
				,'selectors' 	=> array(
					'{{WRAPPER}} .subscribe-email input[type=email]' => 'min-width: {{SIZE}}{{UNIT}};'
				)
			)
		);
		
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type()
			,array(
				'label' 			=> esc_html__( 'Typography', 'themesky' )
				,'name' 			=> 'input_typo'
				,'selector'			=> '{{WRAPPER}} .subscribe-email input[type=email]'
			)
		);
		
		$this->add_control(
            'input_color'
            ,array(
                'label'     	=> esc_html__( 'Text Color', 'themesky' )
                ,'type'     	=> Controls_Manager::COLOR
				,'default'  	=> ''
				,'selectors'	=> array(
					'{{WRAPPER}} form .subscribe-email input[type=email]' => 'color: {{VALUE}}'
				)
            )
        );
		
		$this->add_control(
            'placeholder_color'
            ,array(
                'label'     	=> esc_html__( 'Placeholder Color', 'themesky' )
                ,'type'     	=> Controls_Manager::COLOR
				,'default'  	=> ''
				,'selectors'	=> array(
					'{{WRAPPER}} .mailchimp-subscription' => '--ts-placeholder-color: {{VALUE}}'
				)
            )
        );
		
		$this->add_control(
            'input_background'
            ,array(
                'label'     	=> esc_html__( 'Background Color', 'themesky' )
                ,'type'     	=> Controls_Manager::COLOR
				,'default'  	=> ''
				,'selectors'	=> array(
					'{{WRAPPER}} form .subscribe-email input[type=email]' => 'background-color: {{VALUE}}'
				)
            )
        );
		
		$this->add_control(
            'input_border'
            ,array(
                'label'     	=> esc_html__( 'Border Color', 'themesky' )
                ,'type'     	=> Controls_Manager::COLOR
				,'default'  	=> ''
				,'selectors'	=> array(
					'{{WRAPPER}} form .subscribe-email input[type=email]' => 'border-color: {{VALUE}}'
				)
            )
        );
		
		$this->add_control(
			'ts_hr_2'
			,array(
                'type' 		=> Controls_Manager::DIVIDER
            )
		);
		
		$this->add_control(
            'btn_style'
            ,array(
                'label'     	=> esc_html__( 'Button', 'themesky' )
                ,'type' 		=> Controls_Manager::HEADING		
                ,'description' 	=> ''
            )
        );
		
		$this->add_responsive_control(
			'btn_width'
			,array(
				'label' 	=> esc_html__( 'Min Width', 'themesky' )
				,'type' 	=> Controls_Manager::SLIDER
				,'range' 	=> array(
					'px'	=> array(
						'min' 	=> 0
						,'max' 	=> 1000
					)
				)
				,'default' 		=> array( 'unit' => 'px', 'size' => 0 )
				,'condition' 	=> array('button_style!' => 'button-text')
				,'selectors' 	=> array(
					'{{WRAPPER}} .subscribe-email .button' => 'min-width: {{SIZE}}{{UNIT}};'
				)
			)
		);
		
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type()
			,array(
				'label' 			=> esc_html__( 'Typography', 'themesky' )
				,'name' 			=> 'btn_typo'
				,'selector'			=> '{{WRAPPER}} .subscribe-email .button'
			)
		);
		
		$this->start_controls_tabs(
			'style_tabs'
		);
		
		$this->start_controls_tab(
			'style_normal_tab'
			,array(
				'label' => esc_html__( 'Normal', 'themesky' )
			)
		);
		
		$this->add_control(
            'button_color'
            ,array(
                'label'     	=> esc_html__( 'Text Color', 'themesky' )
                ,'type'     	=> Controls_Manager::COLOR
				,'default'  	=> ''
				,'selectors'	=> array(
					'{{WRAPPER}} .mc4wp-form .subscribe-email .button' => 'color: {{VALUE}}'
					,'{{WRAPPER}} .mailchimp-subscription .processing button.button:before' => 'border-top-color: {{VALUE}}'
				)
            )
        );
		
		$this->add_control(
            'button_background'
            ,array(
                'label'     	=> esc_html__( 'Background Color', 'themesky' )
                ,'type'     	=> Controls_Manager::COLOR
				,'default'  	=> ''
				,'condition'  	=> array( 'button_style!' => 'button-text' )
				,'selectors'	=> array(
					'{{WRAPPER}} .mc4wp-form .subscribe-email .button' => 'background-color: {{VALUE}}'
				)
            )
        );
		
		$this->add_control(
            'button_border'
            ,array(
                'label'     	=> esc_html__( 'Border Color', 'themesky' )
                ,'type'     	=> Controls_Manager::COLOR
				,'default'  	=> ''
				,'condition'  	=> array( 'button_style!' => 'button-text' )
				,'selectors'	=> array(
					'{{WRAPPER}} .mc4wp-form .subscribe-email .button' => 'border-color: {{VALUE}}'
				)
            )
        );
		
		$this->end_controls_tab();
		
		$this->start_controls_tab(
			'style_hover_tab'
			,array(
				'label' => esc_html__( 'Hover', 'themesky' )
			)
		);
		
		$this->add_control(
            'button_color_hover'
            ,array(
                'label'     	=> esc_html__( 'Text Color', 'themesky' )
                ,'type'     	=> Controls_Manager::COLOR
				,'default'  	=> ''
				,'selectors'	=> array(
					'{{WRAPPER}} .mc4wp-form .subscribe-email .button:hover' => 'color: {{VALUE}}'
					,'{{WRAPPER}} .mailchimp-subscription .processing button.button:hover:before' => 'border-top-color: {{VALUE}}'
				)
            )
        );
		
		$this->add_control(
            'button_background_hover'
            ,array(
                'label'     	=> esc_html__( 'Background Color', 'themesky' )
                ,'type'     	=> Controls_Manager::COLOR
				,'default'  	=> ''
				,'condition'  	=> array( 'button_style!' => 'button-text' )
				,'selectors'	=> array(
					'{{WRAPPER}} .mc4wp-form .subscribe-email .button:hover' => 'background-color: {{VALUE}}'
				)
            )
        );
		
		$this->add_control(
            'button_border_hover'
            ,array(
                'label'     	=> esc_html__( 'Border Color', 'themesky' )
                ,'type'     	=> Controls_Manager::COLOR
				,'default'  	=> ''
				,'condition'  	=> array( 'button_style!' => 'button-text' )
				,'selectors'	=> array(
					'{{WRAPPER}} .mc4wp-form .subscribe-email .button:hover' => 'border-color: {{VALUE}}'
				)
            )
        );
		
		$this->end_controls_tab();
		
		$this->end_controls_tabs();

		$this->end_controls_section();
	}
	
	protected function render(){
		$settings = $this->get_settings_for_display();
		
		$default = array(
			'title'				=> ''
			,'intro_text'		=> ''
			,'form'				=> ''
			,'button_style'		=> 'button-default'
			,'align'			=> 'center'
			,'direction'		=> 'row'
			,'form_direction'	=> 'row'
		);
		
		$settings = wp_parse_args( $settings, $default );
		
		extract( $settings );
		
		if( !class_exists('TS_Mailchimp_Subscription_Widget') ){
			return;
		}
		
		$intro_text_html = '';
		if( $intro_text ){
			$intro_text_html = '<div class="newsletter"><p>' . esc_html($intro_text) . '</p></div>';
			$intro_text = ''; /* Dont show in widget content */
		}
		
		$args = array(
			'before_widget' => '<section class="widget-container %s">'
			,'after_widget' => '</section>'
			,'before_title' => '<div class="widget-title-wrapper"><h3 class="widget-title heading-title">'
			,'after_title'  => '</h3></div>' . $intro_text_html
		);

		$title = wp_kses($title, array('br' => array()));
		$instance = compact('title', 'intro_text', 'form');
		
		$classes = array();
		$classes[] = 'direction-' . $direction;
		$classes[] = 'form-direction-' . $form_direction;
		$classes[] = $button_style;
		
		echo '<div class="ts-mailchimp-subscription-shortcode '.implode(' ', $classes).'" >';
		
		the_widget('TS_Mailchimp_Subscription_Widget', $instance, $args);
		
		echo '</div>';
	}
}

$widgets_manager->register( new TS_Elementor_Widget_Mailchimp() );