<?php
class TS_Frequently_Bought_Together{
	protected static $_instance = null;
	
	protected $option_name = 'ts_fbt_product_ids';
	
	function __construct(){
		add_filter('woocommerce_product_data_tabs', array($this, 'add_bought_together_tab'));
		add_action('woocommerce_product_data_panels', array($this, 'add_bought_together_panel'));
		
		add_action('wp_ajax_ts_fbt_search_product', array($this, 'ajax_search_product'));
		add_action('wp_ajax_nopriv_ts_fbt_search_product', array($this, 'ajax_search_product'));
		
		add_action('woocommerce_process_product_meta', array($this, 'save_bought_together_tab' ), 20, 2);
		
		add_action('wp_loaded', array($this, 'add_fbt_to_cart'), 20);
		
		add_action('wp_enqueue_scripts', array($this, 'register_scripts'));
		
		add_action('template_redirect', array($this, 'template_redirect'));
		
		add_action('wp_ajax_ts_frequently_bought_together_fragments', array($this, 'frequently_bought_together_fragments'));
		add_action('wp_ajax_nopriv_ts_frequently_bought_together_fragments', array($this, 'frequently_bought_together_fragments'));
	}
	
	public static function instance(){
		if( is_null( self::$_instance ) ){
			self::$_instance = new self();
		}
		return self::$_instance;
	}
	
	function register_scripts(){
		wp_register_script( 'ts-frequently-bought-together', plugin_dir_url( __DIR__ ) . 'js/frequently-bought-together.js', array('jquery'), THEMESKY_VERSION, true );
		
		$data = array(
				'ajax_nonce' => wp_create_nonce( 'ts-fbt-nonce' )
			);
		wp_localize_script( 'ts-frequently-bought-together', 'ts_fbt_params', $data );	
	}
	
	function get_settings( $key = '', $default = '' ){
		if( function_exists('cozycorner_get_theme_options') ){
			return cozycorner_get_theme_options( $key, $default );
		}
		
		if( $key ){
			return '';
		}
		
		return array();
	}
	
	function template_redirect(){
		global $post;
		if( is_singular('product') && $this->get_product_ids($post->ID) ){
			wp_enqueue_script('ts-frequently-bought-together');
			
			$position = $this->get_settings('ts_fbt_position');
			if( $position == 'after-summary' ){
				add_action('woocommerce_after_single_product_summary', array($this, 'bought_together_form'), 9);
			}
			else{
				add_action('woocommerce_after_single_product_summary', array($this, 'bought_together_form'), 7);
			}
		}
	}
	
	function get_product_ids( $product = null ){
		if( is_numeric( $product ) ){
			$product = wc_get_product( $product );
		}
		
		if( is_null($product) ){
			global $product;
		}
		
		if( !is_a($product, 'WC_Product') ){
			return array();
		}
		
		$product_ids = $product->get_meta( $this->option_name );
		if( is_array($product_ids) ){
			return array_filter( array_map( 'absint', $product_ids ) );
		}
		return array();
	}
	
	/* Backend */
	function add_bought_together_tab( $tabs ){
		$tabs['ts-fbt'] = array(
				'label'   => __( 'Frequently Bought Together', 'themesky' )
				,'target' => 'ts_fbt_data_option'
				,'class'  => array( 'hide_if_grouped', 'hide_if_external', 'hide_if_bundle' )
			);
		
		return $tabs;
	}
	
	function add_bought_together_panel(){
		global $post, $product_object;

		$product_id = $post->ID;
		if( is_null( $product_object ) ){
			$product_object = wc_get_product( $product_id );
		}
		
		$product_ids = $this->get_product_ids( $product_object );
		
		$options = array();
		foreach( $product_ids as $id ){
			$_product = wc_get_product( $id );
			if( is_object( $_product ) ){
				$options[ $id ] = strip_tags( $_product->get_formatted_name() );
			}
		}
		
		?>
		<div id="ts_fbt_data_option" class="panel woocommerce_options_panel">
			<div class="options_group">
				<p class="form-field">
					<label for="ts_fbt_ids"><?php esc_html_e('Select products', 'themesky'); ?></label>
					<select id="ts_fbt_ids"
						name="ts_fbt_ids[]"
						class="wc-product-search"
						data-placeholder="<?php esc_attr_e('Search for a product', 'themesky'); ?>"
						data-allow_clear=""
						data-action="ts_fbt_search_product"
						multiple="multiple"
						data-exclude="<?php echo esc_attr($product_id); ?>"
						style="width: 50%">
						<?php 
						foreach( $options as $id => $label ){
						?>
							<option value="<?php echo esc_attr($id); ?>" selected="selected">
								<?php echo esc_html( $label ); ?>
							</option>
						<?php
						}
						?>
					</select>
				</p>
			</div>
		</div>
		<?php
	}
	
	function save_bought_together_tab( $post_id, $post ){
		$product = wc_get_product( $post_id );
		$product_ids = array();
		if( !empty( $_POST['ts_fbt_ids'] ) && is_array($_POST['ts_fbt_ids']) ){
			$product_ids = stripslashes_deep( array_map( 'sanitize_text_field', $_POST['ts_fbt_ids'] ) );
			$product_ids = array_filter( array_map( 'intval', $product_ids ) );
		}
		$product->update_meta_data($this->option_name, $product_ids);
		$product->save();
	}
	
	function ajax_search_product(){
		check_ajax_referer( 'search-products', 'security' );
		
		$term = isset( $_GET['term'] ) ? (string) wc_clean( stripslashes( $_GET['term'] ) ) : '';
		if( empty($term) ){
			die();
		}
		$exclude = isset( $_GET['exclude'] ) ? explode( ',', wc_clean( stripslashes( $_GET['exclude'] ) ) ) : false;
		
		$post_types = array( 'product', 'product_variation' );
		
		$args_base = array(
						'post_type'       => $post_types
						,'post_status'    => 'publish'
						,'posts_per_page' => -1
						,'fields'         => 'ids'
					);
					
		$args = array_merge($args_base, array(
					's' => $term
			));
			
		if( $exclude ){
			$args['post__not_in'] = $exclude;
		}
		
		$args2 = array_merge($args_base, array(
					'meta_query'     => array(
						array(
							'key'      => '_sku'
							,'value'   => $term
							,'compare' => 'LIKE'
						)
					)
				));
				
		$posts = array_merge( get_posts( $args ), get_posts( $args2 ) );		
				
		if( is_numeric($term) ){
			$args3 = array_merge($args_base, array(
					'post__in' => array( 0, $term )
				));
				
			$posts = array_merge( $posts, get_posts( $args3 ) );	
		}
		
		$posts = array_unique( $posts );
		
		$found_products = array();
		
		if( $posts ){
			foreach( $posts as $post_id ){
				$product = wc_get_product( $post_id );
				if( !$product ){
					continue;
				}
				$product_type = $product->get_type();
				if( in_array($product_type, array('simple', 'variation')) ){
					if( $product_type == 'variation' ){
						$parent_id = wp_get_post_parent_id( $post_id );
						if( !wc_get_product( $parent_id ) ){
							continue;
						}
					}
						
					$found_products[ $post_id ] = strip_tags( rawurldecode( $product->get_formatted_name() ) );
				}
			}
		}
		
		wp_send_json( $found_products );
	}
	/* End Backend */
	
	function add_fbt_to_cart(){
		if( !isset($_REQUEST['action']) || sanitize_text_field($_REQUEST['action']) != 'ts_fbt_add_to_cart' ){
			return;
		}
		
		if( !isset($_REQUEST['_wpnonce']) || !wp_verify_nonce( sanitize_text_field($_REQUEST['_wpnonce']), 'ts_fbt_nonce' ) ){
			return;
		}
		
		if( empty($_POST['ts-fbt-product-ids']) || !is_array($_POST['ts-fbt-product-ids']) ){
			return;
		}
		
		$message     = array();
		$product_ids = array_map('absint', $_POST['ts-fbt-product-ids']);
		
		wc_nocache_headers();
		
		foreach( $product_ids as $product_id ){
			$product = wc_get_product( $product_id );
			
			$variation_id = 0;
			$attr         = array();
			
			if( $product->get_type() == 'variation' ){
				$attr         = $product->get_variation_attributes();
				$variation_id = $product_id;
				$product_id   = $product->get_parent_id();
			}
			
			$cart_item_key = WC()->cart->add_to_cart( $product_id, 1, $variation_id, $attr );
			if( $cart_item_key ){
				$message[ $product_id ] = 1;
			}
		}
		
		if( !empty( $message ) ){
			wc_add_to_cart_message( $message );
		}
		
		if( get_option( 'woocommerce_cart_redirect_after_add' ) === 'yes' ){
			$url = wc_get_cart_url();
		}
		else{
			$url = remove_query_arg( array( 'action', '_wpnonce' ) );
		}

		wp_safe_redirect( esc_url( $url ) );
		
		exit;
	}
	
	function frequently_bought_together_fragments(){
		if( !isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'ts-fbt-nonce') ){
			die( __('Security check', 'themesky') );
		}
		else{
			$main_product_id = isset($_POST['main_product_id']) ? absint($_POST['main_product_id']) : 0;
			$variation_id 	 = isset($_POST['variation_id']) ? absint($_POST['variation_id']) : 0;
			$selected_ids 	 = !empty($_POST['selected_ids']) ? array_map('absint', explode(',', sanitize_text_field($_POST['selected_ids']))) : array();
			
			$data = array(
				'fragments'	=> array(
					'.ts-frequently-bought-together' => $this->bought_together_form($main_product_id, $variation_id, $selected_ids, false)
				)
			);
			wp_send_json( $data );
		}
	}
	
	function bought_together_form( $product_id = 0, $variation_id = 0, $selected_ids = array(), $echo = true ){
		global $product;
		if( $product_id ){
			$product = wc_get_product( $product_id );
		}
		
		if( !$product ){
			return '';
		}
		
		$product_type = $product->get_type();
		
		$product_ids = $this->get_product_ids( $product );
		
		if( empty($product_ids) || !in_array( $product_type, array('simple', 'variable') ) ){
			return '';
		}
		
		$main_product_id = $product->get_id();
		
		$form_action = $product->get_permalink();
		$form_action = add_query_arg( 'action', 'ts_fbt_add_to_cart', $form_action );
		$form_action = wp_nonce_url( $form_action, 'ts_fbt_nonce' );
		
		if( $product_type == 'variable' ){ /* Get selected variation or first variation */
			$variations = $product->get_children();
			if( empty( $variations ) ){
				return '';
			}
			
			if( $variation_id && in_array( $variation_id, $variations ) ){
				$product_id = $variation_id;
			}
			else{
				$product_id = array_shift( $variations );
			}
			$product = wc_get_product( $product_id );
		}
		
		$products = array();
		$products[] = $product;
		
		foreach( $product_ids as $id ){
			$_product = wc_get_product( $id );
			
			if( !$_product || !$_product->is_purchasable() || !$_product->is_in_stock() ){
				continue;
			}
			
			$products[] = $_product;
		}
		
		$total = 0;
		$total_regular_price = 0;
		$total_sale_price = 0;
		
		ob_start();
		?>
		<div class="ts-frequently-bought-together woocommerce" data-main_product_id="<?php echo esc_attr($main_product_id); ?>">
			<h3><?php echo esc_html( $this->get_settings('ts_fbt_heading', __('Frequently Bought Together', 'themesky')) ); ?></h3>
			<form class="ts-fbt-form" method="post" action="<?php echo esc_url($form_action); ?>">
				<div class="items">
				<?php
				$count = count( $products );
				
				foreach( $products as $i => $product ){
					$product_id = $product->get_id();
					$product_url = $product->get_permalink();
					
					$selected = true;
					if( $selected_ids && !in_array($product_id, $selected_ids) ){
						$selected = false;
						$count--;
					}
					else{
						$total += floatval( wc_get_price_to_display( $product ) );
					}
					
					if( $selected && $product->is_on_sale() ){
						$regular_price = $product->get_regular_price();
						$sale_price = $product->get_price();
						if( $regular_price ){
							$total_regular_price += floatval($regular_price);
							$total_sale_price += floatval($sale_price);
						}
					}
					
					if( $i > 0 ){
					?>
					<div class="plus"></div>
					<?php
					}

				?>
					<div class="item">
						<div class="product-wrapper">
							<div class="thumbnail-wrapper">
								<a href="<?php echo esc_url( $product_url ); ?>">
								<?php echo wp_kses_post( $product->get_image() ); ?>
								</a>
							</div>
							<div class="meta-wrapper">
								<?php
								if( taxonomy_exists('ts_product_brand') ){
									$main_product_id = $product_id;
									if( $product->get_type() == 'variation' ){
										$main_product_id = $product->get_parent_id();
									}
									echo get_the_term_list($main_product_id, 'ts_product_brand', '<div class="product-brands"><span class="brand-links">', ', ', '</span></div>');
								}
								?>
								<a href="<?php echo esc_url( $product_url ); ?>" class="product-name"><?php echo esc_html( $product->get_name() ); ?></a>
								<span class="price"><?php echo wp_kses_post( $product->get_price_html() ); ?></span>
							</div>
						</div>
						<label for="ts-fbt-product-ids-<?php echo esc_attr($product_id); ?>" class="<?php echo $selected ? 'selected' : ''; ?>">
							<input type="checkbox" id="ts-fbt-product-ids-<?php echo esc_attr($product_id); ?>" name="ts-fbt-product-ids[]" value="<?php echo esc_attr($product_id); ?>" <?php echo $selected ? 'checked="checked"' : '' ?>>
							<span><?php echo esc_html( $selected ? $this->get_settings('ts_fbt_selected_text') : $this->get_settings('ts_fbt_unselected_text') ); ?></span>
						</label>
					</div>
				<?php
				}
				?>
				</div>
				
				<div class="submit-wrapper">
					<?php 
					$total_label = $this->get_settings('ts_fbt_total_label');
					if( substr_count( $total_label, '%s' ) == 1 ){
						$total_label = sprintf($total_label, $count);
					}
					
					$add_to_cart_text = $this->get_settings('ts_fbt_add_to_cart_text');
					if( substr_count( $add_to_cart_text, '%s' ) == 1 ){
						$add_to_cart_text = sprintf($add_to_cart_text, $count);
					}
					?>
					<h6><?php echo esc_html($total_label); ?></h6>
					<?php if( $total_regular_price && $total_sale_price ){ ?>
					<span class="total-price-label"><?php echo esc_html( $this->get_settings('ts_fbt_discount_label') ); ?> <?php echo wc_price( $total_regular_price - $total_sale_price ); ?></span>
					<?php } ?>
					<span class="total-price"><?php echo wc_price($total); ?></span>
					<button type="submit" class="button"><?php echo esc_html($add_to_cart_text); ?></button>
				</div>
			</form>
		</div>
		<?php
		
		wp_reset_postdata();
		
		if( $echo ){
			echo ob_get_clean();
		}
		else{
			return ob_get_clean();
		}
	}
}

function TS_FBT(){
	return TS_Frequently_Bought_Together::instance();
}
TS_FBT();