<?php
use Elementor\Controls_Manager;

class TS_Elementor_Widget_Compare extends TS_Elementor_Widget_Base{
	public function get_name(){
        return 'ts-compare';
    }
	
	public function get_title(){
        return esc_html__( 'TS Compare', 'themesky' );
    }
	
	public function get_categories(){
        return array( 'ts-elements', 'woocommerce-elements' );
    }
	
	public function get_icon(){
		return 'eicon-exchange';
	}
	
	protected function register_controls(){
		$this->start_controls_section(
            'section_general'
            ,array(
                'label' 	=> esc_html__( 'General', 'themesky' )
                ,'tab'   	=> Controls_Manager::TAB_CONTENT
            )
        );
		
		$this->add_control(
            'info'
            ,array(
                'type' 			=> Controls_Manager::ALERT
                ,'alert_type' 	=> 'info'
				,'content' 		=> esc_html__( 'No need to set any option', 'themesky' )
            )
        );
		
		$this->end_controls_section();
	}
	
	protected function render(){
		if ( !class_exists('WooCommerce') || !shortcode_exists('ts_compare') ){
			return;
		}
		
		echo do_shortcode('[ts_compare]');
	}
}

$widgets_manager->register( new TS_Elementor_Widget_Compare() );