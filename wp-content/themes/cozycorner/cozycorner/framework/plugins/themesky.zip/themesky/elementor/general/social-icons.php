<?php
use Elementor\Controls_Manager;

class TS_Elementor_Widget_Social_Icons extends TS_Elementor_Widget_Base{
	public function get_name(){
        return 'ts-social-icons';
    }
	
	public function get_title(){
        return esc_html__( 'TS Social Icons', 'themesky' );
    }
	
	public function get_categories(){
        return array( 'ts-elements', 'general' );
    }
	
	public function get_icon(){
		return 'eicon-social-icons';
	}
	
	protected function register_controls(){
		$this->start_controls_section(
            'section_general'
            ,array(
                'label' 		=> esc_html__( 'General', 'themesky' )
                ,'tab'   		=> Controls_Manager::TAB_CONTENT
            )
        );
		
		$this->add_control(
            'title'
            ,array(
                'label' 		=> esc_html__( 'Title', 'themesky' )
                ,'type' 		=> Controls_Manager::TEXT
                ,'default' 		=> ''		
                ,'description' 	=> ''
            )
        );
		
		$this->add_control(
            'title_layout'
			,array(
				'label' 		=> esc_html__( 'Title Layout', 'themesky' )
				,'type' 		=> Controls_Manager::CHOOSE
				,'options' 		=> array(
					'vertical' 	=> array(
						'title' 	=> esc_html__( 'Vertical', 'themesky' )
						,'icon' 	=> 'eicon-arrow-down'
					)
					,'horizontal'	=> array(
						'title' 	=> esc_html__( 'Horizontal', 'themesky' )
						,'icon' 	=> 'eicon-arrow-right'
					)
				)
				,'default' 		=> 'vertical'
			)
        );
		
		$this->add_responsive_control(
            'alignment'
            ,array(
                'label' 		=> esc_html__( 'Alignment', 'themesky' )
                ,'type' 		=> Controls_Manager::CHOOSE
				,'options' => array(
					'flex-start' => array(
						'title' => esc_html__( 'Left', 'themesky' )
						,'icon' => 'eicon-text-align-left'
					)
					,'center' => array(
						'title' => esc_html__( 'Center', 'themesky' )
						,'icon' => 'eicon-text-align-center'
					)
					,'flex-end' => array(
						'title' => esc_html__( 'Right', 'themesky' )
						,'icon' => 'eicon-text-align-right'
					)
				)
				,'description' 	=> ''
				,'selectors' 	=> array(
					'{{WRAPPER}} .ts-social-icons-elementor-widget.title-horizontal' => 'justify-content: {{VALUE}}'
					,'{{WRAPPER}} .ts-social-icons-elementor-widget.title-vertical' => 'align-items: {{VALUE}}'
					,'{{WRAPPER}} .ts-social-icons-elementor-widget .list-items' => 'justify-content: {{VALUE}}'
				)
            )
        );

		$repeater = new Elementor\Repeater();

		$repeater->add_control(
			'social_icon'
			,array(
				'label' 	=> esc_html__( 'Icon', 'themesky' )
				,'type' 	=> Controls_Manager::ICONS
				,'default' 	=> array(
					'value' 	=> 'fab fa-wordpress'
					,'library' 	=> 'fa-brands'
				)
				,'recommended' => array(
					'fa-brands' => array(
						'android'
						,'apple'
						,'behance'
						,'bitbucket'
						,'codepen'
						,'delicious'
						,'deviantart'
						,'digg'
						,'dribbble'
						,'elementor'
						,'facebook'
						,'flickr'
						,'foursquare'
						,'free-code-camp'
						,'github'
						,'gitlab'
						,'globe'
						,'houzz'
						,'instagram'
						,'jsfiddle'
						,'linkedin'
						,'medium'
						,'meetup'
						,'mix'
						,'mixcloud'
						,'odnoklassniki'
						,'pinterest'
						,'product-hunt'
						,'reddit'
						,'shopping-cart'
						,'skype'
						,'slideshare'
						,'snapchat'
						,'soundcloud'
						,'spotify'
						,'stack-overflow'
						,'steam'
						,'telegram'
						,'thumb-tack'
						,'tripadvisor'
						,'tumblr'
						,'twitch'
						,'twitter'
						,'viber'
						,'vimeo'
						,'vk'
						,'weibo'
						,'weixin'
						,'whatsapp'
						,'wordpress'
						,'xing'
						,'yelp'
						,'youtube'
						,'500px'
					)
					,'fa-solid' => array(
						'envelope'
						,'link'
						,'rss'
					)
				)
			)
		);
		
		$repeater->add_control(
            'link'
            ,array(
                'label' 		=> esc_html__( 'Link', 'themesky' )
                ,'type' 		=> Controls_Manager::TEXT
                ,'default' 		=> ''		
                ,'description' 	=> ''
            )
        );
		
		$repeater->add_control(
            'name'
            ,array(
                'label' 		=> esc_html__( 'Social Name', 'themesky' )
                ,'type' 		=> Controls_Manager::TEXT
                ,'default' 		=> ''		
                ,'description' 	=> ''
            )
        );
		
		$repeater->add_control(
			'item_color_style'
			,array(
				'label' 	=> esc_html__( 'Color', 'themesky' )
				,'type' 	=> Controls_Manager::SELECT
				,'default' 	=> 'default'
				,'options' 	=> array(
					'default' 	=> esc_html__( 'Official Color', 'themesky' )
					,'custom' 	=> esc_html__( 'Custom', 'themesky' )
				)
			)
		);
		
		$repeater->add_control(
			'item_color'
			,array(
				'label' 		=> esc_html__( 'Item Color', 'themesky' )
				,'type' 		=> Controls_Manager::COLOR
				,'selectors' 	=> array(
					'{{WRAPPER}} .ts-social-icons-elementor-widget .list-items > span {{CURRENT_ITEM}}' => 'color: {{VALUE}};'
				)
				,'condition' 	=> array(
					'item_color_style' => 'custom'
				)
			)
		);
		
		$repeater->add_control(
			'item_border_color'
			,array(
				'label' 		=> esc_html__( 'Item Border Color', 'themesky' )
				,'type' 		=> Controls_Manager::COLOR
				,'selectors' 	=> array(
					'{{WRAPPER}} .ts-social-icons-elementor-widget.show-name .list-items > span {{CURRENT_ITEM}}' => 'border-color: {{VALUE}};'
				)
				,'condition' 	=> array(
					'item_color_style' => 'custom'
				)
			)
		);
		
		$repeater->add_control(
			'item_color_hover'
			,array(
				'label' 		=> esc_html__( 'Item Color Hover', 'themesky' )
				,'type' 		=> Controls_Manager::COLOR
				,'selectors' 	=> array(
					'.ts-social-icons-elementor-widget .list-items > span {{CURRENT_ITEM}}:hover' => 'color: {{VALUE}};'
				)
				,'condition' 	=> array(
					'item_color_style' => 'custom'
				)
			)
		);
		
		$repeater->add_control(
			'item_border_color_hover'
			,array(
				'label' 		=> esc_html__( 'Item Border Color Hover', 'themesky' )
				,'type' 		=> Controls_Manager::COLOR
				,'selectors' 	=> array(
					'{{WRAPPER}} .ts-social-icons-elementor-widget.show-name .list-items > span {{CURRENT_ITEM}}:hover' => 'border-color: {{VALUE}};'
				)
				,'condition' 	=> array(
					'item_color_style' => 'custom'
				)
			)
		);
		
		$this->add_control(
			'social_icon_list'
			,array(
				'label' 	=> esc_html__( 'Social Icons', 'themesky' )
				,'type' 	=> Controls_Manager::REPEATER
				,'fields' 	=> $repeater->get_controls()
				,'default' 	=> array(
					array(
						'social_icon' => array(
							'value' 	=> 'fab fa-facebook'
							,'library' 	=> 'fa-brands'
						)
					)
					,array(
						'social_icon' => array(
							'value' 	=> 'fab fa-twitter'
							,'library' 	=> 'fa-brands'
						)
					)
					,array(
						'social_icon' => array(
							'value' 	=> 'fab fa-youtube'
							,'library' 	=> 'fa-brands'
						)
					)
				)
				,'title_field' => '<# var migrated = "undefined" !== typeof __fa4_migrated, social = ( "undefined" === typeof social ) ? false : social; #>{{{ elementor.helpers.getSocialNetworkNameFromIcon( social_icon, social, true, migrated, true ) }}}'
			)
		);
		
		$this->add_control(
            'show_social_name'
            ,array(
                'label' 		=> esc_html__( 'Show Social Name', 'themesky' )
                ,'type' 		=> Controls_Manager::SWITCHER
                ,'default' 		=> '0'
				,'return_value' => '1'
				,'label_on'		=> esc_html__( 'Show', 'themesky' )
				,'label_off'	=> esc_html__( 'Hide', 'themesky' )			
                ,'description' 	=> ''
            )
        );
		
		$this->add_control(
            'hide_name_mobile'
            ,array(
                'label' 		=> esc_html__( 'Hide Social Name On Mobile', 'themesky' )
                ,'type' 		=> Controls_Manager::SWITCHER
                ,'default' 		=> '0'
				,'return_value' => '1'
				,'label_on'		=> esc_html__( 'Show', 'themesky' )
				,'label_off'	=> esc_html__( 'Hide', 'themesky' )			
                ,'description' 	=> ''
                ,'condition' 	=> array('show_social_name' => '1')
            )
        );

		$this->end_controls_section();
		
		$this->start_controls_section(
            'section_title_style'
            ,array(
                'label' 	=> esc_html__( 'Title', 'themesky' )
                ,'tab'   	=> Controls_Manager::TAB_STYLE
            )
        );
		
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type()
			,array(
				'label' 			=> esc_html__( 'Typography', 'themesky' )
				,'name' 			=> 'title_typography'
				,'selector'			=> '{{WRAPPER}} .ts-social-icons-elementor-widget .shortcode-heading-wrapper .shortcode-title'
				,'fields_options'	=> array(
					'font_size'			=> array(
						'default'		=> array(
							'size' 		=> '20'
							,'unit' 	=> 'px'
						)
						,'size_units' 	=> array( 'px', 'em', 'rem', 'vw' )
					)
					,'line_height'		=> array(
						'default' 		=> array(
							'size' 		=> '24'
							,'unit' 	=> 'px'
						)
					)
				)
			)
		);
		
		$this->add_control(
            'title_color'
            ,array(
                'label'     	=> esc_html__( 'Color', 'themesky' )
                ,'type'     	=> Controls_Manager::COLOR
				,'default'  	=> ''
				,'selectors'	=> array(
					'{{WRAPPER}} .ts-social-icons-elementor-widget .shortcode-heading-wrapper .shortcode-title' => 'color: {{VALUE}}'
				)
            )
        );
		
		$this->add_responsive_control(
			'title_gap'
			,array(
				'label' 	=> esc_html__( 'Title Gap', 'themesky' )
				,'type' 	=> Controls_Manager::SLIDER
				,'range' 	=> array(
					'px'	=> array(
						'min' 	=> 0
						,'max' 	=> 100
					)
				)
				,'size_units' 	=> array( 'px', '%', 'em', 'rem')
				,'default' 		=> array( 'unit' => 'px', 'size' => 25 )
				,'selectors' => array(
					'{{WRAPPER}} .ts-social-icons-elementor-widget'=> 'gap: {{SIZE}}{{UNIT}};'
				)
			)
		);
		
		$this->end_controls_section();
		
		$this->start_controls_section(
            'section_icons_style'
            ,array(
                'label' 	=> esc_html__( 'Icons', 'themesky' )
                ,'tab'   	=> Controls_Manager::TAB_STYLE
            )
        );

		$this->add_responsive_control(
			'icons_size'
			,array(
				'label' 	=> esc_html__( 'Icons Size', 'themesky' )
				,'type' 	=> Controls_Manager::SLIDER
				,'range' 	=> array(
					'px'	=> array(
						'min' 	=> 0
						,'max' 	=> 100
					)
				)
				,'size_units' 	=> array( 'px', '%', 'em', 'rem')
				,'default' 		=> array( 'unit' => 'px', 'size' => 20 )
				,'selectors' => array(
					'{{WRAPPER}} .ts-social-icons-elementor-widget .elementor-icon.elementor-social-icon i'=> 'font-size: {{SIZE}}{{UNIT}};'
				)
			)
		);
		
		$this->add_responsive_control(
			'icons_gap'
			,array(
				'label' 	=> esc_html__( 'Items Gap', 'themesky' )
				,'type' 	=> Controls_Manager::SLIDER
				,'range' 	=> array(
					'px'	=> array(
						'min' 	=> 0
						,'max' 	=> 100
					)
				)
				,'size_units' 	=> array( 'px', '%', 'em', 'rem')
				,'default' 		=> array( 'unit' => 'px', 'size' => 20 )
				,'selectors' => array(
					'{{WRAPPER}} .ts-social-icons-elementor-widget .list-items'=> 'gap: {{SIZE}}{{UNIT}};'
				)
			)
		);
		
		$this->start_controls_tabs(
			'style_tabs'
		);
		
		$this->start_controls_tab(
			'style_normal_tab'
			,array(
				'label' 		=> esc_html__( 'Normal', 'themesky' )
			)
		);
		
		$this->add_control(
            'icons_color'
            ,array(
                'label'     	=> esc_html__( 'Items Color', 'themesky' )
                ,'type'     	=> Controls_Manager::COLOR
				,'default'  	=> ''
				,'selectors'	=> array(
					'{{WRAPPER}} .ts-social-icons-elementor-widget .list-items > span > a' => 'color: {{VALUE}}'
				)
            )
        );
		
		$this->add_control(
            'icons_border_color'
            ,array(
                'label'     	=> esc_html__( 'Items Border Color', 'themesky' )
                ,'type'     	=> Controls_Manager::COLOR
				,'default'  	=> ''
				,'condition'  	=> array('show_social_name' => '1')
				,'selectors'	=> array(
					'{{WRAPPER}} .ts-social-icons-elementor-widget.show-name .list-items > span > a' => 'border-color: {{VALUE}}'
				)
            )
        );
		
		$this->end_controls_tab();
		
		$this->start_controls_tab(
			'style_hover_tab'
			,array(
				'label' 		=> esc_html__( 'Hover', 'themesky' )
			)
		);
		
		$this->add_control(
            'icons_hover_color'
            ,array(
                'label'     	=> esc_html__( 'Items Color', 'themesky' )
                ,'type'     	=> Controls_Manager::COLOR
				,'default'  	=> ''
				,'selectors'	=> array(
					'{{WRAPPER}} .ts-social-icons-elementor-widget .list-items > span > a:hover' => 'color: {{VALUE}}'
				)
            )
        );
		
		$this->add_control(
            'icons_hover_border_color'
            ,array(
                'label'     	=> esc_html__( 'Items Border Color', 'themesky' )
                ,'type'     	=> Controls_Manager::COLOR
				,'default'  	=> ''
				,'condition'  	=> array('show_social_name' => '1')
				,'selectors'	=> array(
					'{{WRAPPER}} .ts-social-icons-elementor-widget.show-name .list-items > span > a:hover' => 'border-color: {{VALUE}}'
				)
            )
        );
		
		$this->end_controls_tab();
		
		$this->end_controls_section();
	}
	
	protected function render(){
		$settings = $this->get_settings_for_display();
		
		$default = array(
			'title'						=> ''
			,'title_layout'				=> 'vertical'
			,'social_icon_list'			=> array()
			,'show_social_name'			=> 0
			,'hide_name_mobile'			=> 0
			,'hover_animation'			=> ''
		);
		
		$settings = wp_parse_args( $settings, $default );
		
		extract( $settings );
		
		$classes = array('ts-social-icons-elementor-widget social-icons');
		$classes[] = 'title-' . $title_layout;
		
		if( $show_social_name ){
			$classes[] = 'show-name';
			
			if( $hide_name_mobile ){
				$classes[] = 'hide-name-mobile';
			}
		}
		?>
		<div class="<?php echo implode(' ', $classes); ?>">
			<?php if( $title ): ?>
			<header class="shortcode-heading-wrapper">
				<h2 class="shortcode-title">
					<?php echo esc_html($title); ?>
				</h2>
			</header>
			<?php endif; ?>
			
			<div class="list-items">
			<?php
			foreach( $social_icon_list as $index => $item ){
				$social = '';
				if( 'svg' !== $item['social_icon']['library'] ){
					$social = explode( ' ', $item['social_icon']['value'], 2 );
					if( empty( $social[1] ) ){
						$social = '';
					}else{
						$social = str_replace( 'fa-', '', $social[1] );
						$social = str_replace( 'icomoon-', '', $social );
					}
				}
				
				if( 'svg' === $item['social_icon']['library'] ){
					$social = get_post_meta( $item['social_icon']['value']['id'], '_wp_attachment_image_alt', true );
				}
				
				$item_class = array('elementor-icon elementor-social-icon');
				$item_class[] = 'elementor-social-icon-' . $social;
				$item_class[] = 'elementor-repeater-item-' . $item['_id'];
				$item_class[] = 'elementor-animation-' . $hover_animation;
				?>
				<span>
					<a href="<?php echo esc_url($item['link']) ?>" target="_blank" class="<?php echo implode(' ', $item_class); ?>">
						<?php Elementor\Icons_Manager::render_icon( $item['social_icon'] ); ?>
						<?php if( $item['name'] && $show_social_name ){ ?>
							<span class="social-name"><?php echo esc_html($item['name']); ?></span>
						<?php } ?>
					</a>
				</span>
				<?php
			}
			?>
			</div>
		</div>
		<?php
	}
}

$widgets_manager->register( new TS_Elementor_Widget_Social_Icons() );