<?php
use Elementor\Controls_Manager;

class TS_Elementor_Widget_Product_Color extends TS_Elementor_Widget_Base{
	public function get_name(){
        return 'ts-product-color';
    }
	
	public function get_title(){
        return esc_html__( 'TS Product Color', 'themesky' );
    }
	
	public function get_categories(){
        return array( 'ts-elements', 'general' );
    }
	
	public function get_icon(){
		return 'eicon-navigation-horizontal';
	}
	
	protected function register_controls(){
		$this->start_controls_section(
            'section_general'
            ,array(
                'label' 	=> esc_html__( 'General', 'themesky' )
                ,'tab'   	=> Controls_Manager::TAB_CONTENT
            )
        );
		
		$this->add_control(
            'info'
            ,array(
                'type' 			=> Controls_Manager::ALERT
                ,'alert_type' 	=> 'info'
				,'content' 		=> esc_html__( 'Show colors of product color attribute. The slug of attribute has to be "color"', 'themesky' )
            )
        );
		
		$this->add_control(
            'except_colors'
            ,array(
                'label' 		=> esc_html__( 'Except Colors', 'themesky' )
                ,'type' 		=> 'ts_autocomplete'
                ,'default' 		=> array()
				,'options'		=> array()
				,'autocomplete'	=> array(
					'type'		=> 'taxonomy'
					,'name'		=> 'pa_color'
				)
				,'multiple' 	=> true
				,'sortable' 	=> false
				,'label_block' 	=> true
            )
        );
		
		$this->add_control(
            'limit'
            ,array(
                'label'     	=> esc_html__( 'Limit', 'themesky' )
                ,'type'     	=> Controls_Manager::NUMBER
				,'default'  	=> 6
				,'min'      	=> 0
				,'description' 	=> esc_html__( 'Maximum number of terms to return. Set 0 to get all.', 'themesky' )
            )
        );
		
		$this->add_control(
            'hide_empty'
            ,array(
                'label' 		=> esc_html__( 'Hide empty color attributes', 'themesky' )
                ,'type' 		=> Controls_Manager::SWITCHER
                ,'default' 		=> '1'
				,'return_value' => '1'
				,'label_on'		=> esc_html__( 'Yes', 'themesky' )
				,'label_off'	=> esc_html__( 'No', 'themesky' )			
                ,'description' 	=> ''
            )
        );
		
		$this->add_control(
            'target'
            ,array(
                'label' 		=> esc_html__( 'Link Target', 'themesky' )
                ,'type' 		=> Controls_Manager::SELECT
                ,'default' 		=> '_self'
				,'options'		=> array(
									'_blank'	=> esc_html__( 'New Window Tab', 'themesky' )
									,'_self'	=> esc_html__( 'Self', 'themesky' )
								)			
                ,'description' => ''
            )
        );
		
		$this->end_controls_section();
		
		$this->start_controls_section(
            'section_style'
            ,array(
                'label' 	=> esc_html__( 'General', 'themesky' )
                ,'tab'   	=> Controls_Manager::TAB_STYLE
            )
        );
		
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type()
			,array(
				'label' 			=> esc_html__( 'Typography', 'themesky' )
				,'name' 			=> 'text_typography'
				,'selector'			=> '{{WRAPPER}} .ts-product-color.product-filter-by-color ul li a'
			)
		);
		
		$this->add_responsive_control(
            'layout'
            ,array(
                'label' 		=> esc_html__( 'Layout', 'themesky' )
                ,'type' 		=> Controls_Manager::CHOOSE
				,'default' 		=> 'row'
				,'options' 		=> array(
					'column' => array(
						'title' => esc_html__( 'Column', 'themesky' )
						,'icon' => 'eicon-arrow-down'
					)
					,'row' => array(
						'title' => esc_html__( 'Row', 'themesky' )
						,'icon' => 'eicon-arrow-right'
					)
				)
				,'selectors' => array(
					'{{WRAPPER}} .product-filter-by-color ul' => 'flex-direction: {{VALUE}}'
				)
            )
        );
		
		$this->add_responsive_control(
			'item_padding'
			,array(
				'type' => Controls_Manager::DIMENSIONS
				,'label' => esc_html__( 'Item Padding', 'themesky' )
				,'size_units' => array( 'px', '%', 'em', 'rem' )
				,'selectors' => array(
					'{{WRAPPER}} .product-filter-by-color ul li a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
				)
			)
		);
		
		$this->add_responsive_control(
			'items_gap'
			,array(
				'type' => Controls_Manager::GAPS
				,'label' => esc_html__( 'Items Gap', 'themesky' )
				,'size_units' => array( 'px', '%', 'em', 'rem', 'vw', 'custom' )
				,'default' => array(
					'column' => 10
					,'row' => 10
					,'isLinked' => true
					,'unit' => 'px'
				)
				,'selectors' => array(
					'{{WRAPPER}} .ts-product-color.product-filter-by-color ul' => 'gap: {{ROW}}{{UNIT}} {{COLUMN}}{{UNIT}}'
				)
			)
		);
		
		$this->add_responsive_control(
			'color_size'
			,array(
				'label' 	=> esc_html__( 'Color Size', 'themesky' )
				,'type' 	=> Controls_Manager::SLIDER
				,'range' 	=> array(
					'px'	=> array(
						'min' 	=> 0
						,'max' 	=> 100
					)
				)
				,'size_units' 	=> array( 'px' )
				,'selectors' 	=> array(
					'{{WRAPPER}} .product-filter-by-color ul li a > img, {{WRAPPER}} .product-filter-by-color ul li a > span:not(.color-name)' => 'width: {{SIZE}}{{UNIT}};'
				)
			)
		);
		
		$this->start_controls_tabs(
			'style_tabs'
		);
		
		$this->start_controls_tab(
			'style_normal_tab'
			,array(
				'label' 		=> esc_html__( 'Normal', 'themesky' )
			)
		);
		
		$this->add_control(
            'item_text_color'
            ,array(
                'label'     	=> esc_html__( 'Text Color', 'themesky' )
                ,'type'     	=> Controls_Manager::COLOR
				,'default'  	=> ''
				,'selectors'	=> array(
					'{{WRAPPER}} .product-filter-by-color ul li a' => 'color: {{VALUE}};'
				)
            )
        );
		
		$this->add_control(
            'item_bg_color'
            ,array(
                'label'     	=> esc_html__( 'Background Color', 'themesky' )
                ,'type'     	=> Controls_Manager::COLOR
				,'default'  	=> ''
				,'selectors'	=> array(
					'{{WRAPPER}} .product-filter-by-color ul li a' => 'background: {{VALUE}};'
				)
            )
        );

		$this->add_control(
            'item_border_color'
            ,array(
                'label'     	=> esc_html__( 'Border Color', 'themesky' )
                ,'type'     	=> Controls_Manager::COLOR
				,'default'  	=> ''
				,'selectors'	=> array(
					'{{WRAPPER}} .product-filter-by-color ul li a' => 'border-color: {{VALUE}};'
				)
            )
        );
		
		$this->end_controls_tab();
		
		$this->start_controls_tab(
			'style_hover_tab'
			,array(
				'label' 		=> esc_html__( 'Hover', 'themesky' )
			)
		);
		
		$this->add_control(
            'item_text_color_hover'
            ,array(
                'label'     	=> esc_html__( 'Text Color', 'themesky' )
                ,'type'     	=> Controls_Manager::COLOR
				,'default'  	=> ''
				,'selectors'	=> array(
					'{{WRAPPER}} .product-filter-by-color ul li a:hover' => 'color: {{VALUE}};'
				)
            )
        );
		
		$this->add_control(
            'item_bg_color_hover'
            ,array(
                'label'     	=> esc_html__( 'Background Color', 'themesky' )
                ,'type'     	=> Controls_Manager::COLOR
				,'default'  	=> ''
				,'selectors'	=> array(
					'{{WRAPPER}} .product-filter-by-color ul li a:hover' => 'background: {{VALUE}};'
				)
            )
        );

		$this->add_control(
            'item_border_color_hover'
            ,array(
                'label'     	=> esc_html__( 'Border Color', 'themesky' )
                ,'type'     	=> Controls_Manager::COLOR
				,'default'  	=> ''
				,'selectors'	=> array(
					'{{WRAPPER}} .product-filter-by-color ul li a:hover' => 'border-color: {{VALUE}};'
				)
            )
        );
		
		$this->end_controls_tab();
		
		$this->end_controls_section();
	}
	
	protected function render(){
		$settings = $this->get_settings_for_display();
		
		$default = array(
			'except_colors'	=> array()
			,'hide_empty'	=> 1
			,'limit' 		=> 6
			,'target'		=> '_self'
		);
		
		$settings = wp_parse_args( $settings, $default );
		
		extract( $settings );
		
		if( !class_exists('WooCommerce') ){
			return;
		}
		
		$taxonomy = 'pa_color';
		
		if( !taxonomy_exists($taxonomy) ){
			return;
		}
		
		$args = array(
			'taxonomy' 		=> $taxonomy
			,'hide_empty'	=> $hide_empty
			,'meta_key'   	=> 'order'
			,'orderby'    	=> 'meta_value_num'
			,'number' 		=> $limit
		);
		
		if( !empty($except_colors) ){
			$args['exclude'] = $except_colors;
		}
		
		$terms = get_terms( $args );
		if( !is_array($terms) || empty($terms) ){
			return;
		}
		
		$base_url = wc_get_page_permalink( 'shop' );
		?>
		<div class="ts-product-color product-filter-by-color">
			<ul>
			<?php
			foreach( $terms as $term ){
				$link = add_query_arg( 'filter_color', $term->slug, $base_url );
				
				$datas = get_term_meta( $term->term_id, 'ts_product_color_config', true );
				if( strlen($datas) > 0 ){
					$datas = unserialize($datas);	
				}else{
					$datas = array(
								'ts_color_color' 				=> "#ffffff"
								,'ts_color_image' 				=> 0
							);
				}
				?>
				<li>
					<a href="<?php echo esc_url( $link ); ?>" target="<?php echo esc_attr( $target ) ?>">
						<?php
						if( absint($datas['ts_color_image']) > 0 ){
							echo wp_get_attachment_image( absint($datas['ts_color_image']), 'ts_prod_color_thumb', true, array( 'title' => $term->name, 'alt' => $term->name ) );
						}else{
							$style = 'background-color:'. $datas['ts_color_color'] .';';
							if( $datas['ts_color_color'] == '#ffffff' ){
								$style .= ' border-color: var(--ts-border);';
							}
							if( $datas['ts_color_color'] == '#000000' ){
								$style .= ' border-color: #ffffff;';
							}
							echo '<span style="'. $style .'"></span>';
						}
						?>
						<span class="color-name"><?php echo esc_html( $term->name ) ?></span>
					</a>
				</li>
				<?php
			}
			?>
			</ul>
		</div>
		<?php
	}
}

$widgets_manager->register( new TS_Elementor_Widget_Product_Color() );