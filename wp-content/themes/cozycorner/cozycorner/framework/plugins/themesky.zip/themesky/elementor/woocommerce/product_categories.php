<?php
use Elementor\Controls_Manager;

class TS_Elementor_Widget_Product_Categories extends TS_Elementor_Widget_Base{
	public function get_name(){
        return 'ts-product-categories';
    }
	
	public function get_title(){
        return esc_html__( 'TS Product Categories', 'themesky' );
    }
	
	public function get_categories(){
        return array( 'ts-elements', 'woocommerce-elements' );
    }
	
	public function get_icon(){
		return 'eicon-product-categories';
	}
	
	protected function register_controls(){
		$this->start_controls_section(
            'section_general'
            ,array(
                'label' 	=> esc_html__( 'General', 'themesky' )
                ,'tab'   	=> Controls_Manager::TAB_CONTENT
            )
        );
		
		$this->add_lazy_load_controls( array( 'thumb-height' => 145 ) );
		
		$this->add_control(
            'title'
            ,array(
                'label' 		=> esc_html__( 'Title', 'themesky' )
                ,'type' 		=> Controls_Manager::TEXT
                ,'default' 		=> ''		
                ,'description' 	=> ''
            )
        );
		
		$this->add_control(
            'style'
            ,array(
                'label' 		=> esc_html__( 'Style', 'themesky' )
                ,'type' 		=> Controls_Manager::SELECT
                ,'default' 		=> 'default'
				,'options'		=> array(
									'default'			=> esc_html__( 'Default', 'themesky' )
									,'default-bg'		=> esc_html__( 'Default Has Background', 'themesky' )
									,'icon'				=> esc_html__( 'Icon', 'themesky' )
									,'auto-width'		=> esc_html__( 'Auto Width', 'themesky' )
									,'big-text'			=> esc_html__( 'Big Text', 'themesky' )
								)			
                ,'description' 	=> ''
            )
        );
		
		$this->add_control(
            'layout_partial'
            ,array(
                'label' 		=> esc_html__( 'Layout Partial View', 'themesky' )
                ,'type' 		=> Controls_Manager::SWITCHER
                ,'default' 		=> '0'
				,'return_value' => '1'
				,'label_on'		=> 	esc_html__( 'Show', 'themesky' )
				,'label_off'	=> 	esc_html__( 'Hide', 'themesky' )	
                ,'description' 	=> ''
            )
        );
		
		$this->add_responsive_control(
			'margin_right'
			,array(
				'label' 	=> esc_html__( 'Partial Right Length', 'themesky' )
				,'type' 	=> Controls_Manager::SLIDER
				,'range' 	=> array(
					'px'	=> array(
						'min' 	=> 0
						,'max' 	=> 1000
					)
				)
				,'size_units' => array( 'px', '%', 'em', 'rem' )
				,'default' 		=> array( 'unit' => 'px', 'size' => 278 )
				,'condition'	=> array('layout_partial' => '1')
				,'selectors' 	=> array(
					'{{WRAPPER}} .ts-product.partial-right .content-wrapper, {{WRAPPER}} .placeholder-items.partial-right' => 'margin-left: 0; margin-right: calc(-50vw + 50% - {{SIZE}}{{UNIT}});'
					,'body.rtl {{WRAPPER}} .ts-product.partial-right .content-wrapper, body.rtl {{WRAPPER}} .placeholder-items.partial-right' => 'margin-left: calc(-50vw + 50% - {{SIZE}}{{UNIT}}); margin-right: 0;'
					,'{{WRAPPER}} .ts-product.partial-right .swiper-pagination-bullets.swiper-pagination-horizontal' => 'margin-left: calc({{SIZE}}{{UNIT}} * -0.5);'
					,'body.rtl {{WRAPPER}} .ts-product.partial-right .swiper-pagination-bullets.swiper-pagination-horizontal' => ' margin-left: 0;margin-right: calc({{SIZE}}{{UNIT}} * -0.5);'
				)
			)
		);
		
		$this->add_control(
            'item_direction'
            ,array(
                'label' 		=> esc_html__( 'Item Direction', 'themesky' )
                ,'type' 		=> Controls_Manager::CHOOSE
                ,'default' 		=> 'vertical'
				,'options'		=> array(
					'vertical' => array(
						'title' => esc_html__( 'Vertical', 'textdomain' )
						,'icon' => 'eicon-arrow-down'
					)
					,'horizontal' => array(
						'title' => esc_html__( 'Horizontal', 'textdomain' )
						,'icon' => 'eicon-arrow-right'
					)
				)					
                ,'description' 	=> ''
				,'condition'	=> array( 'style' => array('icon', 'default-bg', 'auto-width', 'big-text') )
            )
        );
		
		$this->add_control(
            'ids'
            ,array(
                'label' 		=> esc_html__( 'Specific categories', 'themesky' )
                ,'type' 		=> 'ts_autocomplete'
                ,'default' 		=> array()
				,'options'		=> array()
				,'autocomplete'	=> array(
					'type'		=> 'taxonomy'
					,'name'		=> 'product_cat'
				)
				,'multiple' 	=> true
				,'label_block' 	=> true
				,'description' 	=> esc_html__( 'Only show the categories that you choosed.', 'themesky' )
            )
        );
		
		$this->add_control(
            'columns'
            ,array(
                'label'     	=> esc_html__( 'Columns', 'themesky' )
                ,'type'     	=> Controls_Manager::NUMBER
				,'default'  	=> 8
				,'min'      	=> 1
				,'description' 	=> esc_html__( 'Do not support the Auto Width and Big Text (Horizontal) styles', 'themesky' )
            )
        );
		
		$this->add_control(
            'limit'
            ,array(
                'label'     	=> esc_html__( 'Limit', 'themesky' )
                ,'type'     	=> Controls_Manager::NUMBER
				,'default'  	=> 8
				,'min'      	=> 1
            )
        );
		
		$this->add_control(
            'parent'
            ,array(
                'label' 		=> esc_html__( 'Parent', 'themesky' )
                ,'type' 		=> 'ts_autocomplete'
                ,'default' 		=> array()
				,'options'		=> array()
				,'autocomplete'	=> array(
					'type'		=> 'taxonomy'
					,'name'		=> 'product_cat'
				)
				,'multiple' 	=> false
				,'sortable' 	=> false
				,'label_block' 	=> true
				,'description' 	=> esc_html__( 'Get direct children of this category', 'themesky' )
				,'condition'	=> array( 'first_level!' => '1' )
            )
        );
		
		$this->add_control(
            'child_of'
            ,array(
                'label' 		=> esc_html__( 'Child of', 'themesky' )
                ,'type' 		=> 'ts_autocomplete'
                ,'default' 		=> array()
				,'options'		=> array()
				,'autocomplete'	=> array(
					'type'		=> 'taxonomy'
					,'name'		=> 'product_cat'
				)
				,'multiple' 	=> false
				,'sortable' 	=> false
				,'label_block' 	=> true
				,'description' 	=> esc_html__( 'Get all descendents of this category', 'themesky' )
				,'condition'	=> array( 'first_level!' => '1' )
            )
        );

		$this->add_control(
            'hide_empty'
            ,array(
                'label' 		=> esc_html__( 'Hide empty product categories', 'themesky' )
                ,'type' 		=> Controls_Manager::SWITCHER
                ,'default' 		=> '1'
				,'return_value' => '1'
				,'label_on'		=> esc_html__( 'Yes', 'themesky' )
				,'label_off'	=> esc_html__( 'No', 'themesky' )			
                ,'description' 	=> ''
            )
        );

		$this->add_control(
            'first_level'
            ,array(
                'label' 		=> esc_html__( 'Only display the first level', 'themesky' )
                ,'type' 		=> Controls_Manager::SWITCHER
                ,'default' 		=> '0'
				,'return_value' => '1'			
                ,'description' 	=> ''
            )
        );
		
		$this->add_control(
            'show_cat_img'
            ,array(
                'label' 		=> esc_html__( 'Show Category Image/Icon', 'themesky' )
                ,'type' 		=> Controls_Manager::SWITCHER
                ,'default' 		=> '1'
				,'return_value' => '1'
				,'label_on'		=> 	esc_html__( 'Show', 'themesky' )
				,'label_off'	=> 	esc_html__( 'Hide', 'themesky' )			
                ,'description' 	=> ''
            )
        );
		
		$this->add_control(
            'show_title'
            ,array(
                'label' 		=> esc_html__( 'Show Category Name', 'themesky' )
                ,'type' 		=> Controls_Manager::SWITCHER
                ,'default' 		=> '1'
				,'return_value' => '1'
				,'label_on'		=> 	esc_html__( 'Show', 'themesky' )
				,'label_off'	=> 	esc_html__( 'Hide', 'themesky' )			
                ,'description' 	=> ''
            )
        );

		$this->add_control(
            'show_product_count'
            ,array(
                'label' 		=> esc_html__( 'Show Product Count', 'themesky' )
                ,'type' 		=> Controls_Manager::SWITCHER
                ,'default' 		=> '0'
				,'return_value' => '1'
				,'label_on'		=> 	esc_html__( 'Show', 'themesky' )
				,'label_off'	=> 	esc_html__( 'Hide', 'themesky' )			
                ,'description' 	=> ''
            )
        );
		
		$this->end_controls_section();
		
		$this->start_controls_section(
            'section_slider'
            ,array(
                'label' 	=> esc_html__( 'Slider', 'themesky' )
                ,'tab'   	=> Controls_Manager::TAB_CONTENT
            )
        );

		$this->add_product_slider_controls(false);
		
		$this->end_controls_section();

		$this->start_controls_section(
            'section_style'
            ,array(
                'label' 	=> esc_html__( 'Shortcode Title', 'themesky' )
                ,'tab'   	=> Controls_Manager::TAB_STYLE
            )
        );
		
		$this->add_control(
            's_title_group'
            ,array(
                'label'     	=> esc_html__( 'Title', 'themesky' )
                ,'type' 		=> Controls_Manager::HEADING		
                ,'description' 	=> ''
            )
        );
		
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type()
			,array(
				'label' 			=> esc_html__( 'Title Typography', 'themesky' )
				,'name' 			=> 's_title_typography'
				,'selector'			=> '{{WRAPPER}} .shortcode-title'
			)
		);
		
		$this->add_control(
            's_title_color'
            ,array(
                'label'     	=> esc_html__( 'Title Text Color', 'themesky' )
                ,'type'     	=> Controls_Manager::COLOR
				,'default'  	=> ''
				,'selectors'	=> array(
					'{{WRAPPER}} .shortcode-title' => 'color: {{VALUE}}'
				)
            )
        );
		
		$this->add_responsive_control(
            'text_align_title'
            ,array(
                'label' 		=> esc_html__( 'Title Alignment', 'themesky' )
                ,'type' 		=> Controls_Manager::CHOOSE
				,'options' => array(
					'left' => array(
						'title' => esc_html__( 'Left', 'themesky' )
						,'icon' => 'eicon-text-align-left'
					)
					,'center' => array(
						'title' => esc_html__( 'Center', 'themesky' )
						,'icon' => 'eicon-text-align-center'
					)
					,'right' => array(
						'title' => esc_html__( 'Right', 'themesky' )
						,'icon' => 'eicon-text-align-right'
					)
				)
				,'description' 	=> ''
				,'selectors' => array(
					'{{WRAPPER}} .shortcode-heading-wrapper .shortcode-title' => 'text-align: {{VALUE}}'
					,'{{WRAPPER}} .ts-elementor-lazy-load .placeholder-widget-title' => 'text-align: {{VALUE}}'
				)
            )
        );
		
		$this->end_controls_section();
		
		$this->start_controls_section(
            'section_items_style'
            ,array(
                'label' 	=> esc_html__( 'Items', 'themesky' )
                ,'tab'   	=> Controls_Manager::TAB_STYLE
            )
        );
		
		$this->add_control(
            's_items_group'
            ,array(
                'label'     	=> esc_html__( 'Items', 'themesky' )
                ,'type' 		=> Controls_Manager::HEADING		
                ,'description' 	=> ''
            )
        );
		
		$this->add_responsive_control(
            'h_align'
            ,array(
                'label' 		=> esc_html__( 'Horizontal Align', 'themesky' )
                ,'type' 		=> Controls_Manager::CHOOSE
				,'default' 		=> 'flex-start'
				,'options' 		=> array(
					'flex-start' => array(
						'title' => esc_html__( 'Top', 'themesky' )
						,'icon' => 'eicon-h-align-left'
					)
					,'center' => array(
						'title' => esc_html__( 'Middle', 'themesky' )
						,'icon' => 'eicon-h-align-center'
					)
					,'flex-end' => array(
						'title' => esc_html__( 'Bottom', 'themesky' )
						,'icon' => 'eicon-h-align-right'
					)
				)
				,'selectors' => array(
					'{{WRAPPER}} .woocommerce .products' => 'justify-content: {{VALUE}}'
				)
            )
        );
		
		$this->add_responsive_control(
			'items_gap'
			,array(
				'type' => Controls_Manager::GAPS
				,'label' => esc_html__( 'Items Gap', 'themesky' )
				,'size_units' => array( 'px', '%', 'em', 'rem', 'vw', 'custom' )
				,'default' => array(
					'column' => 20
					,'row' => 20
					,'isLinked' => true
					,'unit' => 'px'
				)
				,'selectors' => array(
					'{{WRAPPER}} .ts-product-category-wrapper .products:not(.swiper)'=> 'gap: {{ROW}}{{UNIT}} {{COLUMN}}{{UNIT}};'
					,'{{WRAPPER}} .ts-product-category-wrapper .products.swiper .product-category'=> 'padding-left: calc({{COLUMN}}{{UNIT}}/2);padding-right: calc({{COLUMN}}{{UNIT}}/2);'
					,'{{WRAPPER}} .ts-product-category-wrapper .products.swiper' => 'margin-left: calc(-{{COLUMN}}{{UNIT}}/2);margin-right: calc(-{{COLUMN}}{{UNIT}}/2);width: calc(100% + {{COLUMN}}{{UNIT}});'
				)
			)
		);
		
		$this->add_control(
			'ts_hr_2'
			,array(
                'type' 		=> Controls_Manager::DIVIDER
            )
		);
		
		$this->add_control(
            's_item_group'
            ,array(
                'label'     	=> esc_html__( 'Item', 'themesky' )
                ,'type' 		=> Controls_Manager::HEADING		
                ,'description' 	=> ''
            )
        );
		
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type()
			,array(
				'label' 			=> esc_html__( 'Category Name Typography', 'themesky' )
				,'name' 			=> 'cat_title_typography'
				,'selector'			=> '{{WRAPPER}} .product-category-wrapper .category-name'
			)
		);
		
		$this->start_controls_tabs(
			'style_tabs'
		);
		
		$this->start_controls_tab(
			'style_normal_tab'
			,array(
				'label' 		=> esc_html__( 'Normal', 'themesky' )
			)
		);
		
		$this->add_control(
            'item_text_color'
            ,array(
                'label'     	=> esc_html__( 'Text Color', 'themesky' )
                ,'type'     	=> Controls_Manager::COLOR
				,'default'  	=> ''
				,'selectors'	=> array(
					'{{WRAPPER}} .product-category-wrapper .category-name' => 'color: {{VALUE}};'
					,'{{WRAPPER}} :where(.style-icon, .style-auto-width).direction-horizontal .product-category-wrapper' => 'border-color: {{VALUE}};'
				)
            )
        );
		
		$this->add_control(
            'btn_text_color'
            ,array(
                'label'     	=> esc_html__( 'Button Text Color', 'themesky' )
                ,'type'     	=> Controls_Manager::COLOR
				,'default'  	=> ''
				,'condition'	=> array( 'style' => 'big-text' )
				,'selectors'	=> array(
					'{{WRAPPER}} .style-big-text .product-category-wrapper .meta-btn' => 'color: {{VALUE}}; border-color: {{VALUE}};'
				)
            )
        );
		
		$this->add_control(
            'btn_bg_color'
            ,array(
                'label'     	=> esc_html__( 'Button Background Color', 'themesky' )
                ,'type'     	=> Controls_Manager::COLOR
				,'default'  	=> ''
				,'condition'	=> array( 'style' => 'big-text' )
				,'selectors'	=> array(
					'{{WRAPPER}} .style-big-text .product-category-wrapper .meta-btn' => 'background-color: {{VALUE}};'
				)
            )
        );
		
		$this->add_control(
            'item_bg_color'
            ,array(
                'label'     	=> esc_html__( 'Background Color', 'themesky' )
                ,'type'     	=> Controls_Manager::COLOR
				,'default'  	=> ''
				,'conditions' => array(
					'relation' => 'or'
					,'terms' => array(
						array(
							'name' => 'style'
							,'operator' => '=='
							,'value' => 'default-bg'
						)
						,array(
							'relation' => 'and'
							,'terms' => array(
								array(
									'name' => 'style'
									,'operator' => 'in'
									,'value' => array('icon', 'auto-width')
								)
								,array(
									'name' => 'item_direction'
									,'operator' => '=='
									,'value' => 'horizontal'
								)
							)
						)
					)
				)
				,'selectors'	=> array(
					'{{WRAPPER}} .style-default-bg .product-category-wrapper > a:before' => 'background: {{VALUE}};'
					,'{{WRAPPER}} :where(.style-icon, .style-auto-width).direction-horizontal .product-category-wrapper' => 'background: {{VALUE}};'
				)
            )
        );

		$this->add_control(
            'item_border_color'
            ,array(
                'label'     	=> esc_html__( 'Border Color', 'themesky' )
                ,'type'     	=> Controls_Manager::COLOR
				,'default'  	=> ''
				,'conditions' => array(
					'relation' => 'or'
					,'terms' => array(
						array(
							'name' => 'style'
							,'operator' => '=='
							,'value' => 'default-bg'
						)
						,array(
							'relation' => 'and'
							,'terms' => array(
								array(
									'name' => 'style'
									,'operator' => 'in'
									,'value' => array('icon', 'auto-width')
								)
								,array(
									'name' => 'item_direction'
									,'operator' => '=='
									,'value' => 'horizontal'
								)
							)
						)
					)
				)
				,'selectors'	=> array(
					'{{WRAPPER}} .style-default-bg .product-category-wrapper > a' => 'border-color: {{VALUE}};'
					,'{{WRAPPER}} :where(.style-icon, .style-auto-width).direction-horizontal .product-category-wrapper' => 'border-color: {{VALUE}};'
				)
            )
        );
		
		$this->end_controls_tab();
		
		$this->start_controls_tab(
			'style_hover_tab'
			,array(
				'label' 		=> esc_html__( 'Hover', 'themesky' )
			)
		);
		
		$this->add_control(
            'item_text_hover_color'
            ,array(
                'label'     	=> esc_html__( 'Text Color', 'themesky' )
                ,'type'     	=> Controls_Manager::COLOR
				,'default'  	=> ''
				,'selectors'	=> array(
					'{{WRAPPER}} .product-category-wrapper:hover .category-name' => 'color: {{VALUE}};'
					,'{{WRAPPER}} .style-big-text .product-category-wrapper:hover .meta-btn' => 'background: {{VALUE}}; border-color: {{VALUE}};'
				)
            )
        );
		
		$this->add_control(
            'btn_text_hover_color'
            ,array(
                'label'     	=> esc_html__( 'Button Text Hover Color', 'themesky' )
                ,'type'     	=> Controls_Manager::COLOR
				,'default'  	=> ''
				,'condition'	=> array( 'style' => 'big-text' )
				,'selectors'	=> array(
					'{{WRAPPER}} .style-big-text .product-category-wrapper:hover .meta-btn' => 'color: {{VALUE}}; border-color: {{VALUE}};'
				)
            )
        );
		
		$this->add_control(
            'btn_bg_hover_color'
            ,array(
                'label'     	=> esc_html__( 'Button Background Hover Color', 'themesky' )
                ,'type'     	=> Controls_Manager::COLOR
				,'default'  	=> ''
				,'condition'	=> array( 'style' => 'big-text' )
				,'selectors'	=> array(
					'{{WRAPPER}} .style-big-text .product-category-wrapper:hover .meta-btn' => 'background-color: {{VALUE}};'
				)
            )
        );
		
		$this->add_control(
            'item_bg_hover_color'
            ,array(
                'label'     	=> esc_html__( 'Background Color', 'themesky' )
                ,'type'     	=> Controls_Manager::COLOR
				,'default'  	=> ''
				,'conditions' => array(
					'relation' => 'or'
					,'terms' => array(
						array(
							'name' => 'style'
							,'operator' => '=='
							,'value' => 'default-bg'
						)
						,array(
							'relation' => 'and'
							,'terms' => array(
								array(
									'name' => 'style'
									,'operator' => 'in'
									,'value' => array('icon', 'auto-width')
								)
								,array(
									'name' => 'item_direction'
									,'operator' => '=='
									,'value' => 'horizontal'
								)
							)
						)
					)
				)
				,'selectors'	=> array(
					'{{WRAPPER}} .style-default-bg .product-category-wrapper:hover > a:before' => 'background: {{VALUE}};'
					,'{{WRAPPER}} :where(.style-icon, .style-auto-width).direction-horizontal .product-category-wrapper:hover' => 'background: {{VALUE}};'
				)
            )
        );
		
		$this->add_control(
            'item_border_hover_color'
            ,array(
                'label'     	=> esc_html__( 'Border Color', 'themesky' )
                ,'type'     	=> Controls_Manager::COLOR
				,'default'  	=> ''
				,'conditions' => array(
					'relation' => 'or'
					,'terms' => array(
						array(
							'name' => 'style'
							,'operator' => '=='
							,'value' => 'default-bg'
						)
						,array(
							'relation' => 'and'
							,'terms' => array(
								array(
									'name' => 'style'
									,'operator' => 'in'
									,'value' => array('icon', 'auto-width')
								)
								,array(
									'name' => 'item_direction'
									,'operator' => '=='
									,'value' => 'horizontal'
								)
							)
						)
					)
				)
				,'selectors'	=> array(
					'{{WRAPPER}} .style-default-bg .product-category-wrapper:hover > a' => 'border-color: {{VALUE}};'
					,'{{WRAPPER}} :where(.style-icon, .style-auto-width).direction-horizontal .product-category-wrapper:hover' => 'border-color: {{VALUE}};'
				)
            )
        );
		
		$this->end_controls_tab();
		
		$this->add_responsive_control(
			'img_height'
			,array(
				'label' 	=> esc_html__( 'Image Height', 'themesky' )
				,'type' 	=> Controls_Manager::SLIDER
				,'range' 	=> array(
					'px'	=> array(
						'min' 	=> 0
						,'max' 	=> 100
					)
				)
				,'size_units' 	=> array( 'px')
				,'default' 		=> array( 'unit' => 'px', 'size' => 42 )
				,'conditions' => array(
					'relation' => 'and'
					,'terms' => array(
						array(
							'name' => 'style'
							,'operator' => '=='
							,'value' => 'auto-width'
						)
						,array(
							'name' => 'item_direction'
							,'operator' => '=='
							,'value' => 'horizontal'
						)
					)
				)
				,'selectors' 	=> array(
					'{{WRAPPER}} .style-auto-width.direction-horizontal.woocommerce .products .product .product-category-wrapper > a img' => 'height: {{SIZE}}{{UNIT}};'
				)
			)
		);
		
		$this->add_responsive_control(
			'item_padding'
			,array(
				'type' => Controls_Manager::DIMENSIONS
				,'label' => esc_html__( 'Item Padding', 'themesky' )
				,'size_units' => array( 'px', '%', 'em', 'rem' )
				,'default' => array(
					'top' => ''
					,'right' => ''
					,'bottom' => ''
					,'left' => ''
					,'unit' => 'px'
					,'isLinked' => false
				)
				,'conditions' => array(
					'relation' => 'and'
					,'terms' => array(
						array(
							'name' => 'style'
							,'operator' => 'in'
							,'value' => array('icon', 'auto-width')
						)
						,array(
							'name' => 'item_direction'
							,'operator' => '=='
							,'value' => 'horizontal'
						)
					)
				)
				,'selectors' => array(
					'{{WRAPPER}} :where(.style-icon, .style-auto-width).direction-horizontal .product-category-wrapper' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
				)
			)
		);
		
		$this->end_controls_section();
		
		$this->start_controls_section(
            'section_auto_width_style'
            ,array(
                'label' 	=> esc_html__( 'Slider Auto Width', 'themesky' )
                ,'tab'   	=> Controls_Manager::TAB_STYLE
            )
        );
		
		$this->add_control(
			'auto_width_alert'
			,array(
				'type' 			=> Controls_Manager::ALERT
				,'alert_type' 	=> 'info'
				,'heading' 		=> ''
				,'content' 		=> esc_html__( 'With style Auto Width and Slider is enabled. You can change the gradient background of navigation here to match with your container\'s background', 'themesky' )
			)
		);
		
		$this->add_group_control(
			\Elementor\Group_Control_Background::get_type()
			,array(
				'label' 			=> esc_html__( 'Navigation Background', 'themesky' )
				,'name' 			=> 'nav_gradient_bg'
				,'types' 			=> array('gradient')
				,'fields_options' 	=> array(
					'background' => array(
						'default' => 'gradient'
					)
					,'color' => array(
						'default' => 'rgba(255, 255, 255, 0)'
					)
					,'color_stop' => array(
						'default' => array(
							'unit' => '%'
							,'size' => 0
						)
					)
					,'color_b' => array(
						'default' => 'rgba(255, 255, 255, 1)'
					)
					,'color_b_stop' => array(
						'default' => array(
							'unit' => '%'
							,'size' => 75
						)
					)
					,'gradient_angle' => array(
						'default' => array(
							'unit' => 'deg'
							,'size' => 90
						)
					)
				)
				,'selector'			=> 'body {{WRAPPER}} .ts-product-category-wrapper.style-auto-width :is(.swiper-button-next, .swiper-button-prev)'
			)
		);
		
		$this->end_controls_section();
	}
	
	protected function render(){
		$settings = $this->get_settings_for_display();
		
		$default = array(
			'lazy_load'						=> 0
			,'title'						=> ''
			,'style' 						=> 'default'
			,'item_direction' 				=> 'vertical'
			,'parents' 						=> ''
			,'layout_partial'				=> 0
			,'is_slider'					=> 0
			,'only_slider_mobile'			=> 0
			,'per_page' 					=> 8
			,'columns' 						=> 8
			,'first_level' 					=> 0
			,'parent' 						=> ''
			,'child_of' 					=> 0
			,'ids'	 						=> ''
			,'hide_empty'					=> 1
			,'show_cat_img'					=> 1
			,'show_title'					=> 1
			,'show_product_count'			=> 1
			,'show_nav' 					=> 0
			,'show_dots' 					=> 0
			,'auto_play' 					=> 0
			,'loop' 						=> 1
			,'disable_slider_responsive'	=> 0
		);
		
		$settings = wp_parse_args( $settings, $default );
		
		extract( $settings );
		
		if( !class_exists('WooCommerce') ){
			return;
		}
		
		if( $this->lazy_load_placeholder( $settings, 'product-category' ) ){
			return;
		}

		if( $only_slider_mobile && !wp_is_mobile() ){
			$is_slider = false;
		}
		
		if( is_admin() && !wp_doing_ajax() ){ /* WooCommerce does not include hook below in Elementor editor */
			add_action( 'woocommerce_before_subcategory_title', 'woocommerce_subcategory_thumbnail', 10 );
		}
		
		if( $style == 'icon' ){
			remove_action( 'woocommerce_before_subcategory_title', 'woocommerce_subcategory_thumbnail', 10 );
			add_action( 'woocommerce_before_subcategory_title', array($this, 'category_icon'), 10 );
		}
		
		if( $style == 'big-text' && $item_direction == 'horizontal' ){
			$columns = 1;
		}
		
		if( $first_level ){
			$parent = $child_of = 0;
		}
	
		$parent = is_array($parent) ? implode('', $parent) : $parent;
		$child_of = is_array($child_of) ? implode('', $child_of) : $child_of;

		$args = array(
			'taxonomy'	  => 'product_cat'
			,'meta_key'   => 'order'
			,'orderby'    => 'meta_value_num'
			,'hide_empty' => $hide_empty
			,'pad_counts' => true
			,'parent'     => $parent
			,'child_of'   => $child_of
			,'number'     => $limit
		);
		
		if( $ids ){
			$args['include'] = $ids;
			$args['orderby'] = 'include';
		}
		
		$product_categories = get_terms( $args );
		
		$old_woocommerce_loop_columns = wc_get_loop_prop('columns');
		wc_set_loop_prop('columns', $columns);
		
		wc_set_loop_prop( 'is_shortcode', true );
		
		if( count($product_categories) > 0 ):
			$classes = array();
			$classes[] = 'ts-product-category-wrapper ts-product ts-shortcode woocommerce';
			$classes[] = 'style-'.$style;
			$classes[] = 'direction-'.$item_direction;
			$classes[] = 'columns-'.$columns;
			
			if( !$show_cat_img ){
				$classes[] = 'hide-cat-img';
			}
			
			if( $layout_partial ){
				$classes[] = 'partial-right';
			}
			
			$data_attr = array();
			if( $is_slider ){
				$classes[] = 'ts-slider';
				if( $show_nav ){
					$classes[] = 'has-nav';
				}
				if( $show_dots ){
					$classes[] = 'has-dots';
				}
				$data_attr[] = 'data-nav="'.$show_nav.'"';
				$data_attr[] = 'data-dots="'.$show_dots.'"';
				$data_attr[] = 'data-autoplay="'.$auto_play.'"';
				$data_attr[] = 'data-loop="'.$loop.'"';
				$data_attr[] = 'data-columns="'.$columns.'"';
				$data_attr[] = 'data-disable_responsive="'.$disable_slider_responsive.'"';
			}
		?>
			<div class="<?php echo esc_attr(implode(' ', $classes)) ?>" style="--ts-product-columns: <?php echo esc_attr($columns) ?>" <?php echo implode(' ', $data_attr); ?>>
				<?php if( $title ): ?>
				<header class="shortcode-heading-wrapper">
					<h3 class="shortcode-title"><?php echo esc_html($title); ?></h3>
				</header>
				<?php endif; ?>
			
				<div class="content-wrapper <?php echo $is_slider?'loading':''; ?>">
					<?php 
					woocommerce_product_loop_start();
					
					foreach ( $product_categories as $category ) {
						wc_get_template( 'content-product-cat.php', array(
							'category' 					=> $category
							,'style' 					=> $style
							,'show_title' 				=> $show_title
							,'show_product_count' 		=> $show_product_count
						) );
					}
					
					woocommerce_product_loop_end();
					?>
				</div>
			</div>
		<?php
		endif;
		
		if( $style == 'icon' ){
			add_action( 'woocommerce_before_subcategory_title', 'woocommerce_subcategory_thumbnail', 10 );
			remove_action( 'woocommerce_before_subcategory_title', array($this, 'category_icon'), 10 );
		}
		
		wc_set_loop_prop('columns', $old_woocommerce_loop_columns);
		
		wc_set_loop_prop( 'is_shortcode', false );
	}

	function category_icon( $category ){
		$icon_id = get_term_meta($category->term_id, 'icon_id', true);
		if( $icon_id ){
			echo wp_get_attachment_image( $icon_id, 'full', false, array('alt' => $category->name) );
		}
		else{
			echo wc_placeholder_img();
		}
	}
}

$widgets_manager->register( new TS_Elementor_Widget_Product_Categories() );