jQuery(function($){
	"use strict";
	var _wrapper = null;
	var _variation_id = 0;
	var _is_change_variation = false;
	
	function update_fragments(){
		var main_product_id = _wrapper.attr('data-main_product_id');
		var selected_ids = [];
		_wrapper.find('input[name="ts-fbt-product-ids[]"]').each(function(){
			if( $(this).is(':checked') ){
				selected_ids.push( $(this).val() );
			}
		});
		
		if( _variation_id && _is_change_variation ){ /* if just change, selected variation */
			selected_ids.push( _variation_id );
		}
		
		selected_ids = selected_ids.join(',');
		
		_wrapper.addClass('loading');
		$.ajax({
			type : "POST",
			timeout : 30000,
			url : themesky_params.ajax_uri,
			data : {action: 'ts_frequently_bought_together_fragments', main_product_id: main_product_id, variation_id: _variation_id, selected_ids: selected_ids, nonce: ts_fbt_params.ajax_nonce},
			error: function(xhr,err){
				
			},
			success: function( response ){
				if( response && typeof response.fragments != 'undefined' ){
					$.each( response.fragments, function( key, value ){
						$( key ).replaceWith( value );
					});
				}
				_wrapper.removeClass('loading');
			}
		});
	}
	
	$(document).on('change', '.ts-frequently-bought-together input[name="ts-fbt-product-ids[]"]', function(){
		_wrapper = $(this).closest('.ts-frequently-bought-together');
		update_fragments();
	});
	
	$(document).on('found_variation', 'form.variations_form', function(e, variation){
		var product_id = $(this).data('product_id');
		if( typeof product_id == 'undefined' ){
			return;
		}
		
		if( !$('.ts-frequently-bought-together[data-main_product_id="' + product_id + '"]').length ){
			return;
		}
		_is_change_variation = true;
		
		_variation_id = variation.variation_id;
		_wrapper = $('.ts-frequently-bought-together[data-main_product_id="' + product_id + '"]');
		
		update_fragments();
		
		_is_change_variation = false;
	});
});