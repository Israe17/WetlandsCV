<?php
use Elementor\Controls_Manager;

class TS_Elementor_Widget_Product_Deals extends TS_Elementor_Widget_Base{
	public function get_name(){
        return 'ts-product-deals';
    }
	
	public function get_title(){
        return esc_html__( 'TS Product Deals', 'themesky' );
    }
	
	public function get_categories(){
        return array( 'ts-elements', 'woocommerce-elements' );
    }
	
	public function get_icon(){
		return 'eicon-product-upsell';
	}
	
	protected function register_controls(){
		$this->start_controls_section(
            'section_general'
            ,array(
                'label' 	=> esc_html__( 'General', 'themesky' )
                ,'tab'   	=> Controls_Manager::TAB_CONTENT
            )
        );
		
		$this->add_lazy_load_controls( array( 'thumb-height' => 320 ) );
		
		$this->add_control(
            'title'
            ,array(
                'label' 		=> esc_html__( 'Shortcode Title', 'themesky' )
                ,'type' 		=> Controls_Manager::TEXT
                ,'default' 		=> ''		
                ,'description' 	=> ''
            )
        );
		
		$this->add_control(
            'product_type'
            ,array(
                'label' 		=> esc_html__( 'Product type', 'themesky' )
                ,'type' 		=> Controls_Manager::SELECT
                ,'default' 		=> 'recent'
				,'options'		=> array(
									'recent' 		=> esc_html__('Recent', 'themesky')
									,'featured' 	=> esc_html__('Featured', 'themesky')
									,'best_selling' => esc_html__('Best Selling', 'themesky')
									,'top_rated' 	=> esc_html__('Top Rated', 'themesky')
									,'mixed_order' 	=> esc_html__('Mixed Order', 'themesky')
								)		
                ,'description' 	=> esc_html__( 'Select type of product', 'themesky' )
            )
        );
		
		$this->add_control(
            'product_layout'
            ,array(
				'label' 		=> esc_html__( 'Product Layout', 'themesky' )
				,'type' 		=> Controls_Manager::CHOOSE
				,'options' 		=> array(
					'grid' 		=> array(
						'title' 	=> esc_html__( 'Grid', 'themesky' )
						,'icon' 	=> 'eicon-posts-grid'
					)
					,'list'		=> array(
						'title' 	=> esc_html__( 'List', 'themesky' )
						,'icon' 	=> 'eicon-post-list'
					)
				)
				,'default' 		=> 'grid'
				,'classes' 		=> 'control-choose-big'
			)
        );
		
		$this->add_control(
            'columns'
            ,array(
                'label'     	=> esc_html__( 'Columns', 'themesky' )
                ,'type'     	=> Controls_Manager::NUMBER
				,'default'  	=> 5
				,'min'      	=> 1
            )
        );
		
		$this->add_control(
            'limit'
            ,array(
                'label'     	=> esc_html__( 'Limit', 'themesky' )
                ,'type'     	=> Controls_Manager::NUMBER
				,'default'  	=> 5
				,'min'      	=> 1
				,'description' 	=> esc_html__( 'Number of Products', 'themesky' )
            )
        );
		
		$this->add_control(
            'product_cats'
            ,array(
                'label' 		=> esc_html__( 'Product categories', 'themesky' )
                ,'type' 		=> 'ts_autocomplete'
                ,'default' 		=> array()
				,'options'		=> array()
				,'autocomplete'	=> array(
					'type'		=> 'taxonomy'
					,'name'		=> 'product_cat'
				)
				,'multiple' 	=> true
				,'sortable' 	=> false
				,'label_block' 	=> true
            )
        );

		$this->add_control(
            'ids'
            ,array(
                'label' 		=> esc_html__( 'Specific products', 'themesky' )
                ,'type' 		=> 'ts_autocomplete'
                ,'default' 		=> array()
				,'options'		=> array()
				,'autocomplete'	=> array(
					'type'		=> 'post'
					,'name'		=> 'product'
				)
				,'multiple' 	=> true
				,'sortable' 	=> false
				,'label_block' 	=> true
            )
        );
		
		$this->add_control(
			'ts_hr'
			,array(
                'type' 		=> Controls_Manager::DIVIDER
            )
		);		
		
		$this->add_control(
            'show_shop_more_button'
            ,array(
                'label' 		=> esc_html__( 'Shop more button', 'themesky' )
                ,'type' 		=> Controls_Manager::SWITCHER
                ,'default' 		=> '0'
				,'return_value' => '1'
				,'label_on'		=> 	esc_html__( 'Show', 'themesky' )
				,'label_off'	=> 	esc_html__( 'Hide', 'themesky' )	
                ,'description' 	=> ''
            )
        );
		
		$this->add_control(
			'shop_more_button_link'
			,array(	
				'label'		 		=> esc_html__( 'Button link', 'themesky' )
				,'type'				=> Controls_Manager::URL
				,'default'			=> array( 'url'	=> '', 'is_external' => true, 'nofollow' => true )
				,'show_external' 	=> true
				,'condition'		=> array( 'show_shop_more_button' => '1' )
			)
		);
		
		$this->add_control(
            'shop_more_button_text'
            ,array(
                'label' 		=> esc_html__( 'Button text', 'themesky' )
                ,'type' 		=> Controls_Manager::TEXT
                ,'default' 		=> 'See All Products'		
                ,'description' 	=> ''
				,'condition'	=> array( 'show_shop_more_button' => '1' )
            )
        );

		$this->end_controls_section();
		
		$this->start_controls_section(
            'section_item'
            ,array(
                'label' 		=> esc_html__( 'Item', 'themesky' )
                ,'tab'   		=> Controls_Manager::TAB_CONTENT
            )
        );
		
		$this->add_control(
            'show_availability_bar'
            ,array(
                'label' 		=> esc_html__( 'Show availability bar', 'themesky' )
                ,'type' 		=> Controls_Manager::SWITCHER
                ,'default' 		=> '0'
				,'return_value' => '1'
				,'label_on'		=> 	esc_html__( 'Yes', 'themesky' )
				,'label_off'	=> 	esc_html__( 'No', 'themesky' )			
                ,'description' 	=> ''
            )
        );
		
		$this->add_control(
            'show_counter'
            ,array(
                'label' 		=> esc_html__( 'Show counter', 'themesky' )
                ,'type' 		=> Controls_Manager::SWITCHER
                ,'default' 		=> '1'
				,'return_value' => '1'
				,'label_on'		=> 	esc_html__( 'Yes', 'themesky' )
				,'label_off'	=> 	esc_html__( 'No', 'themesky' )			
                ,'description' 	=> esc_html__( 'Show counter on each product', 'themesky' )
            )
        );

		$this->add_control(
            'show_counter_today'
            ,array(
                'label' 		=> esc_html__( 'Show counter today', 'themesky' )
                ,'type' 		=> Controls_Manager::SWITCHER
                ,'default' 		=> '0'
				,'return_value' => '1'
				,'label_on'		=> 	esc_html__( 'Yes', 'themesky' )
				,'label_off'	=> 	esc_html__( 'No', 'themesky' )			
                ,'description' 	=> esc_html__( 'Show the counter beside heading title. The counter of each product will be hidden', 'themesky' )
            )
        );
		
		$this->add_control(
			'ts_hr_2'
			,array(
                'type' 		=> Controls_Manager::DIVIDER
            )
		);
		
		$this->add_control(
            'has_gap'
            ,array(
                'label' 		=> esc_html__( 'Item Has Gap', 'themesky' )
                ,'type' 		=> Controls_Manager::SWITCHER
                ,'default' 		=> '0'
				,'return_value' => '1'
				,'label_on'		=> 	esc_html__( 'Show', 'themesky' )
				,'label_off'	=> 	esc_html__( 'Hide', 'themesky' )	
                ,'description' 	=> ''
            )
        );
		
		$this->add_product_meta_controls();
		
		$this->add_product_color_swatch_controls();

		$this->end_controls_section();
		
		$this->start_controls_section(
            'section_slider'
            ,array(
                'label' 	=> esc_html__( 'Slider', 'themesky' )
                ,'tab'   	=> Controls_Manager::TAB_CONTENT
            )
        );
		
		$this->add_product_slider_controls();
		
		$this->end_controls_section();
		
		$this->start_controls_section(
            'section_style'
            ,array(
                'label' 	=> esc_html__( 'Shortcode Title', 'themesky' )
                ,'tab'   	=> Controls_Manager::TAB_STYLE
            )
        );
		
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type()
			,array(
				'label' 			=> esc_html__( 'Title Typography', 'themesky' )
				,'name' 			=> 's_title_typography'
				,'selector'			=> '{{WRAPPER}} .shortcode-title'
			)
		);
		
		$this->add_control(
            's_title_color'
            ,array(
                'label'     	=> esc_html__( 'Title Text Color', 'themesky' )
                ,'type'     	=> Controls_Manager::COLOR
				,'default'  	=> ''
				,'selectors'	=> array(
					'{{WRAPPER}} .shortcode-title' => 'color: {{VALUE}}'
				)
            )
        );
		
		$this->add_responsive_control(
            'text_align_title'
            ,array(
                'label' 		=> esc_html__( 'Title Alignment', 'themesky' )
                ,'type' 		=> Controls_Manager::CHOOSE
				,'options' => array(
					'left' => array(
						'title' => esc_html__( 'Left', 'themesky' )
						,'icon' => 'eicon-text-align-left'
					)
					,'center' => array(
						'title' => esc_html__( 'Center', 'themesky' )
						,'icon' => 'eicon-text-align-center'
					)
					,'right' => array(
						'title' => esc_html__( 'Right', 'themesky' )
						,'icon' => 'eicon-text-align-right'
					)
				)
				,'description' 	=> ''
				,'selectors' => array(
					'{{WRAPPER}} .shortcode-heading-wrapper' => 'justify-content: {{VALUE}};'
					,'{{WRAPPER}} .shortcode-heading-wrapper .shortcode-title, {{WRAPPER}} .ts-elementor-lazy-load .placeholder-widget-title' => 'text-align: {{VALUE}};'
				)
            )
        );
		
		$this->end_controls_section();
	}
	
	protected function render(){
		$settings = $this->get_settings_for_display();
		
		$default = array(
			'lazy_load'						=> 0
			,'title'						=> ''
			,'product_type'					=> 'recent'
			,'product_layout'				=> 'grid'
			,'columns' 						=> 5
			,'limit' 						=> 5
			,'product_cats'					=> array()
			,'ids'							=> array()
			,'has_gap'						=> 0
			,'show_counter'					=> 1
			,'show_counter_today'			=> 0
			,'show_availability_bar'		=> 0
			,'show_image' 					=> 1
			,'show_title' 					=> 1
			,'show_sku' 					=> 0
			,'show_price' 					=> 1
			,'show_short_desc'  			=> 0
			,'show_rating' 					=> 0
			,'show_label' 					=> 1	
			,'show_categories'				=> 0	
			,'show_brands'					=> 0	
			,'show_add_to_cart' 			=> 1
			,'border_primary_color' 		=> 0
			,'show_color_swatch'			=> 0
			,'number_color_swatch'			=> 3
			,'show_shop_more_button' 		=> 0
			,'shop_more_button_link' 		=> array( 'url' => '', 'is_external' => true, 'nofollow' => true )
			,'shop_more_button_text' 		=> 'See All Products'
			,'is_slider' 					=> 0
			,'only_slider_mobile'			=> 0
			,'rows' 						=> 1
			,'show_dots' 					=> 0
			,'show_nav' 					=> 0
			,'nav_bottom'					=> 0
			,'auto_play' 					=> 0
			,'loop'							=> 1
			,'disable_slider_responsive'	=> 0
		);
		
		$settings = wp_parse_args( $settings, $default );
		
		extract( $settings );
		
		if( !class_exists('WooCommerce') ){
			return;
		}
		
		$product_ids_on_sale = ts_get_product_deals_ids();
		
		if( $ids ){
			$product_ids_on_sale = array_intersect($product_ids_on_sale, $ids);
		}

		if( !$product_ids_on_sale ){
			return;
		}
		
		if( $this->lazy_load_placeholder( $settings, 'product-deals' ) ){
			return;
		}
	
		if( $only_slider_mobile && !wp_is_mobile() ){
			$is_slider = false;
		}
	
		if( $show_counter_today ){
			$show_counter = 0;
		}
		
		if( $show_counter ){
			add_action('woocommerce_after_shop_loop_item', 'ts_template_loop_time_deals', 1);
		}
		
		if( $show_availability_bar ){
			add_action('woocommerce_after_shop_loop_item', 'ts_product_availability_bar', 40);
		}

		/* Remove hook */
		$options = array(
				'show_image'			=> $show_image
				,'show_label'			=> $show_label
				,'show_title'			=> $show_title
				,'show_sku'				=> $show_sku
				,'show_price'			=> $show_price
				,'show_short_desc'		=> $show_short_desc
				,'show_categories'		=> $show_categories
				,'show_brands'			=> $show_brands
				,'show_rating'			=> $show_rating
				,'show_add_to_cart'		=> $show_add_to_cart
				,'show_color_swatch'	=> $show_color_swatch
				,'number_color_swatch'	=> $number_color_swatch
			);
		ts_remove_product_hooks( $options );

		global $post, $product;
		if( (int)$columns <= 0 ){
			$columns = 6;
		}
		
		$old_woocommerce_loop_columns = wc_get_loop_prop('columns');
		wc_set_loop_prop('columns', $columns);
		
		$args = array(
			'post_type'				=> 'product'
			,'post_status' 			=> 'publish'
			,'posts_per_page' 		=> $limit
			,'orderby' 				=> 'date'
			,'order' 				=> 'desc'
			,'post__in'				=> $product_ids_on_sale
			,'meta_query' 			=> WC()->query->get_meta_query()
			,'tax_query'           	=> WC()->query->get_tax_query()
		);
		
		ts_filter_product_by_product_type($args, $product_type);
		
		if( $product_cats ){
			$args['tax_query'][] = array(
							'taxonomy' 	=> 'product_cat'
							,'terms' 	=> $product_cats
							,'field' 	=> 'term_id'
						);
		}
		
		$link_attr = $this->generate_link_attributes( $shop_more_button_link );
		
		$products = new WP_Query($args);
		
		if( $products->have_posts() ): 
			$classes = array();
			$classes[] = 'ts-product-deals-wrapper ts-shortcode ts-product woocommerce';
			$classes[] = 'columns-' . $columns;
			$classes[] = $show_image?'':'no-thumbnail';
			$classes[] = $show_counter_today?'show-counter-today':'';
			$classes[] = $product_layout;
			
			if( !$show_counter ){
				$classes[] = 'no-counter';
			}
			
			if( $has_gap ){
				$classes[] = 'has-gap';
			}
			
			if( $is_slider ){
				$classes[] = 'ts-slider ';
				$classes[] = 'rows-' . $rows;
				
				if( $show_nav ){
					$classes[] = 'has-nav';
					$classes[] = ( !$nav_bottom && $title == '' )?'nav-middle':'';
					
					if( $nav_bottom ){
						$classes[] = 'nav-bottom';
					}
				}
				
				if( $show_dots ){
					$classes[] = 'has-dots';
				}
			}
			
			if( $disable_slider_responsive ){
				$classes[] = 'disable-responsive';
			}
			
			if( $show_shop_more_button ){
				$classes[] = 'has-shop-more-button';
			}

			$classes = array_filter($classes);
			
			$data_attr = array();
			if( $is_slider ){
				$data_attr[] = 'data-nav="'.$show_nav.'"';
				$data_attr[] = 'data-dots="'.$show_dots.'"';
				$data_attr[] = 'data-autoplay="'.$auto_play.'"';
				$data_attr[] = 'data-loop="'.$loop.'"';
				$data_attr[] = 'data-columns="'.$columns.'"';
				$data_attr[] = 'data-disable_responsive="'.$disable_slider_responsive.'"';
			}			
			?>
			<div class="<?php echo esc_attr( implode(' ', $classes) ); ?>" style="--ts-columns: <?php echo esc_attr($columns) ?>" <?php echo implode(' ', $data_attr); ?>>
				
				<?php 
				if( $title || $show_counter_today ){
					echo $title ? '<header class="shortcode-heading-wrapper">' : '<div class="shortcode-heading-wrapper">';
					
					if( $title ){
						echo '<h3 class="shortcode-title">'. esc_html($title) .'</h3>';
					}
					
					if( $show_counter_today ){
						$current_time = current_time('timestamp');
						$total_seconds_of_day = 60 * 60 * 24;
						$pass_second = $current_time % $total_seconds_of_day;
						$remain_second = $total_seconds_of_day - $pass_second;
						echo '<div class="ts-countdown-wrapper">';
							echo '<span>'.esc_html('Ends in').'</span>';
							ts_countdown( array( 'seconds' => $remain_second ) );
						echo '</div>';
					}

					echo $title ? '</header>' : '</div>';
				}			
				?>
				
				<div class="content-wrapper <?php echo ($is_slider)?'loading':''; ?>">
					<?php
						woocommerce_product_loop_start();

						$count = 0;
						while( $products->have_posts() ){
							$products->the_post();
							
							if( $is_slider && $rows > 1 && $count % $rows == 0 ){
								echo '<div class="product-group">';
							}
							
							wc_get_template_part( 'content', 'product' );
							
							if( $is_slider && $rows > 1 && ($count % $rows == $rows - 1 || $count == $products->post_count - 1) ){
								echo '</div>';
							}
						
							$count++;
						}
							
						woocommerce_product_loop_end();
					?>
				</div>
				
				<?php
					if( $show_shop_more_button ){
						echo '<div class="shop-more">';
							echo '<a class="shop-more-button button-text" '. implode( ' ', $link_attr ) .'>'. esc_html($shop_more_button_text) .'</a>';
						echo '</div>';
					}
				?>

			</div>
			<?php
		endif;
		
		wp_reset_postdata();
		
		/* restore hooks */
		if( $show_counter ){
			remove_action('woocommerce_after_shop_loop_item', 'ts_template_loop_time_deals', 1);
		}
		
		if( $show_availability_bar ){
			remove_action('woocommerce_after_shop_loop_item', 'ts_product_availability_bar', 40);
		}

		ts_restore_product_hooks();

		wc_set_loop_prop('columns', $old_woocommerce_loop_columns);
	}
}

$widgets_manager->register( new TS_Elementor_Widget_Product_Deals() );